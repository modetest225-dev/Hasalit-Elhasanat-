// ============================================================================
// إعدادات Firebase - لازم تعبّي القيم دي بنفسك عشان تسجيل الدخول بجوجل يشتغل
// ============================================================================
// من غير القيم دي، التطبيق هيفضل شغال عادي تمامًا لكن في وضع "ضيف" فقط
// (بدون تسجيل دخول ولا استرجاع حساب من جهاز تاني).
//
// إزاي تجيب القيم دي؟ (٥ دقايق مجانًا):
// 1) روح https://console.firebase.google.com وسجّل دخول بحساب جوجل
// 2) دوس "Add project" واختار اسم للمشروع (مثلاً: hasana-app)
// 3) من صفحة المشروع، دوس على أيقونة الويب </> عشان تضيف تطبيق ويب جديد
// 4) هيدّيك كائن (object) فيه القيم دي بالظبط، انسخه وحطه مكان القيم اللي تحت
// 5) من القائمة الجانبية: Build > Authentication > Sign-in method > فعّل Google
// 6) من القائمة الجانبية: Build > Firestore Database > Create database (اختار وضع Production أو Test)
//
// بعد كده احفظ الملف ده وارفعه مع باقي ملفات التطبيق، وتسجيل الدخول هيشتغل تلقائيًا.
// ============================================================================

const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT.appspot.com",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID",
};
