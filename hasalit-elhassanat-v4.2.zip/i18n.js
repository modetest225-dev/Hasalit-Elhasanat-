// ============================================================================
// نظام تعدد اللغات (i18n)
// ============================================================================
// بصراحة تامة: ترجمة كل حرف في التطبيق (مئات القصص والأسئلة والأحاديث ونص
// القرآن) لعشرات اللغات هو مشروع ترجمة ضخم منفصل، وخصوصًا القرآن الكريم الذي
// يجب أن يُستقى من ترجمات معتمدة من علماء متخصصين وليس من ترجمة آلية مرتجلة.
// لذلك هذا النظام يترجم بالكامل واجهة التطبيق (كل الأزرار والعناوين والتابات)
// للعربية والإنجليزية كأساس متين وجاهز للعمل الآن، ويعرض لغات إضافية في قائمة
// الاختيار موسومة "قريبًا" بصدق بدل الادعاء بدعمها فعليًا. نص القرآن نفسه عند
// اختيار لغة غير العربية سيُجلب من ترجمة معتمدة (Sahih International عبر واجهة
// alquran.cloud الموجودة أصلاً في التطبيق) بدل ترجمة مُرتجلة.

const SUPPORTED_LANGUAGES = [
  { code: 'ar', name: 'العربية', dir: 'rtl', ready: true },
  { code: 'en', name: 'English', dir: 'ltr', ready: true },
  { code: 'fr', name: 'Français', dir: 'ltr', ready: false },
  { code: 'ur', name: 'اردو', dir: 'rtl', ready: false },
  { code: 'tr', name: 'Türkçe', dir: 'ltr', ready: false },
  { code: 'id', name: 'Bahasa Indonesia', dir: 'ltr', ready: false },
  { code: 'ms', name: 'Bahasa Melayu', dir: 'ltr', ready: false },
  { code: 'bn', name: 'বাংলা', dir: 'ltr', ready: false },
  { code: 'ha', name: 'Hausa', dir: 'ltr', ready: false },
  { code: 'sw', name: 'Kiswahili', dir: 'ltr', ready: false },
  { code: 'ur2', name: 'فارسی', dir: 'rtl', ready: false },
];

const translations = {
  ar: {
    tab_home: 'مهامي', tab_pet: 'حيواني', tab_assistant: 'فاعل الخير', tab_stories: 'قصص',
    tab_quiz: 'اختبار', tab_games: 'ألعاب', tab_challenges: 'تحديات', tab_rewards: 'مكافآت',
    tab_achievements: 'إنجازاتي', tab_quran: 'قرآن', tab_hadith: 'أحاديث', tab_adhkar: 'أذكار',
    tab_sunnah: 'سنن الرسول', tab_prayerTimes: 'مواقيت الصلاة', tab_tree: 'شجرتي',
    tab_scenarios: 'مواقف', tab_tasbih: 'سبحة', tab_shop: 'متجر', tab_prayer: 'تعلّم الصلاة', tab_subscription: 'الاشتراك', tab_calendar: 'التقويم الهجري', tab_more: 'المزيد',
    tab_contributors: 'المساهمين',
    tab_otherServices: 'مشاريع أخرى',
    tab_inviteFriend: 'دعوة صديق',
    tab_diamondVault: 'خزنة العملات',
    tab_asmaHusna: 'الأسماء الحسنى',
    tab_kaffara: 'حاسبة الكفارة',
    tab_safeVideos: 'فيديوهات آمنة',
    tab_halalScanner: 'رفيق الحلال',
    tab_events: 'الفعاليات',
    page_home: 'مهامي اليوم', page_pet: 'حيوانك الأليف', page_island: 'جزيرة الحسنات',
    page_stories: 'قصص الأنبياء والصالحين', page_quiz: 'اختبر معلوماتك', page_challenges: 'التحديات',
    page_assistant: 'فاعل الخير', page_games: 'ألعاب إسلامية', page_rewards: 'المكافآت',
    page_achievements: 'إنجازاتي', page_quran: 'القرآن الكريم', page_hadith: 'أحاديث نبوية',
    page_sunnah: 'سنن الرسول ﷺ', page_contributors: 'المساهمين', page_tree: 'شجرة حسناتي',
    page_tasbih: 'السبحة الرقمية', page_scenarios: 'مرآة المواقف', page_adhkar: 'الأذكار',
    page_shop: 'متجر الشخصيات', page_prayerTimes: 'مواقيت الصلاة', page_prayer: 'تعلّم الصلاة خطوة بخطوة',
    page_other: 'مشاريع أخرى', page_calendar: 'التقويم الهجري',
    page_events: 'الفعاليات الحصرية',
    close: 'إغلاق', save: 'حفظ', cancel: 'إلغاء', confirm: 'تأكيد', yes: 'نعم', no: 'لا',
    settings_language: 'اللغة', choose_language: 'اختر لغتك', continue: 'متابعة',
    welcome_title: 'مرحبًا بك! 👋', app_name: 'حصالة الحسنات',
    task_done_btn: 'حصل', task_pending: 'بانتظار الوالدين', points_suffix: 'نقطة',
    buy_for: 'شراء مقابل', currently_active: 'مُفعّل حالياً', activate_this: 'تفعيل',
    listen_story: 'استمع للقصة', stop_narration: 'إيقاف',
  },
  en: {
    tab_home: 'My Tasks', tab_pet: 'My Pet', tab_assistant: 'Helper', tab_stories: 'Stories',
    tab_quiz: 'Quiz', tab_games: 'Games', tab_challenges: 'Challenges', tab_rewards: 'Rewards',
    tab_achievements: 'Achievements', tab_quran: 'Quran', tab_hadith: 'Hadiths', tab_adhkar: 'Adhkar',
    tab_sunnah: "Prophet's Sunnah", tab_prayerTimes: 'Prayer Times', tab_tree: 'My Tree',
    tab_scenarios: 'Scenarios', tab_tasbih: 'Tasbih', tab_shop: 'Shop', tab_prayer: 'Learn Prayer', tab_subscription: 'Subscription', tab_calendar: 'Hijri Calendar', tab_more: 'More',
    tab_contributors: 'Contributors',
    tab_otherServices: 'Other Projects',
    tab_inviteFriend: 'Invite a Friend',
    tab_diamondVault: 'Currency Vault',
    tab_asmaHusna: 'Names of Allah',
    tab_kaffara: 'Expiation Calculator',
    tab_safeVideos: 'Safe Videos',
    tab_halalScanner: 'Halal Companion',
    tab_events: 'Events',
    page_home: "Today's Tasks", page_pet: 'Your Pet', page_island: 'Good Deeds Island',
    page_stories: 'Stories of Prophets & the Righteous', page_quiz: 'Test Your Knowledge', page_challenges: 'Challenges',
    page_assistant: 'Helper Assistant', page_games: 'Islamic Games', page_rewards: 'Rewards',
    page_achievements: 'My Achievements', page_quran: 'The Holy Quran', page_hadith: 'Prophetic Hadiths',
    page_sunnah: "Prophet's Sunnah", page_contributors: 'Contributors', page_tree: 'My Good Deeds Tree',
    page_tasbih: 'Digital Tasbih', page_scenarios: 'Situation Mirror', page_adhkar: 'Adhkar',
    page_shop: 'Character Shop', page_prayerTimes: 'Prayer Times', page_prayer: 'Learn Prayer Step by Step',
    page_other: 'Other Projects', page_calendar: 'Hijri Calendar',
    page_events: 'Exclusive Events',
    close: 'Close', save: 'Save', cancel: 'Cancel', confirm: 'Confirm', yes: 'Yes', no: 'No',
    settings_language: 'Language', choose_language: 'Choose your language', continue: 'Continue',
    welcome_title: 'Welcome! 👋', app_name: 'Hasanat Piggy Bank',
    task_done_btn: 'Done', task_pending: 'Awaiting parent approval', points_suffix: 'pts',
    buy_for: 'Buy for', currently_active: 'Currently active', activate_this: 'Activate',
    listen_story: 'Listen to story', stop_narration: 'Stop',
  },
};

function tr(key) {
  const lang = (typeof state !== 'undefined' && state.language) || 'ar';
  return (translations[lang] && translations[lang][key]) || translations.ar[key] || key;
}

function applyLanguageDirection() {
  const lang = (typeof state !== 'undefined' && state.language) || 'ar';
  const meta = SUPPORTED_LANGUAGES.find(l => l.code === lang) || SUPPORTED_LANGUAGES[0];
  document.documentElement.setAttribute('lang', lang);
  document.documentElement.setAttribute('dir', meta.dir);
  document.body.style.direction = meta.dir;
  document.title = lang === 'en' ? 'Hasanat Piggy Bank' : 'حصالة الحسنات-Hasalit El Hassanat';
}

// ============================== شاشة اختيار اللغة (تظهر مرة واحدة أول استخدام، قبل بوابة تسجيل الدخول) ==============================
function renderLanguagePickerIfNeeded() {
  const root = document.getElementById('lang-picker-root');
  if (!root) return;
  if (typeof state === 'undefined' || state.languageChosen) { root.innerHTML = ''; return; }
  const chips = SUPPORTED_LANGUAGES.map(l => `
    <button class="lang-chip ${!l.ready ? 'soon' : ''}" data-action="pick-language" data-code="${l.code}" ${!l.ready ? 'disabled' : ''}>
      ${l.name}${!l.ready ? '<span class="lang-soon-badge">قريبًا</span>' : ''}
    </button>`).join('');
  root.innerHTML = `
  <div class="modal-overlay" style="z-index:999">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <h1 class="title">🌍 اختر لغتك / Choose your language</h1>
      <p class="muted mt8">تقدر تغيّرها في أي وقت من الإعدادات</p>
      <div class="lang-grid mt16">${chips}</div>
    </div>
  </div>`;
  if (typeof bindContainer === 'function') bindContainer(root);
}

function pickLanguage(code) {
  const meta = SUPPORTED_LANGUAGES.find(l => l.code === code);
  if (!meta || !meta.ready) return;
  if (typeof state !== 'undefined') {
    state.language = code;
    state.languageChosen = true;
    if (typeof saveState === 'function') saveState();
  }
  applyLanguageDirection();
  const root = document.getElementById('lang-picker-root');
  if (root) root.innerHTML = '';
  if (typeof render === 'function') render();
}


// ============================== ترجمة الواجهة الحيّة (DOM) ==============================
// كل قوالب التطبيق مكتوبة بالعربية، فعند اختيار الإنجليزية نترجم النصوص الظاهرة بعد كل رسم من القاموس
// (EN_UI_PAIRS في i18n-en.js)، بمطابقة كاملة أولًا ثم مطابقة جزئية للجمل التي فيها أرقام أو أجزاء متغيرة.
let __enExact = null, __enPartial = null;
const AR_RE = /[\u0600-\u06FF]/;
function __buildEnMaps() {
  if (__enExact || typeof EN_UI_PAIRS === 'undefined') return;
  __enExact = new Map();
  EN_UI_PAIRS.forEach(([ar, en]) => { if (!__enExact.has(ar.trim())) __enExact.set(ar.trim(), en); });
  // مطابقة جزئية للعبارات المركّبة فقط (8 حروف فأكثر وفيها مسافة) كي لا تُستبدل كلمات مفردة داخل جمل أخرى، الأطول أولًا حتى لا تُستبدل أجزاء من جمل أكبر
  __enPartial = [...__enExact.entries()].filter(([k]) => k.length >= 8 && k.includes(' ')).sort((a, b) => b[0].length - a[0].length);
}
const EN_RULES = [
  [/^بعد (\d+) يوم$/, (m) => `In ${m[1]} days`],
  [/^\+?(\d+) نقطة$/, (m) => `+${m[1]} pts`],
  [/^احصل على (\d+) نقطة$/, (m) => `Get ${m[1]} points`],
  [/^(\d+) \/ (\d+)$/, (m) => `${m[1]} / ${m[2]}`],
  [/^آخر تحديث: (.+)$/, (m) => `Last updated: ${m[1]}`],
  [/^مفعّلة — تنتهي (.+)$/, (m) => `Active, ends ${m[1]}`],
  [/^آخر عقوبة: (.+)$/, (m) => `Last penalty: ${m[1]}`],
  [/^مجموع أعمالك: ?(\d+)$/, (m) => `Your total deeds: ${m[1]}`],
  [/^(مكية|مدنية) · (\d+) آية$/, (m) => `${m[1] === 'مكية' ? 'Makki' : 'Madani'} · ${m[2]} verses`],
  [/^(\d+) ركعات? · (.+)$/, (m) => `${m[1]} rak'ahs · ${m[2] === 'فرض' ? 'Obligatory' : (m[2] === 'سنة مؤكدة' ? 'Confirmed sunnah' : m[2])}`],
  [/^افتح مقابل (\d+) ألماس(?:ة|ات)?$/, (m) => `Unlock for ${m[1]} diamonds`],
  [/^مدة الاشتراك: (\d+) يوم \(شهر واحد\) من وقت التفعيل$/, (m) => `Plan length: ${m[1]} days (one month) from activation`],
  [/^أنجز (\d+) مهام اليوم \((\d+)\/(\d+)\)$/, (m) => `Complete ${m[1]} tasks today (${m[2]}/${m[3]})`],
  [/^حفظت (\d+) من (\d+) سورة حتى الآن، استمر .*$/, (m) => `You have memorized ${m[1]} of ${m[2]} surahs so far, keep going!`],
  [/^إجمالي مرات التسبيح بهذا الذكر: ?(\d+)$/, (m) => `Total times for this dhikr: ${m[1]}`],
  [/^السلسلة الحالية: ?(\d+) يوم$/, (m) => `Current streak: ${m[1]} days`],
  [/^أيام الصيام المسجّلة: ?(\d+)$/, (m) => `Logged fasting days: ${m[1]}`],
];
function __translateText(txt) {
  __buildEnMaps();
  if (!__enExact) return txt;
  const trimmed = txt.trim();
  if (!trimmed) return txt;
  const lead = txt.slice(0, txt.indexOf(trimmed)), trail = txt.slice(txt.indexOf(trimmed) + trimmed.length);
  const hit = __enExact.get(trimmed);
  if (hit) return lead + hit + trail;
  for (const [re, fn] of EN_RULES) { const m = re.exec(trimmed); if (m) return lead + fn(m) + trail; }
  let out = trimmed, changed = false;
  for (const [k, v] of __enPartial) {
    if (out.includes(k)) { out = out.split(k).join(v); changed = true; if (!AR_RE.test(out)) break; }
  }
  return (changed && !AR_RE.test(out)) ? lead + out + trail : txt;
}
// نحتفظ بالنص الأصلي لكل عنصر ثابت ترجمناه (مثل شريط التثبيت) لنعيده عند الرجوع للعربية
const __origText = new Map(), __origAttr = new Map();
function __restoreArabic() {
  if (!__origText.size && !__origAttr.size) return;
  __origText.forEach((v, n) => { if (n.isConnected) n.nodeValue = v; });
  __origAttr.forEach((o, el) => { if (el.isConnected) Object.keys(o).forEach(a => el.setAttribute(a, o[a])); });
  __origText.clear(); __origAttr.clear();
}
function translateDom(root) {
  const lang = (typeof state !== 'undefined' && state.language) || 'ar';
  if (lang !== 'en') { __restoreArabic(); return; }
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: (n) => {
      const p = n.parentNode;
      if (!p || !AR_RE.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
      const tag = p.nodeName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA') return NodeFilter.FILTER_REJECT;
      // لا نترجم نص القرآن والأحاديث والقصص عمدًا (محتوى ديني يُترجم من مصادر معتمدة فقط)
      if (p.closest && p.closest('.quran-book, .quran-ayah, [data-no-translate]')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    },
  });
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(n => { const v = __translateText(n.nodeValue); if (v !== n.nodeValue) { if (!__origText.has(n)) __origText.set(n, n.nodeValue); n.nodeValue = v; } });
  root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(el => {
    ['placeholder', 'title', 'aria-label'].forEach(a => {
      const v = el.getAttribute(a);
      if (v && AR_RE.test(v)) { const t = __translateText(v); if (t !== v) { const o = __origAttr.get(el) || {}; if (!(a in o)) o[a] = v; __origAttr.set(el, o); el.setAttribute(a, t); } }
    });
  });
}
// عناصر تُضاف خارج دورة الرسم (رسائل منبثقة، شريط التحديث، الشريط المتحرك) نترجمها عبر مراقب خفيف
let __trQueued = false;
function __initDomTranslator() {
  if (typeof MutationObserver === 'undefined') return;
  new MutationObserver(() => {
    if (__trQueued) return;
    __trQueued = true;
    requestAnimationFrame(() => { __trQueued = false; translateDom(document.body); });
  }).observe(document.body, { childList: true, subtree: true });
}
document.addEventListener('DOMContentLoaded', __initDomTranslator);
