// ==========================================================================
// حاسبة التقويم الهجري + المناسبات الإسلامية - تعمل بالكامل أوفلاين
// (خوارزمية حسابية معروفة، بدون إنترنت وبدون مكتبات خارجية)
// ==========================================================================

function gregorianToJDN(year, month, day) {
  const a = Math.floor((14 - month) / 12);
  const y = year + 4800 - a;
  const m = month + 12 * a - 3;
  return (
    day +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045
  );
}

function jdnToIslamic(jdn) {
  let l = jdn - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631);
  l = l - 10631 * n + 354;
  const j =
    Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) +
    Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
  l =
    l -
    Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) +
    29;
  const month = Math.floor((24 * l) / 709);
  const day = l - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;
  return { year, month, day };
}

// ضبط التاريخ الهجري بفرق أيام (-2 إلى +2) لمطابقة رؤية الهلال المحلية، لأن الحساب الجدولي قد يختلف يومًا
function hijriOffsetDays() {
  try {
    const o = (typeof state !== 'undefined' && state && Number(state.hijriOffset)) || 0;
    return Math.max(-2, Math.min(2, Math.round(o)));
  } catch (e) { return 0; }
}

function getTodayJDN() {
  const now = new Date();
  return gregorianToJDN(now.getFullYear(), now.getMonth() + 1, now.getDate()) + hijriOffsetDays();
}

function getTodayHijri() {
  return jdnToIslamic(getTodayJDN());
}

// عكس jdnToIslamic: من تاريخ هجري إلى رقم اليوم اليولياني
function hijriToJDN(year, month, day) {
  return Math.floor((11 * year + 3) / 30) + 354 * year + 30 * month - Math.floor((month - 1) / 2) + day + 1948440 - 385;
}

function hijriMonthLength(year, month) {
  const ny = month === 12 ? year + 1 : year;
  const nm = month === 12 ? 1 : month + 1;
  return hijriToJDN(ny, nm, 1) - hijriToJDN(year, month, 1);
}

// 0 = الأحد ... 6 = السبت
function jdnDayOfWeek(jdn) { return (jdn + 1) % 7; }

// يستخدم داخليًا فقط لربط يوم هجري بتاريخ تخزين (مثل سجل الصيام)، ولا يُعرض للمستخدم أبدًا
function jdnToDateKey(jdn) {
  const a = jdn + 32044;
  const b = Math.floor((4 * a + 3) / 146097);
  const c = a - Math.floor((146097 * b) / 4);
  const d = Math.floor((4 * c + 3) / 1461);
  const e = c - Math.floor((1461 * d) / 4);
  const m = Math.floor((5 * e + 2) / 153);
  const day = e - Math.floor((153 * m + 2) / 5) + 1;
  const month = m + 3 - 12 * Math.floor(m / 10);
  const year = 100 * b + d - 4800 + Math.floor(m / 10);
  return year + '-' + String(month).padStart(2, '0') + '-' + String(day).padStart(2, '0');
}

function hijriToDateKey(year, month, day) {
  return jdnToDateKey(hijriToJDN(year, month, day) - hijriOffsetDays());
}

function hijriLang() {
  try { return (typeof state !== 'undefined' && state && state.language) || 'ar'; } catch (e) { return 'ar'; }
}

const hijriMonthNames = [
  'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة',
];

const hijriMonthNamesEn = [
  'Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani", 'Jumada al-Awwal', 'Jumada al-Thani',
  'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhu al-Qi'dah", 'Dhu al-Hijjah',
];
const weekdayNamesAr = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const weekdayNamesEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const weekdayShortAr = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
const weekdayShortEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function hijriMonthName(m) {
  return (hijriLang() === 'en' ? hijriMonthNamesEn : hijriMonthNames)[m - 1] || '';
}
function weekdayName(dow, short) {
  const en = hijriLang() === 'en';
  return (short ? (en ? weekdayShortEn : weekdayShortAr) : (en ? weekdayNamesEn : weekdayNamesAr))[dow] || '';
}

function formatHijri(h) {
  if (hijriLang() === 'en') return `${h.day} ${hijriMonthName(h.month)} ${h.year} AH`;
  return `${h.day} ${hijriMonthName(h.month)} ${h.year}هـ`;
}

// كل حدث موزّع على شهره ويومه الهجري الحقيقي (وليس بتاريخ ميلادي تقريبي)
const islamicEvents = [
  { id: 'hijri-year', name: 'رأس السنة الهجرية', icon: 'calendar', hijriMonth: 1, dayStart: 1, dayEnd: 1,
    message: 'عام هجري جديد مبارك! هذه فرصة لبداية جديدة مع الله عز وجل', bonusPoints: 200, theme: 'theme-hijri', priority: 3 },
  { id: 'ashura', name: 'يوم عاشوراء', icon: 'hands', hijriMonth: 1, dayStart: 9, dayEnd: 10,
    message: 'اليوم الذي نجّى الله فيه موسى من فرعون. صم اليوم تكفيراً لذنوب سنة', bonusPoints: 200, theme: 'theme-default', priority: 4 },
  { id: 'mawlid', name: 'المولد النبوي الشريف', icon: 'star', hijriMonth: 3, dayStart: 12, dayEnd: 12,
    message: 'اللهم صل وسلم على نبينا محمد ﷺ في يوم مولده الشريف', bonusPoints: 300, theme: 'theme-mawlid', priority: 4 },
  { id: 'israa', name: 'ليلة الإسراء والمعراج', icon: 'mosque', hijriMonth: 7, dayStart: 27, dayEnd: 27,
    message: 'سبحان الذي أسرى بعبده ليلاً من المسجد الحرام إلى المسجد الأقصى', bonusPoints: 300, theme: 'theme-israa', priority: 4 },
  { id: 'shaban', name: 'نصف شعبان', icon: 'moon', hijriMonth: 8, dayStart: 15, dayEnd: 15,
    message: 'ليلة ترفع فيها الأعمال إلى الله. استغفر وتب إلى ربك', bonusPoints: 200, theme: 'theme-shaban', priority: 3 },
  { id: 'ramadan', name: 'رمضان الكريم', icon: 'crescentStar', hijriMonth: 9, dayStart: 1, dayEnd: 29,
    message: 'مبارك عليكم شهر رمضان المبارك! شهر الصيام والقيام وتلاوة القرآن الكريم', bonusPoints: 500, theme: 'theme-ramadan', priority: 1 },
  { id: 'laylat-qadr', name: 'ليلة القدر (العشر الأواخر)', icon: 'sparkle', hijriMonth: 9, dayStart: 21, dayEnd: 29,
    message: 'خير من ألف شهر! تعبَّد الليلة واكسب نقاطاً مضاعفة', bonusPoints: 1000, theme: 'theme-ramadan', priority: 2 },
  { id: 'eid-fitr', name: 'عيد الفطر المبارك', icon: 'gift', hijriMonth: 10, dayStart: 1, dayEnd: 3,
    message: 'تقبل الله منا ومنكم صالح الأعمال! كل عام وأنتم بخير', bonusPoints: 1000, theme: 'theme-eid', priority: 5 },
  { id: 'arafah', name: 'يوم عرفة', icon: 'hands', hijriMonth: 12, dayStart: 9, dayEnd: 9,
    message: 'أفضل يوم في السنة! الدعاء في يوم عرفة مستجاب. ادعُ الله من قلبك', bonusPoints: 500, theme: 'theme-default', priority: 4 },
  { id: 'eid-adha', name: 'عيد الأضحى المبارك', icon: 'gift', hijriMonth: 12, dayStart: 10, dayEnd: 13,
    message: 'اللهم تقبل منا! أيام التكبير والتضحية والتقرب إلى الله', bonusPoints: 1000, theme: 'theme-eid', priority: 5 },
];

// ============================== الأحداث الأسبوعية المتكررة (كل أسبوع بلا سيرفر) ==============================
// الاثنين والخميس: سنة صيام العصافير (صيام تطوعي خفيف يشجَّع عليه الأطفال)
// الجمعة: خطبة الجمعة + خانة يكتب فيها الطفل ما تعلمه
function getWeeklyEvent() {
  const day = new Date().getDay(); // 0=أحد 1=اثنين ... 5=جمعة 6=سبت
  if (day === 1 || day === 4) {
    return {
      id: 'sunnah-fast-' + day,
      kind: 'fasting',
      name: 'صيام الاثنين والخميس (صيام العصافير)',
      icon: 'bird',
      message: 'اليوم من أيام صيام النبي ﷺ المفضّلة. جرّب صيام العصافير (صيام جزء من اليوم بحسب سنك وبإذن والديك) واكسب نقاطاً بعد تأكيد الوالدين',
      theme: 'theme-fasting',
      points: 60,
    };
  }
  if (day === 5) {
    return {
      id: 'jumuah',
      kind: 'khutba',
      name: 'يوم الجمعة المبارك',
      icon: 'mosque',
      message: 'أكثِر اليوم من الصلاة على النبي ﷺ، واحرص على حضور خطبة الجمعة والإنصات لها، ثم اكتب أهم ما تعلمته لتأخذ مكافأتك من والديك',
      theme: 'theme-jumuah',
      points: 50,
    };
  }
  if (day === 0) {
    return {
      id: 'charity-sunday',
      kind: 'charity',
      name: 'يوم الصدقة',
      icon: 'gift',
      message: 'ابدأ أسبوعك بالصدقة! تصدّق ولو بشيء بسيط أو ساعد محتاجاً، فالصدقة تطفئ غضب الرب وتزيد المال بركة',
      theme: 'theme-default',
      points: 40,
    };
  }
  if (day === 2) {
    return {
      id: 'birr-tuesday',
      kind: 'birr',
      name: 'يوم بر الوالدين',
      icon: 'hands',
      message: 'اليوم افعل شيئاً يُسعد والديك: ساعدهما، أو قبّل رأسهما، أو قل لهما كلمة طيبة. بر الوالدين من أحب الأعمال إلى الله',
      theme: 'theme-default',
      points: 40,
    };
  }
  if (day === 3) {
    return {
      id: 'quran-wednesday',
      kind: 'quran',
      name: 'يوم حفظ القرآن',
      icon: 'book',
      message: 'خصص اليوم وقتاً إضافياً لتلاوة القرآن أو حفظ آية جديدة أو مراجعة ما حفظته من قبل',
      theme: 'theme-default',
      points: 50,
    };
  }
  // السبت
  return {
    id: 'akhlaq-saturday',
    kind: 'akhlaq',
    name: 'يوم الأخلاق الحسنة',
    icon: 'heart',
    message: 'اليوم تحدَّ نفسك أن تبتسم للجميع، وتتكلم بكلام طيب، وتساعد أي شخص تقابله. الخُلق الحسن يزن يوم القيامة الكثير',
    theme: 'theme-default',
    points: 40,
  };
}

function getActiveIslamicEvents() {
  const today = getTodayHijri();
  return islamicEvents
    .filter(e => e.hijriMonth === today.month && today.day >= e.dayStart && today.day <= e.dayEnd)
    .sort((a, b) => b.priority - a.priority);
}

function getCurrentIslamicEvent() {
  const active = getActiveIslamicEvents();
  return active[0] || null;
}

function getCurrentAppTheme() {
  const active = getActiveIslamicEvents();
  if (active[0]) return active[0].theme;
  const weekly = getWeeklyEvent();
  return weekly?.theme || 'theme-default';
}


// ============================== أدوات التقويم الهجري ==============================
// مناسبات الشهر الهجري الواحد (للتقويم): المناسبات الكبرى + الأيام البيض (سنّة الصيام في كل شهر)
function getHijriMonthEvents(month) {
  const list = islamicEvents
    .filter(e => e.hijriMonth === month)
    .map(e => ({ id: e.id, name: e.name, icon: e.icon, dayStart: e.dayStart, dayEnd: e.dayEnd, message: e.message, wholeMonth: (e.dayEnd - e.dayStart) >= 20 }));
  // 13 ذو الحجة من أيام التشريق التي لا يُصام فيها، فلا تُعرض الأيام البيض في هذا الشهر
  if (month !== 12) {
    list.push({ id: 'white-days', name: 'الأيام البيض', icon: 'moon', dayStart: 13, dayEnd: 15, wholeMonth: false,
      message: 'يُستحب صيام ثلاثة أيام من كل شهر هجري: الثالث عشر والرابع عشر والخامس عشر' });
  }
  return list.sort((a, b) => a.dayStart - b.dayStart);
}

function getHijriDayEvents(month, day) {
  return getHijriMonthEvents(month).filter(e => day >= e.dayStart && day <= e.dayEnd);
}

// أقرب المناسبات القادمة مع عدد الأيام المتبقية (أو "جارية الآن")
function getUpcomingHijriEvents(limit) {
  const t = getTodayHijri();
  const todayJ = getTodayJDN();
  const out = [];
  islamicEvents.forEach(e => {
    if (e.id === 'laylat-qadr') return;
    for (let y = t.year; y <= t.year + 1; y++) {
      const startJ = hijriToJDN(y, e.hijriMonth, e.dayStart);
      const endJ = hijriToJDN(y, e.hijriMonth, e.dayEnd);
      if (endJ >= todayJ) {
        out.push({ event: e, year: y, days: Math.max(0, startJ - todayJ), ongoing: startJ <= todayJ });
        break;
      }
    }
  });
  return out.sort((a, b) => a.days - b.days).slice(0, limit || 3);
}

// شبكة الشهر: الأسبوع يبدأ بالسبت. كل خلية = { day } أو null للمسافات الفارغة
function buildHijriMonthGrid(year, month) {
  const len = hijriMonthLength(year, month);
  const firstJ = hijriToJDN(year, month, 1);
  const lead = (jdnDayOfWeek(firstJ) + 1) % 7; // السبت = 0
  const cells = [];
  for (let i = 0; i < lead; i++) cells.push(null);
  for (let d = 1; d <= len; d++) cells.push({ day: d, dow: jdnDayOfWeek(firstJ + d - 1) });
  while (cells.length % 7 !== 0) cells.push(null);
  return { cells, length: len };
}

// ============================== ترجمة نصوص المناسبات للإنجليزية (يستخدمها نظام اللغات) ==============================
const HIJRI_EN_PAIRS = [
  ['رأس السنة الهجرية', 'Islamic New Year'],
  ['عام هجري جديد مبارك! هذه فرصة لبداية جديدة مع الله عز وجل', 'A blessed new Hijri year! A fresh start with Allah.'],
  ['يوم عاشوراء', 'Day of Ashura'],
  ['اليوم الذي نجّى الله فيه موسى من فرعون. صم اليوم تكفيراً لذنوب سنة', 'The day Allah saved Musa from Pharaoh. Fasting it expiates the sins of a year.'],
  ['المولد النبوي الشريف', "The Prophet's Birthday"],
  ['اللهم صل وسلم على نبينا محمد ﷺ في يوم مولده الشريف', 'O Allah, send peace and blessings upon our Prophet Muhammad ﷺ on his blessed birthday.'],
  ['ليلة الإسراء والمعراج', "Isra' and Mi'raj Night"],
  ['سبحان الذي أسرى بعبده ليلاً من المسجد الحرام إلى المسجد الأقصى', 'Glory to Him who took His servant by night from the Sacred Mosque to the Farthest Mosque.'],
  ['نصف شعبان', "Mid-Sha'ban"],
  ['ليلة ترفع فيها الأعمال إلى الله. استغفر وتب إلى ربك', 'A night when deeds are raised to Allah. Seek forgiveness and repent.'],
  ['رمضان الكريم', 'Blessed Ramadan'],
  ['مبارك عليكم شهر رمضان المبارك! شهر الصيام والقيام وتلاوة القرآن الكريم', 'Ramadan Mubarak! The month of fasting, night prayer and reciting the Quran.'],
  ['ليلة القدر (العشر الأواخر)', 'Laylat al-Qadr (Last Ten Nights)'],
  ['خير من ألف شهر! تعبَّد الليلة واكسب نقاطاً مضاعفة', 'Better than a thousand months! Worship tonight and earn double points.'],
  ['عيد الفطر المبارك', 'Eid al-Fitr'],
  ['تقبل الله منا ومنكم صالح الأعمال! كل عام وأنتم بخير', 'May Allah accept our good deeds and yours! Eid Mubarak!'],
  ['يوم عرفة', 'Day of Arafah'],
  ['أفضل يوم في السنة! الدعاء في يوم عرفة مستجاب. ادعُ الله من قلبك', 'The best day of the year! Supplications on Arafah are answered. Pray from your heart.'],
  ['عيد الأضحى المبارك', 'Eid al-Adha'],
  ['اللهم تقبل منا! أيام التكبير والتضحية والتقرب إلى الله', 'O Allah, accept from us! Days of takbeer, sacrifice and drawing near to Allah.'],
  ['الأيام البيض', 'The White Days'],
  ['يُستحب صيام ثلاثة أيام من كل شهر هجري: الثالث عشر والرابع عشر والخامس عشر', 'Fasting three days of every Hijri month is recommended: the 13th, 14th and 15th.'],
  ['صيام الاثنين والخميس (صيام العصافير)', 'Monday & Thursday Fast (Little Birds Fast)'],
  ['اليوم من أيام صيام النبي ﷺ المفضّلة. جرّب صيام العصافير (صيام جزء من اليوم بحسب سنك وبإذن والديك) واكسب نقاطاً بعد تأكيد الوالدين', "Today is one of the Prophet's ﷺ favorite fasting days. Try the Little Birds fast (part of the day, depending on your age and with your parents' permission) and earn points after parent approval."],
  ['يوم الجمعة المبارك', 'Blessed Friday'],
  ['أكثِر اليوم من الصلاة على النبي ﷺ، واحرص على حضور خطبة الجمعة والإنصات لها، ثم اكتب أهم ما تعلمته لتأخذ مكافأتك من والديك', "Send lots of blessings upon the Prophet ﷺ, attend the Friday sermon and listen quietly, then write the most important thing you learned to get your reward from your parents."],
  ['يوم الصدقة', 'Charity Day'],
  ['ابدأ أسبوعك بالصدقة! تصدّق ولو بشيء بسيط أو ساعد محتاجاً، فالصدقة تطفئ غضب الرب وتزيد المال بركة', 'Start your week with charity! Give even something small or help someone in need.'],
  ['يوم بر الوالدين', 'Honor Your Parents Day'],
  ['اليوم افعل شيئاً يُسعد والديك: ساعدهما، أو قبّل رأسهما، أو قل لهما كلمة طيبة. بر الوالدين من أحب الأعمال إلى الله', 'Do something that makes your parents happy: help them, kiss their heads, or say a kind word. Honoring parents is one of the most beloved deeds to Allah.'],
  ['يوم حفظ القرآن', 'Quran Memorization Day'],
  ['خصص اليوم وقتاً إضافياً لتلاوة القرآن أو حفظ آية جديدة أو مراجعة ما حفظته من قبل', 'Set aside extra time today to recite the Quran, memorize a new verse or review what you already know.'],
  ['يوم الأخلاق الحسنة', 'Good Manners Day'],
  ['اليوم تحدَّ نفسك أن تبتسم للجميع، وتتكلم بكلام طيب، وتساعد أي شخص تقابله. الخُلق الحسن يزن يوم القيامة الكثير', 'Challenge yourself today to smile at everyone, speak kindly and help whoever you meet. Good character weighs heavily on the Day of Judgment.'],
];
