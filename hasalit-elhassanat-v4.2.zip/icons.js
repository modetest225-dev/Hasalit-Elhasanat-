// ==========================================================================
// مكتبة رسوم توضيحية (SVG) خاصة بالتطبيق - بديل كامل لأي إيموجي
// كل الرسوم مرسومة يدوياً بخطوط بسيطة (لا صور خارجية ولا خطوط أيقونات جاهزة)
// ==========================================================================

const ICONS = {
  mosque: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v3M9 5a3 3 0 0 0 6 0"/><path d="M3 21V13c0-2.2 2-3.6 4-4.6C9 7.4 10 6 12 6s3 1.4 5 2.4c2 1 4 2.4 4 4.6v8"/><path d="M3 21h18"/><path d="M9 21v-5a3 3 0 0 1 6 0v5"/><path d="M5 21v-6M19 21v-6"/></svg>`,
  moon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z"/></svg>`,
  sun: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.4M12 19v2.4M4.5 12H2.1M21.9 12h-2.4M5.6 5.6l1.7 1.7M16.7 16.7l1.7 1.7M18.4 5.6l-1.7 1.7M7.3 16.7l-1.7 1.7"/></svg>`,
  coin: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.3 9.2c0-1.1 1.2-2 2.7-2s2.7.7 2.7 1.7c0 2.4-5.4 1-5.4 3.4 0 1 1.2 1.7 2.7 1.7s2.7-.9 2.7-2"/></svg>`,
  diamond: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"><path d="M4 9 L8 3 H16 L20 9 L12 21 Z"/><path d="M4 9 H20 M8 3 L9.5 9 L12 21 M16 3 L14.5 9 L12 21"/></svg>`,
  star: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2.5l2.7 6.3 6.8.6-5.2 4.5 1.6 6.6L12 16.9l-5.9 3.6 1.6-6.6-5.2-4.5 6.8-.6z"/></svg>`,
  sparkle: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2c.6 3.8 2 5.8 6 6.4-4 .6-5.4 2.6-6 6.4-.6-3.8-2-5.8-6-6.4 4-.6 5.4-2.6 6-6.4Z"/><path d="M19 15c.3 1.7.9 2.5 2.6 2.8-1.7.3-2.3 1.1-2.6 2.8-.3-1.7-.9-2.5-2.6-2.8 1.7-.3 2.3-1.1 2.6-2.8Z"/></svg>`,
  crescentStar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M15.5 3.5A8 8 0 1 0 15.5 20.5 9.5 9.5 0 1 1 15.5 3.5Z"/><path d="M19 5.5l.7 1.7 1.8.4-1.4 1.2.4 1.8-1.5-1-1.5 1 .4-1.8-1.4-1.2 1.8-.4z" fill="currentColor" stroke="none"/></svg>`,
  person: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.4-3.6 4-5.4 7.5-5.4s6.1 1.8 7.5 5.4"/></svg>`,
  book: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.2C6 4.3 8.5 4 12 5v14.5c-3.5-1-6-.7-8 .2Z"/><path d="M20 5.2C18 4.3 15.5 4 12 5v14.5c3.5-1 6-.7 8 .2Z"/></svg>`,
  bookOpenStar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6.2C5 5.3 7.3 5 11 5.8v13c-3.7-.8-6-.5-8 .4Z"/><path d="M21 6.2c-2-.9-4.3-1.2-8-.4v13c3.7-.8 6-.5 8 .4Z"/><path d="M16.5 2.2l.5 1.4 1.5.3-1.1 1 .3 1.5-1.2-.8-1.2.8.3-1.5-1.1-1 1.5-.3z" fill="currentColor" stroke="none"/></svg>`,
  scroll: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4h11a2 2 0 0 1 2 2v11a3 3 0 0 1-3 3H8"/><path d="M6 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2"/><path d="M9 9h7M9 13h7"/></svg>`,
  chat: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5h16v10H10l-4 3.5v-3.5H4Z"/><path d="M8 9.5h8M8 12.5h5"/></svg>`,
  beads: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="12" cy="4.5" r="1.7"/><circle cx="17" cy="7" r="1.7"/><circle cx="19.2" cy="12.3" r="1.7"/><circle cx="17" cy="17.6" r="1.7"/><circle cx="12" cy="20" r="1.7"/><circle cx="7" cy="17.6" r="1.7"/><circle cx="4.8" cy="12.3" r="1.7"/><circle cx="7" cy="7" r="1.7"/><path d="M12 4.5V1.3"/></svg>`,
  bag: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8h12l1 12.5H5Z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/></svg>`,
  brain: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4.5a2.5 2.5 0 0 0-2.5 2.5A2.5 2.5 0 0 0 4 9.5 2.7 2.7 0 0 0 5.4 14 3 3 0 0 0 8 18.5h1V4.5Z"/><path d="M15 4.5a2.5 2.5 0 0 1 2.5 2.5A2.5 2.5 0 0 1 20 9.5 2.7 2.7 0 0 1 18.6 14 3 3 0 0 1 16 18.5h-1V4.5Z"/><path d="M9 8.5h1M9 12h1M14 8.5h1M14 12h1"/></svg>`,
  checklist: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3.5" width="16" height="17" rx="2"/><path d="M8 9l1.5 1.5L12.5 7M8 15h8M8 17.5h5"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>`,
  checkCircle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.3l2.6 2.6L16.3 9"/></svg>`,
  xCircle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg>`,
  compass: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M15.5 8.5l-2 5-5 2 2-5Z" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1"/></svg>`,
  mic: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2.5" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3.5M9 21.5h6"/></svg>`,
  paperclip: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17 7l-7.5 7.5a3 3 0 0 0 4.2 4.2L21 12a5 5 0 0 0-7-7L6.5 12.5a4 4 0 0 0 5.6 5.6"/></svg>`,
  sendIcon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 3 3 10.5l7 3 3 7Z"/></svg>`,
  hourglass: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 3h11M6.5 21h11M7 3c0 4.5 3 5.5 5 6.5 2-1 5-2 5-6.5M7 21c0-4.5 3-5.5 5-6.5 2 1 5 2 5 6.5"/></svg>`,
  lock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15" r="1.4" fill="currentColor" stroke="none"/></svg>`,
  door: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3.5H6.5v17H14"/><path d="M10 12h9.5M17 8.5l3.5 3.5-3.5 3.5"/></svg>`,
  trash: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 6.5h15M9 6.5V4.8a1.3 1.3 0 0 1 1.3-1.3h3.4A1.3 1.3 0 0 1 15 4.8v1.7"/><path d="M6.5 6.5l.9 13a2 2 0 0 0 2 1.9h5.2a2 2 0 0 0 2-1.9l.9-13"/></svg>`,
  gift: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="9" width="16" height="4.5" rx="1"/><path d="M5.5 13.5v6.5a1.5 1.5 0 0 0 1.5 1.5h10a1.5 1.5 0 0 0 1.5-1.5v-6.5"/><path d="M12 9v12M12 9C10.5 6 7.5 5 6.5 6.8 5.6 8.4 8 9 12 9ZM12 9c1.5-3 4.5-4 5.5-2.2C18.4 8.4 16 9 12 9Z"/></svg>`,
  speaker: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4Z"/><path d="M16.5 9a4 4 0 0 1 0 6M18.7 6.8a7.3 7.3 0 0 1 0 10.4"/></svg>`,
  stop: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>`,
  key: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="9" r="4"/><path d="M11.2 11.8 19 19.5M15.5 16l2-2M18 18.5l2-2"/></svg>`,
  warning: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5 21.5 20h-19Z"/><path d="M12 9.5v5M12 17.2v.1"/></svg>`,
  heart: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 20.5s-7.6-4.6-9.8-9.2C.8 7.9 2.5 4.5 6 4c2-.3 3.6.8 6 3 2.4-2.2 4-3.3 6-3 3.5.5 5.2 3.9 3.8 7.3-2.2 4.6-9.8 9.2-9.8 9.2Z"/></svg>`,
  hands: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 20c-1-3.5-1-7 .5-11l1 .6c-1 3-1.2 6 0 9"/><path d="M18 20c1-3.5 1-7-.5-11l-1 .6c1 3 1.2 6 0 9"/><path d="M8 4.5c1.5 1.5 2.5 3.6 2.7 6.5M16 4.5c-1.5 1.5-2.5 3.6-2.7 6.5"/></svg>`,
  camera: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l1.5-2h7L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13.5" r="3.5"/></svg>`,
  crown: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"><path d="M4 18h16l-1.4-8-4 3-2.6-5-2.6 5-4-3Z"/><path d="M4 18v1.5h16V18"/></svg>`,
  seedling: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21v-9"/><path d="M12 12C7 12 5 9 5 6c4 0 7 2 7 6ZM12 12c5 0 7-3.5 7-7-4.5 0-7 2.5-7 7Z"/></svg>`,
  leaf: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M19 5C9 5 4.5 10 4.5 17.5 15 17.5 19 12 19 5Z"/><path d="M6 18C10 13 13 10 18 6"/></svg>`,
  tree: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21v-6.5"/><path d="M12 3c3.5 0 6 2.6 6 5.7 0 3.4-2.8 5.8-6 5.8s-6-2.4-6-5.8C6 5.6 8.5 3 12 3Z"/></svg>`,
  graduate: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 9 12 5l9.5 4-9.5 4-9.5-4Z"/><path d="M6.5 11v4.5c0 1.4 2.5 2.5 5.5 2.5s5.5-1.1 5.5-2.5V11"/><path d="M21.5 9v5.5"/></svg>`,
  bird: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13c2-4 5-5.5 8-5.2-.4-1.6.3-3 2-3.3 1.3-.3 2.6.4 3 1.6-1.1.1-2 .8-2 1.9 3 .3 5.5 2 6 5-2-.6-3.3-.5-4.3.2-1 4-4.5 6.3-8.7 6.3-1.6 0-2.7-.3-3.5-.7 1.6-.3 2.7-1 3.3-2C4.8 16.4 3.4 15 3 13Z"/><circle cx="15.3" cy="7.3" r=".5" fill="currentColor"/></svg>`,
  fastMoon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13.2A6.8 6.8 0 1 1 10.8 6a5.5 5.5 0 0 0 7.2 7.2Z"/></svg>`,
  calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></svg>`,
  drop: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5c3 4 6 7.5 6 11a6 6 0 1 1-12 0c0-3.5 3-7 6-11Z"/></svg>`,
  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4.5 6v6c0 4.7 3.2 7.7 7.5 9 4.3-1.3 7.5-4.3 7.5-9V6Z"/><path d="M9 12l2 2 4-4.3"/></svg>`,
  telescope: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5l13.5-4 1.6 5.4-13.5 4Z"/><path d="M12 12l7-2 2.5 3-1 3.5"/><path d="M9.5 12.7 7 20.5M12.5 13.6 11 20.5"/><circle cx="5.2" cy="8.4" r="1.7"/></svg>`,
  sleepy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M15 13.2A6.8 6.8 0 1 1 7.8 6a5.5 5.5 0 0 0 7.2 7.2Z"/><path d="M17 5h4M18 3v4M19.5 9h2.5M20.7 7.6v2.8"/></svg>`,
  pen: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20l.7-3.8L15.5 5.4a1.8 1.8 0 0 1 2.6 0l1.5 1.5a1.8 1.8 0 0 1 0 2.6L8.8 20.3z"/><path d="M13.8 7.1l3 3"/></svg>`,
  wave: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8c2-2 4-2 6 0s4 2 6 0 4-2 6 0M2 14c2-2 4-2 6 0s4 2 6 0 4-2 6 0M2 20c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/></svg>`,
  mailEnvelope: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5.5" width="18" height="13" rx="2.2"/><path d="M4 7l8 6 8-6"/></svg>`,
  instagramGlyph: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.2" y="3.2" width="17.6" height="17.6" rx="5.5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.1" cy="6.9" r="1" fill="currentColor" stroke="none"/></svg>`,
  xGlyph: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 4.5l15 15M19.5 4.5l-15 15"/></svg>`,
  facebookGlyph: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.2" y="3.2" width="17.6" height="17.6" rx="5.5"/><path d="M14 21v-7h2.4l.4-3H14V9.2c0-.9.3-1.5 1.6-1.5H17V5.1C16.6 5 15.7 5 14.7 5c-2.1 0-3.5 1.3-3.5 3.7V11H9v3h2.2v7Z" fill="currentColor" stroke="none"/></svg>`,
  youtubeGlyph: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10.2 9.3l5 2.7-5 2.7Z" fill="currentColor" stroke="none"/></svg>`,
  rabbit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 9.5C8 6 8.3 3 9.7 2.2c1 2 1.3 4.7 1 6.8M15 9.5c1-3.5.7-6.5-.7-7.3-1 2-1.3 4.7-1 6.8"/><circle cx="12" cy="13" r="5.2"/><circle cx="10" cy="12" r=".6" fill="currentColor" stroke="none"/><circle cx="14" cy="12" r=".6" fill="currentColor" stroke="none"/><path d="M11 14.3c.6.5 1.4.5 2 0"/><path d="M7.5 16.5c-1.5.7-2.2 2-2 3.5M16.5 16.5c1.5.7 2.2 2 2 3.5"/></svg>`,
  cat: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 8 5.5 3.5 9.5 6M17 8l1.5-4.5L14.5 6"/><circle cx="12" cy="12.5" r="6"/><circle cx="9.7" cy="11.5" r=".6" fill="currentColor" stroke="none"/><circle cx="14.3" cy="11.5" r=".6" fill="currentColor" stroke="none"/><path d="M12 13.2v.8M7 13.5H4M7 15h-3.4M17 13.5h3M17 15h3.4M10.5 14.5c.8.9 2.2.9 3 0"/></svg>`,
  butterfly: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5.5v13"/><path d="M12 7c-1-3-4.5-4-6.3-2.3-1.7 1.7-1 4.8 1.3 6C5 12 4.3 14.7 6 16.4c1.7 1.7 4.4.8 6-1.4M12 7c1-3 4.5-4 6.3-2.3 1.7 1.7 1 4.8-1.3 6 2 1.3 2.7 4 1 5.7-1.7 1.7-4.4.8-6-1.4"/><path d="M10.5 5.2 9.2 3M13.5 5.2 14.8 3"/></svg>`,
  turtle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5c0-3 3.6-5 8-5s8 2 8 5-3.6 4.5-8 4.5-8-1.5-8-4.5Z"/><path d="M9 8.5V7c0-1 .8-1.7 1.8-1.7M15 8.5V7c0-1-.8-1.7-1.8-1.7M8 16l-2 3M16 16l2 3M9.5 17l-1 3M14.5 17l1 3"/><circle cx="12" cy="12.3" r="1.4"/></svg>`,
  flower: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none"/><circle cx="12" cy="6.5" r="2.6"/><circle cx="17.5" cy="12" r="2.6"/><circle cx="12" cy="17.5" r="2.6"/><circle cx="6.5" cy="12" r="2.6"/><path d="M12 19v2.5"/></svg>`,
  fountain: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 19.5h18"/><path d="M5 19.5V17a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2.5"/><path d="M8 15v-3.5M16 15v-3.5M12 15V9"/><path d="M12 9c-1.5-1.5-1.5-3.5 0-5 1.5 1.5 1.5 3.5 0 5ZM8 11.5c-1.2-1.3-1.2-3 0-4.3M16 11.5c1.2-1.3 1.2-3 0-4.3"/></svg>`,
  cloud: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M6.5 17.5a4.2 4.2 0 0 1-.6-8.35 5 5 0 0 1 9.7-1.9A4.3 4.3 0 0 1 18 17.5Z"/></svg>`,
  rainbowArc: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2.5 18a9.5 9.5 0 0 1 19 0"/><path d="M6 18a6 6 0 0 1 12 0"/><path d="M9.5 18a2.5 2.5 0 0 1 5 0"/></svg>`,
};
ICONS.prayerTimes = ICONS.mosque; // إصلاح: أيقونة "مواقيت الصلاة" العادية (غير أيقونة التاب) كانت غير معرّفة فترجع لأيقونة ✨ افتراضيًا

function icon(name, extraClass) {
  const svg = ICONS[name] || ICONS.sparkle;
  return `<span class="i${extraClass ? ' ' + extraClass : ''}">${svg}</span>`;
}

// ============================== أيقونات التبويبات الملوّنة (رسوم مصنوعة بالكامل، ليست خطوطًا بيضاء) ==============================
// كل أيقونة رسمة صغيرة كاملة الألوان بتدرجات وظلال، مصمّمة خصيصًا لهذا التطبيق، بلا صور خارجية وبلا Emoji
const TAB_ICONS = {
  home: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgHomeBoard" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FFFDF7"/><stop offset="100%" stop-color="#F0E8D4"/></linearGradient>
    <linearGradient id="tgHomeClip" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#3C8055"/><stop offset="100%" stop-color="#2F6B44"/></linearGradient></defs>
    <rect x="5" y="5" width="22" height="24" rx="4" fill="url(#tgHomeBoard)" stroke="#D8C7A0" stroke-width="1"/>
    <rect x="11" y="3" width="10" height="6" rx="2.5" fill="url(#tgHomeClip)"/>
    <rect x="9" y="12" width="14" height="2.6" rx="1.3" fill="#D9A441"/>
    <rect x="9" y="17" width="14" height="2.6" rx="1.3" fill="#8FBFA0"/>
    <rect x="9" y="22" width="9" height="2.6" rx="1.3" fill="#8FBFA0"/>
    <circle cx="22" cy="23" r="4" fill="#2F6B44"/>
    <path d="M20.2 23l1.3 1.3 2.3-2.6" stroke="#fff" stroke-width="1.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,
  island: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgIslSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#BFE3F5"/><stop offset="100%" stop-color="#EAF6FA"/></linearGradient>
    <linearGradient id="tgIslSea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#5FA3C9"/><stop offset="100%" stop-color="#3F7FA6"/></linearGradient></defs>
    <circle cx="16" cy="16" r="14" fill="url(#tgIslSky)"/>
    <circle cx="23" cy="9" r="4" fill="#F2C464"/>
    <path d="M2 20 a14 14 0 0 0 28 0 Z" fill="url(#tgIslSea)"/>
    <path d="M6 21 Q16 14 26 21 L26 24 Q16 19 6 24 Z" fill="#5FA378"/>
    <rect x="14.3" y="12" width="1.6" height="8" rx="0.8" fill="#8B5A2B"/>
    <circle cx="15" cy="10.5" r="5" fill="#2F6B44"/>
    <circle cx="11.5" cy="13" r="3.4" fill="#3C8055"/>
    <circle cx="18.5" cy="13" r="3.4" fill="#3C8055"/>
  </svg>`,
  stories: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgStoL" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#4A5FA8"/><stop offset="100%" stop-color="#324580"/></linearGradient>
    <linearGradient id="tgStoR" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6C5A96"/><stop offset="100%" stop-color="#4E3E72"/></linearGradient></defs>
    <path d="M16 8c-3-2-7-2-10-1v17c3-1 7-1 10 1Z" fill="url(#tgStoL)"/>
    <path d="M16 8c3-2 7-2 10-1v17c-3-1-7-1-10 1Z" fill="url(#tgStoR)"/>
    <path d="M16 8v17" stroke="#FFE9A8" stroke-width="1"/>
    <rect x="14" y="4" width="4" height="9" rx="1" fill="#D9A441"/>
  </svg>`,
  quiz: `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgQuizBulb" cx="35%" cy="30%" r="75%"><stop offset="0%" stop-color="#FDE58B"/><stop offset="100%" stop-color="#D9A441"/></radialGradient></defs>
    <circle cx="16" cy="14" r="9" fill="url(#tgQuizBulb)"/>
    <rect x="12.5" y="21" width="7" height="3" rx="1.4" fill="#8B7355"/>
    <rect x="13" y="24.3" width="6" height="2.2" rx="1" fill="#6B5A45"/>
    <path d="M16 3v2.4M25 14h2.4M6.6 14H4M23 6.5l-1.6 1.6M9 8.1L7.4 6.5" stroke="#D9A441" stroke-width="1.6" stroke-linecap="round"/>
  </svg>`,
  games: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgGamePc" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#EDEBFB"/><stop offset="100%" stop-color="#C7C0EE"/></linearGradient></defs>
    <path d="M16 4l4.2 4.2h-3v3.6h3l-4.2 4.2-4.2-4.2h3V8.2h-3Z" fill="#C0392B"/>
    <rect x="4" y="16" width="24" height="12" rx="4" fill="url(#tgGamePc)"/>
    <circle cx="11" cy="22" r="2.6" fill="#4A5FA8"/>
    <circle cx="21" cy="22" r="2.6" fill="#3C8055"/>
    <circle cx="16" cy="22" r="2.6" fill="#D9A441"/>
  </svg>`,
  challenges: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgChalFlag" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#E0664D"/><stop offset="100%" stop-color="#C0392B"/></linearGradient></defs>
    <rect x="8" y="4" width="2.4" height="24" rx="1.2" fill="#8B7355"/>
    <path d="M10.4 5.5 24 9l-13.6 4Z" fill="url(#tgChalFlag)"/>
    <circle cx="9.2" cy="4.5" r="1.6" fill="#D9A441"/>
  </svg>`,
  rewards: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgRewBox" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#E0664D"/><stop offset="100%" stop-color="#C0392B"/></linearGradient></defs>
    <rect x="5" y="14" width="22" height="13" rx="2.5" fill="url(#tgRewBox)"/>
    <rect x="5" y="10" width="22" height="6" rx="2" fill="#D9433A"/>
    <rect x="14.2" y="10" width="3.6" height="17" fill="#F2C464"/>
    <path d="M12 10c-3-1-4-4-1.6-6 2 1.5 2.6 3.7 1.6 6ZM20 10c3-1 4-4 1.6-6-2 1.5-2.6 3.7-1.6 6Z" fill="#F2C464"/>
  </svg>`,
  achievements: `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgAchMedal" cx="35%" cy="30%" r="75%"><stop offset="0%" stop-color="#FDE58B"/><stop offset="100%" stop-color="#C9922A"/></radialGradient></defs>
    <path d="M11 14 7 4h5l3 8Z" fill="#4A5FA8"/>
    <path d="M21 14 25 4h-5l-3 8Z" fill="#C0392B"/>
    <circle cx="16" cy="19" r="9" fill="url(#tgAchMedal)" stroke="#A9761F" stroke-width="1"/>
    <path d="M16 13.5l1.5 3 3.3.4-2.4 2.3.6 3.3-2.9-1.6-2.9 1.6.6-3.3-2.4-2.3 3.3-.4Z" fill="#fff" opacity=".9"/>
  </svg>`,
  quran: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgQrCov" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3C8055"/><stop offset="100%" stop-color="#245536"/></linearGradient></defs>
    <path d="M7 6.5c3-1.4 6-1.4 9 0v20c-3-1.4-6-1.4-9 0Z" fill="url(#tgQrCov)"/>
    <path d="M25 6.5c-3-1.4-6-1.4-9 0v20c3-1.4 6-1.4 9 0Z" fill="#2F6B44"/>
    <circle cx="16" cy="12" r="3.4" fill="none" stroke="#D9A441" stroke-width="1.3"/>
    <path d="M16 9.2a3 3 0 1 0 0 5.6" fill="none" stroke="#D9A441" stroke-width="1.1"/>
  </svg>`,
  hadith: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgHadScroll" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#F6EFDC"/><stop offset="100%" stop-color="#E9DBB8"/></linearGradient></defs>
    <rect x="6" y="9" width="20" height="15" rx="2" fill="url(#tgHadScroll)"/>
    <rect x="6" y="7" width="20" height="4" rx="2" fill="#C9A24B"/>
    <rect x="6" y="21" width="20" height="4" rx="2" fill="#C9A24B"/>
    <rect x="9.5" y="13" width="13" height="1.8" rx=".9" fill="#B79A6C"/>
    <rect x="9.5" y="17" width="9" height="1.8" rx=".9" fill="#B79A6C"/>
  </svg>`,
  adhkar: `<svg viewBox="0 0 32 32">
    <g fill="none" stroke-width="0">
      <circle cx="16" cy="6.5" r="2.6" fill="#3C8055"/>
      <circle cx="23" cy="9.5" r="2.6" fill="#D9A441"/>
      <circle cx="26" cy="16" r="2.6" fill="#3C8055"/>
      <circle cx="23" cy="22.5" r="2.6" fill="#D9A441"/>
      <circle cx="16" cy="25.5" r="2.6" fill="#3C8055"/>
      <circle cx="9" cy="22.5" r="2.6" fill="#D9A441"/>
      <circle cx="6" cy="16" r="2.6" fill="#3C8055"/>
      <circle cx="9" cy="9.5" r="2.6" fill="#D9A441"/>
    </g>
    <circle cx="16" cy="16" r="3.6" fill="#4A5FA8"/>
  </svg>`,
  shop: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgShopBag" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#E0A45C"/><stop offset="100%" stop-color="#C1694F"/></linearGradient></defs>
    <path d="M9 12h14l1.4 15H7.6Z" fill="url(#tgShopBag)"/>
    <path d="M12 12v-2a4 4 0 0 1 8 0v2" fill="none" stroke="#8B5A2B" stroke-width="2" stroke-linecap="round"/>
    <circle cx="13" cy="17" r="1.4" fill="#fff"/><circle cx="19" cy="17" r="1.4" fill="#fff"/>
  </svg>`,
  prayer: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgPrDome" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3C8055"/><stop offset="100%" stop-color="#2F6B44"/></linearGradient></defs>
    <rect x="6" y="20" width="20" height="7" fill="#EFE6D3"/>
    <path d="M6 20a10 10 0 0 1 20 0Z" fill="url(#tgPrDome)"/>
    <rect x="14.3" y="8" width="1.6" height="6" fill="#D9A441"/>
    <circle cx="15.1" cy="6.5" r="1.6" fill="#D9A441"/>
    <rect x="10" y="21.5" width="3.4" height="5.5" rx="1.6" fill="#C9A24B"/>
    <rect x="18.6" y="21.5" width="3.4" height="5.5" rx="1.6" fill="#C9A24B"/>
  </svg>`,
  pet: `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgPetBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#E0A45C"/><stop offset="100%" stop-color="#C1694F"/></linearGradient></defs>
    <ellipse cx="16" cy="19" rx="9" ry="8" fill="url(#tgPetBody)"/>
    <circle cx="16" cy="10" r="6.4" fill="url(#tgPetBody)"/>
    <path d="M11 7 8 3l3 1Z" fill="#C1694F"/><path d="M21 7l3-4-3 1Z" fill="#C1694F"/>
    <circle cx="13.6" cy="9.6" r="1.1" fill="#3A2A1C"/><circle cx="18.4" cy="9.6" r="1.1" fill="#3A2A1C"/>
    <path d="M14.5 12.2q1.5 1.2 3 0" stroke="#3A2A1C" stroke-width="1" fill="none" stroke-linecap="round"/>
    <path d="M8 22c-2 1-3 3-2 5 2 0 4-1 5-3Z" fill="#D9A441"/>
  </svg>`,
  assistant: `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgAstBody" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#3C8055"/></radialGradient></defs>
    <ellipse cx="16" cy="27" rx="10" ry="2.6" fill="rgba(0,0,0,.12)"/>
    <path d="M8 16c0-7 4-11 8-11s8 4 8 11-4 10-8 10-8-3-8-10Z" fill="url(#tgAstBody)"/>
    <circle cx="8.5" cy="12" r="3.4" fill="url(#tgAstBody)"/><circle cx="23.5" cy="12" r="3.4" fill="url(#tgAstBody)"/>
    <circle cx="12" cy="16" r="4.2" fill="#FBF6EA"/><circle cx="20" cy="16" r="4.2" fill="#FBF6EA"/>
    <circle cx="12" cy="16" r="2" fill="#20303B"/><circle cx="20" cy="16" r="2" fill="#20303B"/>
    <path d="M13 24l3-3 3 3" stroke="#D9A441" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M9 24c2 3 12 3 14 0" stroke="#215538" stroke-width="1.4" fill="none" stroke-linecap="round"/>
  </svg>`,
  tree: `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgTreeLeaf" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#2F6B44"/></radialGradient></defs>
    <ellipse cx="16" cy="28" rx="10" ry="2.4" fill="rgba(0,0,0,.12)"/>
    <rect x="14.4" y="18" width="3.2" height="10" rx="1.4" fill="#8B5A2B"/>
    <circle cx="16" cy="10" r="9" fill="url(#tgTreeLeaf)"/>
    <circle cx="8.5" cy="15" r="5.5" fill="url(#tgTreeLeaf)"/>
    <circle cx="23.5" cy="15" r="5.5" fill="url(#tgTreeLeaf)"/>
    <circle cx="12" cy="9" r="2" fill="#D9A441"/><circle cx="20" cy="12" r="1.6" fill="#D9A441"/><circle cx="16" cy="6" r="1.6" fill="#D9A441"/>
  </svg>`,
  scenarios: `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgScopeFace" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#FBF6EA"/><stop offset="100%" stop-color="#E6D9B8"/></radialGradient></defs>
    <circle cx="16" cy="16" r="13" fill="url(#tgScopeFace)" stroke="#D9A441" stroke-width="2"/>
    <path d="M16 8l4 6-4 10-4-10Z" fill="#C1694F"/>
    <path d="M16 8l4 6-8 0Z" fill="#A6323B"/>
    <circle cx="16" cy="16" r="2.2" fill="#2F6B44"/>
    <circle cx="16" cy="6" r="1.4" fill="#2F6B44"/><circle cx="16" cy="26" r="1.4" fill="#2F6B44"/>
    <circle cx="6" cy="16" r="1.4" fill="#2F6B44"/><circle cx="26" cy="16" r="1.4" fill="#2F6B44"/>
  </svg>`,
};
function tabIcon(id) { return TAB_ICONS[id] || ''; }
TAB_ICONS.prayerTimes = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgClockFace" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#F2D27A"/><stop offset="100%" stop-color="#B8862E"/></radialGradient></defs>
    <circle cx="16" cy="16" r="12" fill="url(#tgClockFace)" stroke="#8B6F47" stroke-width="1.4"/>
    <path d="M16 9v7l5 3" stroke="#3C2A1C" stroke-width="2" stroke-linecap="round" fill="none"/>
  </svg>`;
TAB_ICONS.inviteFriend = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgInviteA" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#2F6B44"/></radialGradient></defs>
    <circle cx="11" cy="12" r="5" fill="url(#tgInviteA)"/>
    <path d="M3 26c0-4.5 3.4-7.5 8-7.5s8 3 8 7.5" fill="#2F6B44"/>
    <circle cx="24" cy="10" r="3.4" fill="#D9A441"/>
    <path d="M20 8l2 2 3.5-4" stroke="#fff" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
TAB_ICONS.kaffara = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgKaffaraMoon" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#2F6B44"/></radialGradient></defs>
    <path d="M20 5 A11 11 0 1 0 20 27 A9 9 0 1 1 20 5 Z" fill="url(#tgKaffaraMoon)"/>
    <path d="M8 24h16v4H8z" fill="#D9A441" rx="2"/>
  </svg>`;
TAB_ICONS.safeVideos = `<svg viewBox="0 0 32 32">
    <rect x="3" y="7" width="26" height="19" rx="4" fill="#2F6B44"/>
    <path d="M13 12 L21 16.5 L13 21 Z" fill="#fff"/>
    <circle cx="26" cy="8" r="3.5" fill="#D9A441"/>
  </svg>`;
TAB_ICONS.halalScanner = `<svg viewBox="0 0 32 32">
    <rect x="5" y="5" width="7" height="2.4" fill="#2F6B44"/><rect x="5" y="5" width="2.4" height="7" fill="#2F6B44"/>
    <rect x="20" y="5" width="7" height="2.4" fill="#2F6B44"/><rect x="24.6" y="5" width="2.4" height="7" fill="#2F6B44"/>
    <rect x="5" y="24.6" width="7" height="2.4" fill="#2F6B44"/><rect x="5" y="20" width="2.4" height="7" fill="#2F6B44"/>
    <rect x="20" y="24.6" width="7" height="2.4" fill="#2F6B44"/><rect x="24.6" y="20" width="2.4" height="7" fill="#2F6B44"/>
    <circle cx="16" cy="16" r="6" fill="#D9A441"/><path d="M13.5 16l1.8 1.8 3.2-3.6" stroke="#fff" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
TAB_ICONS.asmaHusna = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgAsmaStar" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#FDE68A"/><stop offset="100%" stop-color="#D9A441"/></radialGradient></defs>
    <path d="M16 4 L19 12 L27 12 L20.5 17 L23 25 L16 20 L9 25 L11.5 17 L5 12 L13 12 Z" fill="url(#tgAsmaStar)"/>
  </svg>`;
TAB_ICONS.diamondVault = `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgDiamondV" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#8FD3F4"/><stop offset="100%" stop-color="#2F80B8"/></linearGradient></defs>
    <path d="M6 12 L11 5 H21 L26 12 L16 27 Z" fill="url(#tgDiamondV)"/>
    <path d="M6 12 H26 M11 5 L13.5 12 L16 27 M21 5 L18.5 12 L16 27" stroke="#fff" stroke-width="1" opacity=".6"/>
  </svg>`;
TAB_ICONS.events = `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgEventsCrown" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#F2D27A"/><stop offset="100%" stop-color="#B8862E"/></linearGradient></defs>
    <path d="M5 14 L9 22 H23 L27 14 L21 18 L16 9 L11 18 Z" fill="url(#tgEventsCrown)" stroke="#8B6F47" stroke-width="1" stroke-linejoin="round"/>
    <circle cx="16" cy="8" r="2" fill="#E0577A"/>
    <rect x="9" y="22" width="14" height="3" rx="1" fill="#B8862E"/>
  </svg>`;
TAB_ICONS.subscription = TAB_ICONS.events; // إعادة استخدام أيقونة التاج نفسها الموجودة لتابة الفعاليات
TAB_ICONS.otherServices = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgOtherServ" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#2F6B44"/></radialGradient></defs>
    <rect x="6" y="6" width="9" height="9" rx="2.5" fill="url(#tgOtherServ)"/>
    <rect x="17" y="6" width="9" height="9" rx="2.5" fill="#D9A441"/>
    <rect x="6" y="17" width="9" height="9" rx="2.5" fill="#D9A441"/>
    <circle cx="21.5" cy="21.5" r="4.5" fill="url(#tgOtherServ)"/>
  </svg>`;
TAB_ICONS.contributors = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgContribStar" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#FDE68A"/><stop offset="100%" stop-color="#D9A441"/></radialGradient></defs>
    <circle cx="12" cy="13" r="5.5" fill="url(#tgContribStar)"/>
    <circle cx="21" cy="15" r="4.5" fill="#8FBFA0"/>
    <path d="M4 27c0-5 3.6-8.5 8-8.5s8 3.5 8 8.5" fill="#2F6B44"/>
    <path d="M18 27c0-4 2.8-7 6.5-7s6.5 3 6.5 7" fill="#4C8A63"/>
  </svg>`;
TAB_ICONS.sunnah = `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgSunnahBook" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#2F6B44"/></linearGradient></defs>
    <path d="M6 8c0-1.6 1.4-2.6 3-2.6h6.6v20.6H9c-1.6 0-3-1-3-2.6V8Z" fill="url(#tgSunnahBook)"/>
    <path d="M26 8c0-1.6-1.4-2.6-3-2.6h-6.6v20.6H23c1.6 0 3-1 3-2.6V8Z" fill="#D9A441"/>
    <path d="M16 5.4v20.6" stroke="#fff" stroke-width="1"/>
  </svg>`;
TAB_ICONS.tasbih = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgTasbihBead" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#F2D27A"/><stop offset="100%" stop-color="#B8862E"/></radialGradient></defs>
    <path d="M16 6 C 8 6 6 12 6 16 C 6 22 10 26 16 26" stroke="#8B6F47" stroke-width="1.6" fill="none"/>
    <circle cx="16" cy="6" r="3" fill="url(#tgTasbihBead)"/><circle cx="9" cy="10" r="3" fill="url(#tgTasbihBead)"/>
    <circle cx="6.5" cy="16" r="3" fill="url(#tgTasbihBead)"/><circle cx="9" cy="22" r="3" fill="url(#tgTasbihBead)"/>
    <circle cx="16" cy="26" r="3.4" fill="#2F6B44"/>
  </svg>`;
TAB_ICONS.more = `<svg viewBox="0 0 32 32">
    <circle cx="10" cy="10" r="3.4" fill="#8FBFA0"/><circle cx="22" cy="10" r="3.4" fill="#D9A441"/>
    <circle cx="10" cy="22" r="3.4" fill="#D9A441"/><circle cx="22" cy="22" r="3.4" fill="#8FBFA0"/>
  </svg>`;
TAB_ICONS.tree = `<svg viewBox="0 0 32 32">
    <defs><radialGradient id="tgTreeLeaf" cx="35%" cy="30%" r="80%"><stop offset="0%" stop-color="#8FBFA0"/><stop offset="100%" stop-color="#2F6B44"/></radialGradient></defs>
    <rect x="14.3" y="19" width="3.4" height="9" rx="1.4" fill="#8B5A2B"/>
    <circle cx="16" cy="14" r="10" fill="url(#tgTreeLeaf)"/>
    <circle cx="9" cy="18" r="6" fill="url(#tgTreeLeaf)"/>
    <circle cx="23" cy="18" r="6" fill="url(#tgTreeLeaf)"/>
    <circle cx="12" cy="12" r="1.6" fill="#D9A441"/><circle cx="20" cy="16" r="1.6" fill="#D9A441"/><circle cx="16" cy="9" r="1.6" fill="#D9A441"/>
  </svg>`;
TAB_ICONS.scenarios = `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgScenNeedle" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#C0392B"/><stop offset="100%" stop-color="#E0A45C"/></linearGradient></defs>
    <circle cx="16" cy="16" r="12" fill="#FBF6EA" stroke="#D9A441" stroke-width="2"/>
    <path d="M16 8l3.2 8.8L11 20l3.2-8.8Z" fill="url(#tgScenNeedle)"/>
    <circle cx="16" cy="16" r="2" fill="#3C2A1C"/>
  </svg>`;

// ============================== مشاهد غلاف القصص حسب التصنيف ==============================
// رسوم مركّبة (سماء + عناصر رمزية) مصنوعة بالكامل بالكود، بدون أي صور خارجية أو أشخاص مرسومين،
// تُعرض أعلى كل قصة عند فتحها لإعطاء إحساس "كتاب مصوّر" حقيقي
const STORY_COVER_SCENES = {
  prophets: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scPropSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#1B2440"/><stop offset="100%" stop-color="#3A2E5C"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scPropSky)"/>
    <circle cx="240" cy="35" r="18" fill="#F2E7C4"/><circle cx="233" cy="30" r="15" fill="#3A2E5C"/>
    <circle cx="40" cy="25" r="1.6" fill="#fff"/><circle cx="80" cy="45" r="1.2" fill="#fff"/><circle cx="130" cy="20" r="1.4" fill="#fff"/><circle cx="180" cy="55" r="1.2" fill="#fff"/><circle cx="20" cy="60" r="1" fill="#fff"/>
    <path d="M0 120 Q60 95 130 115 T300 105 V150 H0 Z" fill="#3C3660"/>
    <rect x="45" y="70" width="5" height="45" rx="2" fill="#5C4A2E"/><circle cx="47" cy="65" r="16" fill="#3C8055"/>
    <path d="M0 135 Q80 118 160 133 T300 128 V150 H0Z" fill="#2A2650"/>
  </svg>`,
  sahaba: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scSahSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#E8A45C"/><stop offset="100%" stop-color="#F3D08A"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scSahSky)"/>
    <circle cx="150" cy="90" r="30" fill="#F6E2A8"/>
    <path d="M0 115 Q80 95 160 112 T300 100 V150 H0 Z" fill="#D9A441"/>
    <path d="M110 112 L150 70 L190 112Z" fill="#F5EDE0"/><path d="M150 70v42" stroke="#C9922A" stroke-width="1.5"/>
    <rect x="147" y="55" width="1.6" height="16" fill="#8B5A2B"/><path d="M148.6 55 165 60 148.6 65Z" fill="#C0392B"/>
    <path d="M0 135 Q100 122 200 133 T300 128 V150 H0Z" fill="#C1694F" opacity=".5"/>
  </svg>`,
  tabiin: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scTabSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#1B2440"/><stop offset="100%" stop-color="#2E3A66"/></linearGradient>
    <radialGradient id="scTabGlow" cx="50%" cy="50%" r="60%"><stop offset="0%" stop-color="#FDE58B"/><stop offset="100%" stop-color="#F2C464" stop-opacity="0"/></radialGradient></defs>
    <rect width="300" height="150" fill="url(#scTabSky)"/>
    <circle cx="60" cy="30" r="1.4" fill="#fff"/><circle cx="230" cy="40" r="1.2" fill="#fff"/><circle cx="180" cy="20" r="1" fill="#fff"/>
    <circle cx="150" cy="80" r="45" fill="url(#scTabGlow)"/>
    <path d="M140 60h6v40h-6Z" fill="#3A2A1C"/><ellipse cx="143" cy="58" rx="10" ry="6" fill="#F2C464"/>
    <path d="M100 115h60l-6 15h-48Z" fill="#6C5A96"/><path d="M105 115 L110 90 L190 90 L195 115Z" fill="#4E3E72"/>
    <path d="M0 135 Q100 122 200 133 T300 128 V150 H0Z" fill="#232B4D"/>
  </svg>`,
  akhlaq: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scAkhSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#BFE3F5"/><stop offset="100%" stop-color="#EAF6FA"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scAkhSky)"/>
    <circle cx="250" cy="35" r="20" fill="#F2C464"/>
    <path d="M0 120 Q100 105 200 118 T300 110 V150 H0Z" fill="#8FBFA0"/>
    <rect x="60" y="80" width="40" height="35" fill="#F5EDE0"/><path d="M55 80 80 60 105 80Z" fill="#C1694F"/>
    <rect x="160" y="70" width="45" height="45" fill="#FBF6EA"/><path d="M154 70 182 48 210 70Z" fill="#4A5FA8"/>
    <path d="M130 55c-8-8-22-3-22 8 0 12 22 22 22 22s22-10 22-22c0-11-14-16-22-8Z" fill="#E0817A"/>
  </svg>`,
  birr: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scBirrSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FDF3E0"/><stop offset="100%" stop-color="#F6E2A8"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scBirrSky)"/>
    <circle cx="55" cy="35" r="16" fill="#F2C464"/>
    <path d="M0 122 Q100 108 200 120 T300 112 V150 H0Z" fill="#8FBFA0"/>
    <rect x="120" y="80" width="60" height="38" fill="#F5EDE0"/><path d="M112 80 150 52 188 80Z" fill="#C1694F"/>
    <rect x="142" y="98" width="18" height="20" fill="#8B5A2B"/>
    <path d="M150 65c-8-8-22-3-22 8 0 12 22 22 22 22s22-10 22-22c0-11-14-16-22-8Z" fill="#E0817A"/>
    <circle cx="230" cy="120" r="6" fill="#D9A441"/><circle cx="245" cy="128" r="5" fill="#C1694F"/><circle cx="220" cy="130" r="5" fill="#4A5FA8"/>
  </svg>`,
  sidq: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scSidqSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#D9EDD9"/><stop offset="100%" stop-color="#F6F1DE"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scSidqSky)"/>
    <path d="M0 120 Q100 108 200 118 T300 112 V150 H0Z" fill="#E6D2A0"/>
    <rect x="90" y="70" width="120" height="8" fill="#8B5A2B"/><rect x="146" y="45" width="8" height="30" fill="#8B5A2B"/>
    <path d="M90 74 L70 100 L110 100Z" fill="none" stroke="#3A2A1C" stroke-width="2"/>
    <path d="M210 74 L190 100 L230 100Z" fill="none" stroke="#3A2A1C" stroke-width="2"/>
    <circle cx="90" cy="74" r="3" fill="#D9A441"/><circle cx="210" cy="74" r="3" fill="#D9A441"/>
    <circle cx="150" cy="35" r="14" fill="#F2C464"/>
  </svg>`,
  amanah: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scAmanSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#DDE6F5"/><stop offset="100%" stop-color="#F3EFE0"/></linearGradient>
    <linearGradient id="scAmanChest" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#C9922A"/><stop offset="100%" stop-color="#8B5A2B"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scAmanSky)"/>
    <path d="M0 120 Q100 108 200 118 T300 112 V150 H0Z" fill="#8FBFA0"/>
    <rect x="105" y="85" width="90" height="35" rx="4" fill="url(#scAmanChest)"/>
    <path d="M105 85q45-18 90 0" fill="none" stroke="#8B5A2B" stroke-width="6"/>
    <circle cx="150" cy="95" r="6" fill="#3A2A1C"/>
    <circle cx="150" cy="45" r="12" fill="#F2C464"/><rect x="147" y="55" width="6" height="14" fill="#F2C464"/>
  </svg>`,
  shajaah: `<svg viewBox="0 0 300 150">
    <defs><linearGradient id="scShajSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#E0664D"/><stop offset="100%" stop-color="#F2C464"/></linearGradient></defs>
    <rect width="300" height="150" fill="url(#scShajSky)"/>
    <circle cx="150" cy="55" r="24" fill="#FDE58B"/>
    <path d="M0 130 L60 60 L100 100 L150 40 L210 100 L250 65 L300 130Z" fill="#8B5A2B" opacity=".85"/>
    <path d="M150 40v-22" stroke="#3A2A1C" stroke-width="2"/><path d="M150 18 168 24 150 30Z" fill="#3C8055"/>
    <path d="M0 140 Q100 130 200 138 T300 134 V150 H0Z" fill="#C1694F"/>
  </svg>`,
};
function storyCoverScene(catId) { return STORY_COVER_SCENES[catId] || STORY_COVER_SCENES.akhlaq; }

// ============================== لوحات "القصة المصوّرة" داخل نص القصة (أسلوب كوميك) ==============================
// بما أن التطبيق يعمل بالكامل بدون إنترنت ولا صور خارجية (خوفًا من مشاكل حقوق الملكية)، نبني لوحات كوميك
// متعددة ومتنوعة الشكل من نفس مشاهد SVG المرسومة يدويًا لكل تصنيف، بدل تكرار نفس الغلاف الثابت فقط.
// كل لوحة تُعرض داخل إطار كوميك سميك أبيض، بزاوية ميل بسيطة ولمعة زخرفية في الزاوية، وتلوين مختلف قليلاً
// عن سابقتها (hue-rotate) وانعكاس أفقي أحيانًا، لتبدو كأنها "كادرات" متتابعة من نفس القصة لا صورة واحدة مكرّرة.
const COMIC_ACCENT_ICONS = ['sparkle', 'star', 'heart', 'moon', 'crescentStar', 'bookOpenStar'];
const COMIC_TILTS = [-3, 2, -2, 3, -4, 1];
function comicPanel(catId, seed) {
  const scene = storyCoverScene(catId);
  const hue = ((seed * 53) % 50) - 25;
  const flip = seed % 3 === 2;
  const tilt = COMIC_TILTS[seed % COMIC_TILTS.length];
  const accent = COMIC_ACCENT_ICONS[seed % COMIC_ACCENT_ICONS.length];
  return `
  <div class="comic-panel" style="transform:rotate(${tilt}deg)">
    <div class="comic-panel-scene" style="filter:hue-rotate(${hue}deg)${flip ? ';transform:scaleX(-1)' : ''}">${scene}</div>
    <span class="comic-panel-accent">${icon(accent)}</span>
  </div>`;
}

// ============================== رسوم الحيوان الأليف الكبيرة والمفصّلة (لعرض الحيوان في شاشته الخاصة) ==============================
// هذه ليست صورًا فوتوغرافية حقيقية (لا تتوفر لدينا أداة لإنتاج صور واقعية داخل هذا التطبيق بلا إنترنت وبلا حقوق ملكية)،
// لكنها رسوم أكثر تفصيلاً وظلالًا وتدرجات لونية من الأيقونة الصغيرة، لتبدو أقرب لحيوان حقيقي بأسلوب رسم لطيف
const BIG_PET_ICONS = {
  bird: `<svg viewBox="0 0 100 100">
    <defs>
      <linearGradient id="bpBirdBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#5FA3C9"/><stop offset="100%" stop-color="#3C7BA0"/></linearGradient>
      <linearGradient id="bpBirdBelly" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FBF6EA"/><stop offset="100%" stop-color="#E9DBB8"/></linearGradient>
    </defs>
    <ellipse cx="50" cy="80" rx="26" ry="5" fill="rgba(0,0,0,.12)"/>
    <path d="M30 55c0-16 9-28 20-28s20 12 20 28-9 24-20 24-20-8-20-24Z" fill="url(#bpBirdBody)"/>
    <path d="M38 60c0-10 5.5-17 12-17s12 7 12 17-5.5 15-12 15-12-5-12-15Z" fill="url(#bpBirdBelly)"/>
    <path d="M50 27c4-6 12-8 17-5-2 4-3 7-3 10" fill="#3C7BA0"/>
    <circle cx="58" cy="38" r="3" fill="#20303B"/><circle cx="57" cy="37" r="1" fill="#fff"/>
    <path d="M68 40c5-1 9 1 10 4-4 1-7 0-10-4Z" fill="#D9A441"/>
    <path d="M35 66c-8 3-13 9-12 16 6-1 12-5 15-11M65 66c8 3 13 9 12 16-6-1-12-5-15-11" fill="#3C7BA0" opacity=".8"/>
    <path d="M42 78l2 8M50 79l0 9M58 78l-2 8" stroke="#D9A441" stroke-width="2.4" stroke-linecap="round"/>
  </svg>`,
  rabbit: `<svg viewBox="0 0 100 100">
    <defs><linearGradient id="bpRabBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#F5EDE0"/><stop offset="100%" stop-color="#DCC9A8"/></linearGradient></defs>
    <ellipse cx="50" cy="82" rx="26" ry="5" fill="rgba(0,0,0,.12)"/>
    <path d="M38 30c-4-12-2-24 4-27 4 8 5 18 3 26M62 30c4-12 2-24-4-27-4 8-5 18-3 26" fill="url(#bpRabBody)" stroke="#C9A24B" stroke-width="1"/>
    <ellipse cx="40" cy="18" rx="4" ry="9" fill="#E0A45C" opacity=".6"/>
    <ellipse cx="60" cy="18" rx="4" ry="9" fill="#E0A45C" opacity=".6"/>
    <circle cx="50" cy="55" r="26" fill="url(#bpRabBody)"/>
    <circle cx="42" cy="50" r="3" fill="#3A2A1C"/><circle cx="58" cy="50" r="3" fill="#3A2A1C"/>
    <circle cx="41" cy="48.5" r="1" fill="#fff"/><circle cx="57" cy="48.5" r="1" fill="#fff"/>
    <ellipse cx="50" cy="58" rx="3.4" ry="2.4" fill="#E0817A"/>
    <path d="M45 62c2.5 2.5 7.5 2.5 10 0" stroke="#8B5A2B" stroke-width="1.6" fill="none" stroke-linecap="round"/>
    <ellipse cx="34" cy="60" rx="5" ry="3.5" fill="#F3A6A0" opacity=".6"/>
    <ellipse cx="66" cy="60" rx="5" ry="3.5" fill="#F3A6A0" opacity=".6"/>
    <path d="M30 65c-6 2-10 7-9 13 5-1 9-4 12-9M70 65c6 2 10 7 9 13-5-1-9-4-12-9" fill="url(#bpRabBody)"/>
    <circle cx="50" cy="80" r="7" fill="#fff"/>
  </svg>`,
  cat: `<svg viewBox="0 0 100 100">
    <defs><linearGradient id="bpCatBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#E0A45C"/><stop offset="100%" stop-color="#C1694F"/></linearGradient></defs>
    <ellipse cx="50" cy="83" rx="26" ry="5" fill="rgba(0,0,0,.12)"/>
    <path d="M32 32 24 14l16 10Z" fill="url(#bpCatBody)"/>
    <path d="M68 32 76 14 60 24Z" fill="url(#bpCatBody)"/>
    <circle cx="50" cy="52" r="27" fill="url(#bpCatBody)"/>
    <path d="M50 30c-15 0-27 10-27 24" fill="none"/>
    <circle cx="41" cy="48" r="3.2" fill="#3A2A1C"/><circle cx="59" cy="48" r="3.2" fill="#3A2A1C"/>
    <circle cx="40" cy="46.5" r="1" fill="#fff"/><circle cx="58" cy="46.5" r="1" fill="#fff"/>
    <path d="M50 55v3" stroke="#3A2A1C" stroke-width="2" stroke-linecap="round"/>
    <path d="M23 55h-12M23 59h-13M77 55h12M77 59h13M44 61c3.5 3.5 8.5 3.5 12 0" stroke="#3A2A1C" stroke-width="1.6" fill="none" stroke-linecap="round"/>
    <path d="M30 70c-9 4-14 12-11 20 6-2 12-8 15-16M70 70c9 4 14 12 11 20-6-2-12-8-15-16" fill="url(#bpCatBody)"/>
  </svg>`,
  butterfly: `<svg viewBox="0 0 100 100">
    <defs>
      <linearGradient id="bpButL" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6C5A96"/><stop offset="100%" stop-color="#4A5FA8"/></linearGradient>
      <linearGradient id="bpButR" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#C1694F"/><stop offset="100%" stop-color="#D9A441"/></linearGradient>
    </defs>
    <rect x="47.5" y="25" width="5" height="55" rx="2.5" fill="#3A2A1C"/>
    <path d="M50 34c-6-16-26-22-36-12-9 9-4 26 8 31-9 4-13 15-6 23 7 8 20 3 25-9" fill="url(#bpButL)"/>
    <path d="M50 34c6-16 26-22 36-12 9 9 4 26-8 31 9 4 13 15 6 23-7 8-20 3-25-9" fill="url(#bpButR)"/>
    <circle cx="27" cy="30" r="5" fill="#FBF6EA" opacity=".6"/><circle cx="73" cy="30" r="5" fill="#FBF6EA" opacity=".6"/>
    <circle cx="24" cy="58" r="4" fill="#FBF6EA" opacity=".6"/><circle cx="76" cy="58" r="4" fill="#FBF6EA" opacity=".6"/>
    <path d="M46 24 40 12M54 24 60 12" stroke="#3A2A1C" stroke-width="2" stroke-linecap="round"/>
  </svg>`,
  turtle: `<svg viewBox="0 0 100 100">
    <defs><radialGradient id="bpTurShell" cx="35%" cy="30%" r="75%"><stop offset="0%" stop-color="#6BAE86"/><stop offset="100%" stop-color="#2F6B44"/></radialGradient></defs>
    <ellipse cx="50" cy="82" rx="28" ry="5" fill="rgba(0,0,0,.12)"/>
    <ellipse cx="50" cy="55" rx="34" ry="24" fill="url(#bpTurShell)" stroke="#215538" stroke-width="1.5"/>
    <path d="M50 33v44M22 55h56M30 40l40 30M70 40 30 70" stroke="#215538" stroke-width="1.4" opacity=".6"/>
    <circle cx="82" cy="52" r="10" fill="#8FBFA0"/>
    <circle cx="88" cy="49" r="2" fill="#20303B"/>
    <path d="M28 70c-6 4-9 10-7 16 5-1 10-6 12-13M20 60c-7 1-12 6-12 12 5 1 10-2 13-8" fill="#8FBFA0"/>
    <path d="M72 70c6 4 9 10 7 16-5-1-10-6-12-13" fill="#8FBFA0"/>
  </svg>`,
};
function bigPetIcon(id) { return BIG_PET_ICONS[id] || ''; }

// ============================== شجرة الحسنات: شجرة برسم إجرائي، كل فرع يكبر حسب عدد الأعمال في تصنيفه ==============================
const HASANAH_BRANCHES = [
  { key: 'salah', label: 'الصلاة', color: '#3A8FC9', light: '#6FB3E0', dark: '#1F5C85', fruit: '#E0A03A', angle: -55, x: 90, y: 70 },
  { key: 'quran', label: 'القرآن', color: '#2F6B44', light: '#5C9E77', dark: '#1B4A2E', fruit: '#C0392B', angle: -125, x: 210, y: 70 },
  { key: 'dhikr', label: 'الأذكار', color: '#D9A441', light: '#EFC873', dark: '#A87A25', fruit: '#C0392B', angle: -25, x: 60, y: 110 },
  { key: 'kindness', label: 'الخير والبر', color: '#C1694F', light: '#DD9478', dark: '#8F4630', fruit: '#E0A03A', angle: -155, x: 240, y: 110 },
];
function renderHasanahTreeSvg(counts, potSkin) {
  const pot = potSkin || { c1: '#8B6F47', c2: '#6B4A2E' };
  let defs = `
    <radialGradient id="trunkGrad" cx="30%" cy="20%" r="90%">
      <stop offset="0%" stop-color="#9C7B52"/><stop offset="60%" stop-color="#6B4A2E"/><stop offset="100%" stop-color="#4A3220"/>
    </radialGradient>`;
  const branches = HASANAH_BRANCHES.map((b, bi) => {
    const n = Math.min(counts[b.key] || 0, 14);
    const rad = b.angle * Math.PI / 180;
    const len = 50 + n * 3.2;
    const ex = 150 + Math.cos(rad) * len;
    const ey = 208 + Math.sin(rad) * len;
    const canopyR = 26 + n * 1.6;
    const gradId = `leafGrad${bi}`;
    defs += `
    <radialGradient id="${gradId}" cx="35%" cy="30%" r="75%">
      <stop offset="0%" stop-color="${b.light || b.color}"/><stop offset="70%" stop-color="${b.color}"/><stop offset="100%" stop-color="${b.dark || b.color}"/>
    </radialGradient>`;
    // عناقيد أوراق متراكبة بأحجام مختلفة تعطي إحساس كثافة طبيعية بدل دائرة واحدة مسطحة
    const blobs = [
      { dx: 0, dy: 0, r: canopyR },
      { dx: -canopyR * 0.55, dy: canopyR * 0.25, r: canopyR * 0.68 },
      { dx: canopyR * 0.55, dy: canopyR * 0.2, r: canopyR * 0.65 },
      { dx: 0, dy: -canopyR * 0.5, r: canopyR * 0.6 },
    ].map(o => `<circle cx="${(ex + o.dx).toFixed(1)}" cy="${(ey + o.dy).toFixed(1)}" r="${o.r.toFixed(1)}" fill="url(#${gradId})"/>`).join('');
    // ثمار صغيرة بلمعة بيضاء، عددها يزيد مع النشاط في هذا الفرع
    const fruitCount = Math.min(n, 8);
    let fruits = '';
    for (let i = 0; i < fruitCount; i++) {
      const fa = (i / fruitCount) * Math.PI * 2;
      const fr = canopyR * 0.85;
      const fx = ex + Math.cos(fa) * fr;
      const fy = ey + Math.sin(fa) * fr * 0.8 + canopyR * 0.35;
      fruits += `<circle cx="${fx.toFixed(1)}" cy="${fy.toFixed(1)}" r="4.2" fill="${b.fruit || '#C0392B'}"/><circle cx="${(fx-1.3).toFixed(1)}" cy="${(fy-1.3).toFixed(1)}" r="1.2" fill="#fff" opacity=".8"/>`;
    }
    const branchLimb = `<path d="M150 205 Q${((150+ex)/2).toFixed(1)} ${((205+ey)/2 - 8).toFixed(1)} ${ex.toFixed(1)} ${ey.toFixed(1)}" stroke="#5A3E26" stroke-width="6" fill="none" stroke-linecap="round"/>`;
    return branchLimb + blobs + fruits;
  }).join('');
  return `<svg viewBox="0 0 300 245" xmlns="http://www.w3.org/2000/svg">
    <defs>${defs}</defs>
    <ellipse cx="150" cy="236" rx="76" ry="7" fill="rgba(0,0,0,.15)"/>
    <path d="M108 213 L119 238 Q150 245 181 238 L192 213 Z" fill="${pot.c2}"/>
    <path d="M106 213 Q150 222 194 213 L192 217 Q150 226 108 217 Z" fill="${pot.c1}"/>
    <path d="M141 205 Q136 165 140 145 Q143 125 148 108 L152 108 Q155 128 158 148 Q161 168 159 205 Z" fill="url(#trunkGrad)"/>
    <path d="M146 195 Q144 165 147 140" stroke="#4A3220" stroke-width="1.4" fill="none" opacity=".5"/>
    <path d="M154 190 Q156 160 152 135" stroke="#4A3220" stroke-width="1.4" fill="none" opacity=".5"/>
    ${branches}
  </svg>`;
}

// ---- أيقونات مضافة في الإصدار 4.1 ----
ICONS.download = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="m7.5 11 4.5 4.5 4.5-4.5"/><path d="M5 19.5h14"/></svg>`;
ICONS.whatsapp = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20l1.3-4.3A8.2 8.2 0 1 1 8.5 18.8L4 20Z"/><path d="M9.3 8.9c.2 2.4 2.4 4.6 4.8 4.8l1.1-1.2-1.9-.9-.9.7a4.3 4.3 0 0 1-1.8-1.8l.7-.9-.9-1.9-1.1 1.2Z"/></svg>`;

// ---- إصلاح: أيقونات عادية (غير أيقونات التاب) كانت ناقصة فترجع افتراضيًا لأيقونة ✨ بدل أيقونتها الحقيقية ----
ICONS.asmaHusna = TAB_ICONS.asmaHusna;
ICONS.contributors = TAB_ICONS.contributors;
ICONS.diamondVault = TAB_ICONS.diamondVault;
ICONS.halalScanner = TAB_ICONS.halalScanner;
ICONS.inviteFriend = TAB_ICONS.inviteFriend;
ICONS.kaffara = TAB_ICONS.kaffara;
ICONS.otherServices = TAB_ICONS.otherServices;
ICONS.safeVideos = TAB_ICONS.safeVideos;
ICONS.sunnah = TAB_ICONS.sunnah;
ICONS.tasbih = TAB_ICONS.tasbih;
ICONS.clock = ICONS.hourglass;

TAB_ICONS.calendar = `<svg viewBox="0 0 32 32">
    <defs><linearGradient id="tgCalHead" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#4C8A63"/><stop offset="100%" stop-color="#2F6B44"/></linearGradient></defs>
    <ellipse cx="16" cy="29" rx="10" ry="2" fill="rgba(0,0,0,.12)"/>
    <rect x="4" y="6" width="24" height="21" rx="4" fill="#FBF6EA" stroke="#D9A441" stroke-width="1.6"/>
    <path d="M4 10a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v3H4Z" fill="url(#tgCalHead)"/>
    <rect x="10" y="3" width="2.6" height="6" rx="1.3" fill="#8B6F47"/><rect x="19.4" y="3" width="2.6" height="6" rx="1.3" fill="#8B6F47"/>
    <path d="M20.5 15.2a4.6 4.6 0 1 0 2.4 8.1 3.7 3.7 0 0 1-2.4-8.1Z" fill="#D9A441"/>
    <circle cx="10" cy="19" r="1.3" fill="#2F6B44"/><circle cx="10" cy="23.4" r="1.3" fill="#2F6B44"/><circle cx="14.6" cy="19" r="1.3" fill="#2F6B44"/>
  </svg>`;
