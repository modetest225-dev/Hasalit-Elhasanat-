// ============================================================================
// تسجيل الدخول بجوجل واسترجاع الحساب من أي جهاز (Firebase Auth + Firestore)
// ============================================================================
// التصميم مقصود منه: التطبيق يفضل شغال بالكامل بدون إنترنت وبدون تسجيل دخول
// (وضع "ضيف")، وتسجيل الدخول ميزة اختيارية إضافية فقط لمن يريد مزامنة تقدمه
// بين أكثر من جهاز. أي خطأ في الشبكة أو في إعدادات Firebase لا يمنع التطبيق
// من العمل، فقط ميزة المزامنة هي التي تتعطل.

const AUTH_PROMPTED_KEY = 'hasana_auth_prompted_v1';
let authUser = null;
let authFirestore = null;
let authAvailable = false;
let authSyncTimer = null;

function isFirebaseConfigured() {
  return typeof firebaseConfig !== 'undefined' &&
    firebaseConfig.apiKey && !String(firebaseConfig.apiKey).includes('PASTE_YOUR');
}

function initAuth() {
  if (!isFirebaseConfigured() || typeof firebase === 'undefined') {
    authAvailable = false;
    renderAuthGateIfNeeded();
    return;
  }
  try {
    firebase.initializeApp(firebaseConfig);
    authFirestore = firebase.firestore();
    authAvailable = true;
    firebase.auth().onAuthStateChanged(user => {
      authUser = user;
      if (user) onSignedIn(user);
      renderAuthUI();
    });
  } catch (e) {
    console.error('تعذر تهيئة تسجيل الدخول، سيعمل التطبيق كضيف', e);
    authAvailable = false;
  }
  renderAuthGateIfNeeded();
}

// ============================== بوابة تسجيل الدخول (تظهر مرة واحدة فقط عند أول استخدام) ==============================
let authGateTab = 'login'; // 'login' | 'register'
const FAKE_ACCOUNT_KEY = 'hasana_local_account_v1';

function renderAuthGateIfNeeded() {
  const root = document.getElementById('auth-root');
  if (!root) return;
  const alreadyPrompted = localStorage.getItem(AUTH_PROMPTED_KEY);
  if (alreadyPrompted) { root.innerHTML = ''; return; }
  const isLogin = authGateTab === 'login';
  root.innerHTML = `
  <div class="modal-overlay" style="z-index:998">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <h1 class="title">مرحبًا بك! 👋</h1>
      <p class="muted mt8">سجّل دخولك عشان تقدر تسترجع تقدّمك ونقاطك في أي وقت</p>

      <div class="story-filter-row center mt12">
        <button class="story-filter-btn ${isLogin ? 'active' : ''}" data-action="auth-gate-tab" data-tab="login">تسجيل الدخول</button>
        <button class="story-filter-btn ${!isLogin ? 'active' : ''}" data-action="auth-gate-tab" data-tab="register">حساب جديد</button>
      </div>

      ${isLogin ? `
        <input type="text" id="auth-email" placeholder="البريد الإلكتروني" class="mt12" />
        <input type="password" id="auth-password" placeholder="كلمة المرور" class="mt8" />
        <button class="btn block mt8" data-action="auth-local-login">${icon('check')} تسجيل الدخول</button>
      ` : `
        <input type="text" id="auth-name" placeholder="اسم الطفل" class="mt12" />
        <input type="text" id="auth-email" placeholder="البريد الإلكتروني" class="mt8" />
        <input type="password" id="auth-password" placeholder="كلمة المرور" class="mt8" />
        <button class="btn block mt8" data-action="auth-local-register">${icon('sparkle')} إنشاء الحساب</button>
      `}

      <div class="row center mt16" style="gap:8px"><div style="flex:1;height:1px;background:var(--card-border)"></div><span class="muted small">أو</span><div style="flex:1;height:1px;background:var(--card-border)"></div></div>

      ${authAvailable
        ? `<button class="btn secondary block mt12" data-action="auth-google-signin">${icon('sparkle')} تسجيل الدخول بجوجل</button>`
        : ''}
      <button class="btn secondary block mt8" data-action="auth-continue-guest">متابعة بدون تسجيل (كضيف)</button>
    </div>
  </div>`;
  if (typeof bindContainer === 'function') bindContainer(root);
}

function switchAuthGateTab(tab) {
  authGateTab = tab;
  renderAuthGateIfNeeded();
}

// حساب محلي بسيط (وهمي) للاسم والدخول السريع بدون اتصال إنترنت - بياناته لا تُزامَن بين الأجهزة
// (على عكس تسجيل الدخول بجوجل الحقيقي أعلاه الذي يزامن عبر Firestore)
function localFakeRegister() {
  const name = (document.getElementById('auth-name') || {}).value || '';
  const email = (document.getElementById('auth-email') || {}).value || '';
  const password = (document.getElementById('auth-password') || {}).value || '';
  if (!name.trim() || !email.trim() || !password.trim()) {
    if (typeof showMessageCard === 'function') showMessageCard('warning', 'أكمل البيانات', 'من فضلك املأ كل الحقول'); return;
  }
  localStorage.setItem(FAKE_ACCOUNT_KEY, JSON.stringify({ name: name.trim(), email: email.trim() }));
  if (typeof state !== 'undefined') { state.childName = name.trim(); if (typeof saveState === 'function') saveState(); }
  dismissAuthGate();
  if (typeof render === 'function') render();
}

function localFakeLogin() {
  const email = (document.getElementById('auth-email') || {}).value || '';
  const password = (document.getElementById('auth-password') || {}).value || '';
  if (!email.trim() || !password.trim()) {
    if (typeof showMessageCard === 'function') showMessageCard('warning', 'أكمل البيانات', 'من فضلك اكتب البريد الإلكتروني وكلمة المرور'); return;
  }
  const saved = localStorage.getItem(FAKE_ACCOUNT_KEY);
  if (saved) {
    const acc = JSON.parse(saved);
    if (typeof state !== 'undefined' && acc.name) { state.childName = acc.name; if (typeof saveState === 'function') saveState(); }
  }
  dismissAuthGate();
  if (typeof render === 'function') render();
}

function dismissAuthGate() {
  localStorage.setItem(AUTH_PROMPTED_KEY, '1');
  const root = document.getElementById('auth-root');
  if (root) root.innerHTML = '';
}

// ============================== تسجيل الدخول / الخروج ==============================
function googleSignIn() {
  if (!authAvailable) return;
  const provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider)
    .then(() => dismissAuthGate())
    .catch(e => {
      console.error('فشل تسجيل الدخول', e);
      if (typeof showMessageCard === 'function') showMessageCard('error', 'تعذّر تسجيل الدخول', 'تأكد من اتصالك بالإنترنت وحاول مرة أخرى');
    });
}

function googleSignOut() {
  if (!authAvailable) return;
  firebase.auth().signOut();
}

// ============================== المزامنة مع Firestore ==============================
// عند تسجيل الدخول لأول مرة: لو فيه بيانات محفوظة في السحابة، نستردّها (استرجاع الحساب).
// لو مفيش، نرفع البيانات المحلية الحالية كأول نسخة احتياطية للحساب.
function onSignedIn(user) {
  if (!authFirestore) return;
  authFirestore.collection('users').doc(user.uid).get()
    .then(doc => {
      if (doc.exists && doc.data() && doc.data().state) {
        window.applyCloudState(doc.data().state);
      } else if (typeof state !== 'undefined') {
        authFirestore.collection('users').doc(user.uid).set({ state, updatedAt: Date.now() });
      }
    })
    .catch(e => console.error('تعذرت مزامنة البيانات مع الحساب', e));
}

// تُستدعى تلقائيًا من app.js (saveState) في كل مرة تتغير فيها بيانات الطفل
window.onStateSaved = function(currentState) {
  if (!authUser || !authFirestore) return;
  clearTimeout(authSyncTimer);
  authSyncTimer = setTimeout(() => {
    authFirestore.collection('users').doc(authUser.uid)
      .set({ state: currentState, updatedAt: Date.now() })
      .catch(e => console.error('تعذر حفظ نسخة احتياطية في السحابة', e));
  }, 2000); // تجميع الحفظات المتكررة كل 2 ثانية بدل رفع كل تغيير فورًا
};

// ============================== واجهة تسجيل الدخول/الخروج داخل صفحة الإعدادات ==============================
function renderAuthAccountCard() {
  if (!authAvailable) {
    return `<p class="muted small">تسجيل الدخول غير مفعّل حاليًا على هذا التطبيق.</p>`;
  }
  if (authUser) {
    return `
    <div class="row">
      ${authUser.photoURL ? `<img src="${authUser.photoURL}" style="width:36px;height:36px;border-radius:50%" />` : ''}
      <div><b>${authUser.displayName || 'مستخدم مسجّل'}</b><div class="muted small">${authUser.email || ''}</div></div>
    </div>
    <p class="muted small mt8">بياناتك محفوظة تلقائيًا وهتقدر تستردها من أي جهاز تاني بنفس الحساب</p>
    <button class="btn secondary block mt8" data-action="auth-sign-out">تسجيل الخروج</button>`;
  }
  return `
  <p class="muted small mb8">أنت في وضع الضيف حاليًا، بياناتك محفوظة على هذا الجهاز فقط</p>
  <button class="btn block" data-action="auth-google-signin">${icon('sparkle')} تسجيل الدخول بجوجل</button>`;
}

function renderAuthUI() {
  if (typeof render === 'function' && typeof currentTab !== 'undefined') render();
}

document.addEventListener('DOMContentLoaded', () => setTimeout(initAuth, 0));
