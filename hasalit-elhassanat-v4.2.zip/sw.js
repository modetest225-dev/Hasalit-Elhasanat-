// ============================================================================
// Service Worker لتطبيق حصالة الحسنات
// ============================================================================
// السبب الرئيسي لوجود هذا الملف: إشعارات النظام (اللي تظهر في شريط الإشعارات
// العلوي بالموبايل) لازم تُعرض عن طريق registration.showNotification() من
// service worker حقيقي، مش عن طريق new Notification() من صفحة الويب مباشرة —
// الطريقة التانية دي أحيانًا بتشتغل بس التطبيق مفتوح وفي المقدمة، والطريقة
// الأولى دي اللي بتضمن ظهور الإشعار في شريط النظام فعليًا زي أي تطبيق تاني.

const CACHE_NAME = 'hasana-cache-v12'; // تم رفعه بعد التقويم الهجري وإعادة تصميم الإعدادات وشاشة التحديث المتكسّرة
const CORE_ASSETS = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './data.js',
  './icons.js',
  './hijri.js',
  './i18n.js',
  './i18n-en.js',
  './auth.js',
  './firebase-config.js',
  './manifest.webmanifest',
  './favicon.ico',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/badge-96.png',
  './icons/badge-192.png',
  './icons/apple-touch-icon.png',
  './quran_index.pdf',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// إستراتيجية "الكاش أولًا مع تحديث في الخلفية": يعرض النسخة المخزّنة فورًا (تحميل فوري حتى بدون إنترنت)،
// وفي نفس الوقت يجيب نسخة جديدة من الشبكة لو الاتصال متاح ويحدّث الكاش بيها لمرة الاستخدام الجاية.
// لا يتدخل إطلاقًا في طلبات المواقع الخارجية (خطوط جوجل، واجهات الصلاة والقرآن، الفيديوهات...) ليعمل كل منها بشكل طبيعي.
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  let url;
  try { url = new URL(req.url); } catch (e) { return; }
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req).then((res) => {
        if (res && res.status === 200) {
          const resClone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone)).catch(() => {});
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});

// تفعيل النسخة الجديدة فورًا عند ضغط المستخدم على "تحديث الآن"
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

// يستقبل طلب عرض إشعار من صفحة التطبيق (app.js) ويعرضه في شريط إشعارات النظام فعليًا
self.addEventListener('message', (event) => {
  const data = event.data || {};
  if (data.type === 'SHOW_NOTIFICATION') {
    self.registration.showNotification(data.title || 'حصالة الحسنات', {
      body: data.body || '',
      icon: './icons/icon-192.png',
      badge: './icons/badge-96.png',
      dir: 'rtl',
      lang: 'ar',
      vibrate: [200, 100, 200],
      tag: data.tag || undefined,
    });
  }
});

// عند الضغط على الإشعار: يفتح التطبيق (أو يركّز عليه لو مفتوح بالفعل)
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const existing = clientsArr.find((c) => 'focus' in c);
      if (existing) return existing.focus();
      return self.clients.openWindow('./');
    })
  );
});
