// ==========================================================================
// حصالة الحسنات - تطبيق كامل بدون بناء (Vanilla JS) - يعمل بفتح index.html مباشرة
// صنع بواسطة محمد حمدي
// ==========================================================================

const STORAGE_KEY = 'hasana_state_v1';
const APP_VERSION = '4.1';

function todayStr() { return new Date().toLocaleDateString('en-CA'); }
function shuffle(arr) { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
// تهريب أي نص يكتبه المستخدم (أو يجي من مصدر خارجي) قبل إدراجه في HTML، لمنع كسر الصفحة أو حقن أكواد
function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
// اسم الطفل: لازم يحتوي حروف عربي/إنجليزي حقيقية بس (مفيش أرقام/رموز/إيموجي/HTML)، وطوله بين حرفين و20 حرف
function sanitizeChildName(raw) {
  let v = String(raw || '').trim().replace(/<[^>]*>/g, '');
  if (!/[a-zA-Zأ-ي]/.test(v)) return null;
  v = v.replace(/[^a-zA-Zأ-يءآأؤإئ\s\-]/g, '').trim().replace(/\s+/g, ' ');
  if (v.length < 2) return null;
  if (v.length > 20) v = v.slice(0, 20).trim();
  return v || null;
}
function getWeekKey() {
  const d = new Date();
  const onejan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d - onejan) / 86400000) + onejan.getDay() + 1) / 7);
  return d.getFullYear() + '-W' + week;
}
function getMonthKey() {
  const d = new Date();
  return d.getFullYear() + '-' + (d.getMonth() + 7);
}

function defaultState() {
  return {
    childName: 'بطل الحسنات',
    points: 0,
    totalEarnedPoints: 0,
    darkMode: false,
    parentPin: '',
    tasksPending: {},   // taskId -> dateStr (الطفل قال إنه عمل المهمة، بانتظار تأكيد الوالدين)
    tasksApproved: {},  // taskId -> dateStr (الوالدين أكدوا، والنقاط اتصرفت)
    dailyDate: todayStr(),
    soundEnabled: true,
    customTasks: [],
    avatarsOwned: ['faris'],
    currentAvatar: 'faris',
    petsOwned: ['bird'],
    currentPet: 'bird',
    storiesOwned: [],
    eventClaimed: {},
    weeklyClaimed: {},      // weeklyEventId -> dateStr (بانتظار/تم تأكيد الوالدين)
    weeklyApproved: {},     // weeklyEventId -> dateStr
    khutbaNotes: {},        // dateStr -> النص اللي كتبه الطفل عن الخطبة
    dhikrProgress: {},      // dhikrId -> عدد مرات الضغط اليوم (يتصفر يوميًا)
    dhikrDate: todayStr(),
    // ---- إحصائيات دائمة تُستخدم لفتح الإنجازات ----
    tasksApprovedTotal: 0,
    weeklyApprovedTotal: 0,
    storiesReadIds: [],
    quizCorrectCount: 0,
    dhikrCompletedCount: 0,
    gamesWonCount: 0,
    loginStreak: 0,
    lastOpenDate: '',
    unlockedAchievements: {}, // achievementId -> dateStr
    lastDailyGiftDate: '',
    lastWheelWeek: '',
    lastMonthlyGift: '',
    tasksApprovedToday: 0,
    dailyChallengeClaimed: '',
    weeklyChallengeClaimed: '',
    childAge: '',
    childPhoto: '',
    secretMessages: [], // رسائل الطفل لصديقه السري (تصل للوالدين ليساعدوه)
    lastAdhanNotified: '',
    taskTypeApprovedEver: {}, // لتتبع أول مرة تُعتمد فيها كل نوع مهمة (لإنجازات مثل أول صلاة)
    sadaqahDone: false,
    memorizedSurahs: [], // أرقام السور التي أكّد الوالدان حفظها فعليًا
    pendingMemorizedSurahs: [], // سور علّمها الطفل كمحفوظة وبانتظار تأكيد الوالدين
    memorizedHadiths: [], // معرّفات الأحاديث التي أكّد الوالدان حفظها فعليًا
    pendingMemorizedHadiths: [], // أحاديث علّمها الطفل كمحفوظة وبانتظار تأكيد الوالدين
    appColorTheme: 'green',
    colorThemesOwned: ['green'],
    petAccessoriesOwned: [],
    currentPetAccessory: '',
    pendingEncouragements: [], // رسائل تشجيع من إخوة/أخوات على نفس الجهاز
    hasanahTree: { salah: 0, quran: 0, dhikr: 0, kindness: 0 }, // شجرة الحسنات: عدد الأعمال في كل فرع
    dedications: [], // { name, dua, date } - حسنات مُهداة لأشخاص عزيزين
    parentChallenges: [], // { id, name, points, status: 'active'|'pending'|'done' } - تحديات مخصصة من الوالدين
    certFramesOwned: ['default'], currentCertFrame: 'default', // إطارات شهادة التقدير
    potSkinsOwned: ['default'], currentPotSkin: 'default', // أواني شجرة الحسنات
    lockedFeatures: {}, // { tabId: timestampMillis } - قفل مؤقت لميزات معينة كعقوبة من الوالدين على الغش/الكذب
    penaltyLog: [], // { date, points, features, hours, reason } - سجل العقوبات لمراجعة الوالدين
    tasbihCounts: {}, // { phraseId: count } - عداد كل نوع تسبيح (تراكمي)
    currentTasbihId: 'subhanallah',
    ayahMemoryProgress: {}, // { surahId: عدد الآيات المؤكَّدة من الوالدين } - تحدي الحفظ آية بآية
    ayahMemoryPending: {}, // { surahId: العدد المطلوب اعتماده, بانتظار تأكيد الوالدين }
    petRoamingEnabled: true, // إمكانية إيقاف حركة الحيوان الأليف المتجول على الشاشة
    tasbihFreeMode: false, // وضع تسبيح حر: عداد بلا هدف محدد، بدل الدورة المستهدفة (33/99/100...)
    parentLockType: 'pin', // 'pin' | 'password' | 'pattern' - طريقة قفل دخول وضع الوالدين
    parentPassword: '', // مُجزَّأ (hash) مثل parentPin تمامًا
    parentPattern: '', // مُجزَّأ أيضًا؛ يُخزَّن كسلسلة أرقام النقاط بالترتيب قبل التجزئة
    notificationsEnabled: false, // إشعارات الهاتف عند إتمام مهمة، اقتراب حدث، أو دخول وقت الصلاة
    backgroundThemesOwned: ['default'], currentBackgroundTheme: 'default', // ألوان خلفية التطبيق وشاشة البداية
    language: 'ar', languageChosen: false, // لغة الواجهة، وهل اختار المستخدم لغته من قبل
    diamonds: 0, // عملة الألماس: تُجمع فقط عند حفظ آيات جديدة من القرآن (مؤكَّدة من الوالدين)
    diamondBadgeOwned: false, // وسام النجم الماسي (يظهر بجانب الاسم في كل مكان)
    gold: 0, // عملة الذهب: تُجمع من فعاليات نادرة جدًا أو شحن حقيقي يديره صاحب التطبيق يدويًا
    silver: 0, // عملة الفضة: نفس مصدر الذهب
    ownedFierceFrames: [], // إطارات "احتراقية" فاخرة تم فتحها بالذهب
    currentProfileFrame: null, // الإطار المفعّل حاليًا حوالين صورة البروفايل (من ownedFierceFrames)
    ownedNameGlows: [], currentNameGlow: '', // أنماط الاسم المتوهج المملوكة والمفعّل حاليًا
    supporterBadgeOwned: false, // شارة "داعم مميز" — لقب وشكل تجميلي فقط، بدون أي صلاحية إدارية حقيقية
    activeSubscription: null, // { tierId, startDate, expiresDate } — باقة الاشتراك الحالية (لو موجودة) ومعادها
    hijriOffset: 0, // ضبط التاريخ الهجري (-2 إلى +2 يوم) لمطابقة رؤية الهلال المحلية
    largeText: false, // وضع النص الكبير (إمكانية وصول)
    calmMode: false, calmPrevSound: true, // وضع الهدوء: بدون حركات ولا أصوات
    fastingDays: [], // تواريخ الأيام اللي سجّل الطفل إنه صامها
    gratitudeEntries: [], // دفتر الشكر: [{date,text}]
    streakShieldMonth: null, // آخر شهر استُخدم فيه درع المواظبة
    lastWeeklyChestDate: null, // آخر مرة استلم فيها صندوق الأسبوع (باقة ماسية فأعلى)
    lastDailyBonusDate: null, // آخر يوم استلم فيه المستخدم الهدية اليومية من باقة الاشتراك
    codeLockUntil: null, // لو مش null، التطبيق محظور مؤقتًا (8 ساعات) بسبب محاولة استخدام كود مكرر
    securityLockUntil: null, // لو مش null، التطبيق متوقف مؤقتًا (ساعة) بسبب نشاط نقر غير طبيعي (حماية من البوتات)
    selectedReciter: 'ar.alafasy', // الشيخ المختار لتلاوة القرآن (افتراضيًا مشاري العفاسي)
    usedActivationCodeHashes: [], // أكواد التفعيل (كـ hash) اللي استُخدمت على الجهاز ده قبل كده، عشان الكود منستخدمش مرتين
    ownedEvents: [], // الفعاليات الحصرية اللي تم شراؤها بالألماس
    eventBestScores: {}, // أفضل نتيجة حققها الطفل في كل فعالية (من 10)
    redeemedCoupons: [], // أكواد الكوبونات اللي تم استخدامها بالفعل (كل كود مرة واحدة فقط)
    animatedIcons: true, // تحريك الأيقونات في كل التطبيق (قابل للإيقاف من الإعدادات)
    animatedText: true, // تحريك النصوص الرئيسية في كل التطبيق (قابل للإيقاف من الإعدادات)
    zoomMode: false, // وضع تكبير الصفحة لتحسين الوضوح (إتاحة الوصول)
    namesMemoryProgress: 0, // عدد أسماء الله الحسنى المؤكَّدة من الوالدين (بالترتيب)
    namesMemoryPending: 0, // العدد المطلوب اعتماده حاليًا، بانتظار تأكيد الوالدين
    kaffaraPlans: [], // { id, label, totalDays, doneDates: [], startDate, active } - خطط صيام الكفارة
    customVideos: [], // { id: youtubeVideoId, title } - فيديوهات آمنة يضيفها الوالدين يدويًا
    hasOpenedBefore: false, // هل فتح التطبيق من قبل؟ (لتشغيل الترحيب المناسب: تعريفي أول مرة أو "أهلاً برجوعك" بعد كده)
    tutorialShown: false, // هل شاهد الجولة التعليمية التلقائية من قبل؟ (تظهر مرة واحدة فقط عند أول فتح للتطبيق)
    lastRegionalNoticeShown: '', // آخر يوم ظهر فيه تنبيه "قد تواجهوا مشكلة..." (يظهر مرة واحدة كل يوم)
    parentSecurityQ: '', parentSecurityA: '', // سؤال أمان لاسترجاع دخول الوالدين بدون مسح البيانات لو نسوا القفل
    screenLimitMinutes: 0, // الحد الأقصى لدقائق استخدام الطفل يوميًا (0 = بلا حد)
    screenTimeUsedToday: 0, screenTimeDate: '', extraTimeGrantedToday: 0, // متابعة استخدام اليوم + وقت إضافي منحه الوالد
    bedtimeStart: '', bedtimeEnd: '', // نطاق وقت النوم (HH:MM)، يقفل التطبيق تلقائيًا خلاله
  };
}

// تصفير كل ما يخص "اليوم" (المهام والأذكار...) إذا بدأ يوم جديد. تُستخدم عند فتح التطبيق، وعند تبديل حساب طفل،
// وعند عبور منتصف الليل والتطبيق مفتوح (كانت المهام قبل كده تفضل مقفولة لحد ما الطفل يقفل التطبيق ويفتحه تاني)
function rollDailyState(st) {
  const today = todayStr();
  if (st.dailyDate !== today) {
    st.tasksPending = {};
    st.tasksApproved = {};
    st.weeklyClaimed = {};
    st.weeklyApproved = {};
    st.tasksApprovedToday = 0;
    st.dailyDate = today;
  }
  if (st.dhikrDate !== today) {
    st.dhikrProgress = {};
    st.dhikrDate = today;
  }
  if (st.screenTimeDate !== today) {
    st.screenTimeUsedToday = 0;
    st.extraTimeGrantedToday = 0;
    st.screenTimeDate = today;
  }
  if (st.activeSubscription && st.activeSubscription.expiresDate && today > st.activeSubscription.expiresDate) {
    st.activeSubscription = null; // انتهت مدة الباقة (شهر بالظبط من وقت التفعيل)
  }
  return st;
}

let state = loadState();

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    rollDailyState(parsed);
    // ترقية فيديوهات محفوظة بالشكل القديم (قبل دعم أي رابط فيديو غير يوتيوب) حتى تفضل شغالة
    if (Array.isArray(parsed.customVideos)) {
      parsed.customVideos = parsed.customVideos.map(v => v && !v.type ? { id: v.id, type: 'youtube', ref: v.id, title: v.title } : v);
    }
    return { ...defaultState(), ...parsed };
  } catch (e) {
    return defaultState();
  }
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    if (typeof window.onStateSaved === 'function') window.onStateSaved(state);
  } catch (e) {
    console.error('تعذر حفظ البيانات', e);
    // كان الفشل بيحصل بصمت (مثلًا لما مساحة التخزين تمتلئ) فتضيع تقدّم الطفل من غير ما حد يعرف
    if (!window.__saveWarned) {
      window.__saveWarned = true;
      setTimeout(() => showMessageCard('warning', 'تعذّر حفظ التقدّم', 'مساحة التخزين على الجهاز ممتلئة. امسح بيانات غير مهمة أو احفظ نسخة احتياطية من لوحة الوالدين'), 0);
    }
  }
}

// تُستدعى من auth.js بعد استرجاع بيانات محفوظة من السحابة (تسجيل الدخول من جهاز جديد)
window.applyCloudState = function(cloudState) {
  if (!cloudState || typeof cloudState !== 'object') return;
  state = { ...defaultState(), ...cloudState };
  saveState();
  render();
};

async function hashPin(pin) {
  if (typeof crypto === 'undefined' || !crypto.subtle) return pin;
  const data = new TextEncoder().encode('hasana_salt_' + pin);
  const buf = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}
function looksHashed(v) { return /^[0-9a-f]{64}$/.test(v || ''); }

// ============================== لوحة العائلة: حسابات متعددة على نفس الجهاز ==============================
// طبقة منفصلة تمامًا عن حالة الطفل الحالية (state)، فلا تغيّر أي منطق قائم؛ كل ملف طفل يُخزَّن بمفتاحه الخاص
const FAMILY_KEY = 'hasana_family_v1';

function loadFamilyIndex() {
  try {
    const raw = localStorage.getItem(FAMILY_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  const idx = { profiles: [{ id: 'p1', name: state.childName }], activeId: 'p1' };
  localStorage.setItem(FAMILY_KEY, JSON.stringify(idx));
  localStorage.setItem('hasana_profile_p1', JSON.stringify(state));
  return idx;
}
function saveFamilyIndex(idx) { localStorage.setItem(FAMILY_KEY, JSON.stringify(idx)); }
function saveCurrentProfileSnapshot(idx) { localStorage.setItem('hasana_profile_' + idx.activeId, JSON.stringify(state)); }
function loadProfileState(id) {
  try {
    const raw = localStorage.getItem('hasana_profile_' + id);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return null;
}

function addPoints(n) {
  const beforeLevel = getCurrentLevel(state.totalEarnedPoints);
  // مضاعف النقاط المؤقت من باقة الاشتراك السارية (لو موجودة)، بيرجع الوضع الطبيعي أوتوماتيك لما الباقة تخلص
  const activeTier = getActiveSubscriptionTier();
  const mult = (activeTier && activeTier.perks && activeTier.perks.pointsMultiplier) || 1;
  const finalN = Math.round(n * mult);
  state.points += finalN;
  state.totalEarnedPoints += finalN;
  saveState();
  const afterLevel = getCurrentLevel(state.totalEarnedPoints);
  if (afterLevel && beforeLevel && afterLevel.name !== beforeLevel.name) {
    sendPhoneNotification('ترقية مستوى جديد! 🌟', 'وصلت لمستوى "' + afterLevel.name + '"، أحسنت!');
  }
}
function spendPoints(n) {
  if (state.points < n) return false;
  state.points -= n;
  saveState();
  return true;
}

// ============================== الإنجازات ==============================
// يفحص كل الإنجازات، وأي إنجاز جديد يتحقق شرطه يُفتح فورًا مع صوت ورسوم احتفال
// ينطق نصًا عربيًا بصوت مناسب (يُستخدم في ترحيب الفتح، كلام الحيوان الأليف، وغيرها)
// نجهّز قائمة أصوات النطق مبكرًا: كروم وبعض المتصفحات بترجع قائمة فاضية أول مرة قبل ما تحمّل الأصوات فعليًا،
// وده كان بيخلي أول جملة منطوقة تتقال بصوت افتراضي (إنجليزي غالبًا) فتطلع مخارج الحروف العربية غلط تمامًا
let cachedVoices = [];
function refreshVoicesCache() {
  if (!('speechSynthesis' in window)) return;
  cachedVoices = window.speechSynthesis.getVoices() || [];
}
function initVoicesCache() {
  if (!('speechSynthesis' in window)) return;
  refreshVoicesCache();
  try { window.speechSynthesis.addEventListener('voiceschanged', refreshVoicesCache); } catch (e) {}
}
// نظّف النص قبل النطق: نستبدل الرموز والصيغ المختصرة اللي محركات النطق بتتلعثم فيها بنصها الكامل،
// ونشيل علامات الوقف القرآنية الخاصة اللي مش كل الأجهزة بتتعرف عليها صح
function cleanArabicForSpeech(text) {
  return String(text || '')
    .replace(/ﷺ/g, ' صلى الله عليه وسلم ')
    .replace(/ﷻ/g, ' عز وجل ')
    .replace(/رضي الله عنهما/g, ' رضي الله عنهما ')
    .replace(/[\u06D6-\u06ED]/g, '') // علامات الوقف القرآنية (ۖ ۗ ۘ ...) بعض محركات النطق بتقرأها كصوت غريب
    .replace(/\s+/g, ' ')
    .trim();
}
// نختار أفضل صوت عربي متاح على الجهاز بدل أول صوت بيلاقيه: نفضّل النطق السعودي (الأوضح للفصحى)،
// وبعدين أي صوت عربي تاني، وبعدين أي صوت اسمه فيه "Arabic" حتى لو لغته مش مضبوطة بالظبط
function pickBestArabicVoice() {
  const voices = cachedVoices.length ? cachedVoices : (window.speechSynthesis ? window.speechSynthesis.getVoices() : []);
  if (!voices.length) return null;
  const byLang = (code) => voices.find(v => (v.lang || '').toLowerCase() === code);
  return byLang('ar-sa') || byLang('ar-eg')
    || voices.find(v => (v.lang || '').toLowerCase().startsWith('ar'))
    || voices.find(v => /arabic/i.test(v.name || ''))
    || null;
}
function speakArabic(text, opts) {
  if (!('speechSynthesis' in window)) return;
  const clean = cleanArabicForSpeech(text);
  if (!clean) return;
  window.speechSynthesis.cancel();
  const speakNow = () => {
    const utter = new SpeechSynthesisUtterance(clean);
    utter.lang = 'ar-SA';
    utter.rate = (opts && opts.rate) || 0.92;
    utter.pitch = (opts && opts.pitch) || 1.1;
    const arVoice = pickBestArabicVoice();
    if (arVoice) { utter.voice = arVoice; utter.lang = arVoice.lang || 'ar-SA'; }
    window.speechSynthesis.speak(utter);
  };
  // لو الأصوات لسه ما اتحمّلتش (قائمة فاضية)، ننتظر تحميلها أول مرة بدل ما ننطق بصوت غلط فورًا
  refreshVoicesCache();
  if (!cachedVoices.length && 'addEventListener' in window.speechSynthesis) {
    window.speechSynthesis.addEventListener('voiceschanged', () => { refreshVoicesCache(); speakNow(); }, { once: true });
  } else {
    speakNow();
  }
}
// صوت إرشادي عند فتح التطبيق: تعريف بالتطبيق أول مرة، أو ترحيب بالعودة في المرات اللي بعدها
function playWelcomeVoiceGuide() {
  if (!state.soundEnabled) return;
  if (!state.hasOpenedBefore) {
    state.hasOpenedBefore = true; saveState();
    speakArabic('أهلاً بيك في حصالة الحسنات! هنا تقدر تجمع حسنات كل يوم، وتسمع قصص، وتلعب ألعاب إسلامية، وتتعلم القرآن والصلاة. يلا نبدأ رحلتنا مع الخير!');
  } else {
    speakArabic('أهلاً برجوعك يا ' + (state.childName || 'بطل الحسنات') + '! جاهز تكمل جمع حسناتك النهاردة؟');
  }
}

function checkAndUnlockAchievements() {
  let unlockedNew = false;
  achievementsList.forEach(a => {
    if (!state.unlockedAchievements[a.id] && a.check(state)) {
      state.unlockedAchievements[a.id] = todayStr();
      unlockedNew = true;
      sendPhoneNotification('إنجاز جديد! 🏆', 'فتحت إنجاز "' + a.title + '"');
    }
  });
  if (unlockedNew) { saveState(); playAchievementSound(); celebrate(); }
}

// يحسب أيام الدخول المتتالية للتطبيق (تُستخدم في إنجازي "مواظب" و"أسبوع كامل")
function updateLoginStreak() {
  const today = todayStr();
  if (state.lastOpenDate === today) return;
  const y = new Date(); y.setDate(y.getDate() - 1);
  const yesterday = y.toLocaleDateString('en-CA');
  const d2 = new Date(); d2.setDate(d2.getDate() - 2);
  const twoDaysAgo = d2.toLocaleDateString('en-CA');
  const monthKey = today.slice(0, 7);
  if (state.lastOpenDate === yesterday) {
    state.loginStreak = (state.loginStreak || 0) + 1;
  } else if (state.lastOpenDate === twoDaysAgo && hasTierAtLeast('silver-plan') && state.streakShieldMonth !== monthKey) {
    // درع المواظبة (باقة فضية فأعلى): يحمي السلسلة لو فاتك يوم واحد، مرة كل شهر
    state.loginStreak = (state.loginStreak || 0) + 1;
    state.streakShieldMonth = monthKey;
  } else {
    state.loginStreak = 1;
  }
  state.lastOpenDate = today;
  saveState();
}

// ============================== أصوات التطبيق (مُولَّدة برمجيًا، بدون ملفات صوتية، بدون إنترنت) ==============================
// كل الأصوات هادئة ولطيفة، ويمكن إيقافها بالكامل من الإعدادات (state.soundEnabled)
let audioCtx = null;
function getAudioCtx() {
  audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
  return audioCtx;
}
function playTone(freq, start, dur, type, vol) {
  const ctx = getAudioCtx();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type || 'sine';
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(vol || 0.08, start);
  gain.gain.exponentialRampToValueAtTime(0.0008, start + dur);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(start); osc.stop(start + dur + 0.02);
}
// صوت بسيط عند الضغط على أي زر
// اهتزاز خفيف عند اللمس (لو الجهاز بيدعمه)، يمكن إيقافه من الإعدادات
function hapticTap(ms) {
  try { if (state.hapticEnabled !== false && navigator.vibrate) navigator.vibrate(ms || 8); } catch (e) {}
}
function playClickSound() {
  hapticTap(8);
  if (!state.soundEnabled) return;
  if (state.darkMode) { playMagicClickSound(); return; }
  try { playTone(620, getAudioCtx().currentTime, 0.12, 'sine', 0.07); } catch (e) { /* بيئة لا تدعم الصوت، تجاهل بهدوء */ }
}
// نقرة "سحرية" لامعة تُستخدم تلقائيًا في الوضع المعتم بدل النقرة العادية
function playMagicClickSound() {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [1046, 1568, 2093].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.045, 0.16, 'sine', 0.055));
  } catch (e) {}
}
// نغمة "لمعان" قصيرة ومتصاعدة عند فتح ستارة النجوم فوق شعار التطبيق في شاشة البداية
function playSplashShineSound() {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [784, 988, 1245, 1568, 1976].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.06, 0.2, 'sine', 0.07));
  } catch (e) {}
}
// نغمة نجاح صاعدة: إنهاء مهمة / إجابة صحيحة / حسنة جديدة
function playSuccessSound() {
  hapticTap(15);
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [660, 880, 1046].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.09, 0.18, 'sine', 0.09));
  } catch (e) {}
}
// نقرة خفيفة عند إكمال عدّاد (تسبيح، أذكار)
function playTickSound() {
  if (!state.soundEnabled) return;
  try { playTone(940, getAudioCtx().currentTime, 0.07, 'triangle', 0.06); } catch (e) {}
}
// نغمة فتح لطيفة: فتح قصة / سورة / باب أذكار / درس صلاة
function playOpenSound() {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [520, 740].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.07, 0.14, 'sine', 0.07));
  } catch (e) {}
}
// نغمة عملات/شراء: صندوق مكافآت أو شراء من المتجر
function playPurchaseSound() {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [880, 660, 990].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.06, 0.12, 'triangle', 0.08));
  } catch (e) {}
}
// نغمة إنجاز/وسام: أطول وأكثر احتفالية من نغمة النجاح العادية
// ============================== إشعارات الهاتف (Web Notifications) ==============================
function requestNotificationPermission() {
  if (typeof Notification === 'undefined') { showMessageCard('error', 'غير مدعوم', 'متصفحك لا يدعم الإشعارات'); return; }
  Notification.requestPermission().then(perm => {
    state.notificationsEnabled = perm === 'granted';
    saveState(); render();
    if (perm !== 'granted') showMessageCard('warning', 'لازم إذن', 'لازم توافق على إذن الإشعارات من إعدادات المتصفح عشان تشتغل');
  });
}
function sendPhoneNotification(title, body) {
  if (!state.notificationsEnabled || typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  // الطريقة الصحيحة والموثوقة لإظهار إشعار في شريط النظام فعليًا: عن طريق service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then((reg) => {
      reg.active && reg.active.postMessage({ type: 'SHOW_NOTIFICATION', title, body });
    }).catch(() => {
      try { new Notification(title, { body, icon: 'icons/icon-192.png' }); } catch (e) {}
    });
  } else {
    try { new Notification(title, { body, icon: 'icons/icon-192.png' }); } catch (e) {}
  }
}

function playAchievementSound() {
  hapticTap([12, 40, 12]);
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [523, 659, 784, 1046].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.1, 0.22, 'sine', 0.1));
  } catch (e) {}
}

// نغمة تذكير الصلاة: أعلى صوتًا وأطول من نغمة الإنجاز العادية حتى تُسمع بوضوح، وتتكرر مرتين لجذب الانتباه
function playPrayerReminderSound() {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    const notes = [784, 988, 1175, 1568];
    [0, 1].forEach(rep => {
      notes.forEach((freq, i) => playTone(freq, ctx.currentTime + rep * 1.3 + i * 0.14, 0.32, 'sine', 0.22));
    });
    if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 300]);
  } catch (e) {}
}

// نغمة فرح قصيرة عند التفاعل مع الحيوان الأليف
function playPetSound() {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    [1046, 1318].forEach((freq, i) => playTone(freq, ctx.currentTime + i * 0.08, 0.12, 'sine', 0.08));
  } catch (e) {}
}

// يجعل الحيوان الأليف يقفز ويظهر رسالة تشجيعية عشوائية عند الضغط عليه، دون إعادة رسم كل التطبيق
function bouncePetFigure() {
  const fig = document.getElementById('pet-figure');
  const zone = document.getElementById('pet-msg-zone');
  if (fig) {
    fig.classList.remove('pet-bounce');
    void fig.offsetWidth;
    fig.classList.add('pet-bounce');
  }
  if (zone) {
    const msg = petMessages[Math.floor(Math.random() * petMessages.length)];
    zone.innerHTML = `<div class="pet-bubble">${icon('heart')} ${msg}</div>`;
    setTimeout(() => { if (zone.firstChild) zone.innerHTML = ''; }, 2200);
  }
}

// ============================== لمعة سحرية صغيرة عند كل ضغطة (بدون صور خارجية) ==============================
function sparkleAt(x, y) {
  try {
    const el = document.createElement('div');
    el.className = 'tap-sparkle';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.innerHTML = ICONS.sparkle;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 600);
  } catch (e) {}
}

// ============================== احتفال (كونفيتي) لتشجيع الطفل ==============================
function celebrate() {
  const colors = ['#2F6B44', '#D9A441', '#4A5FA8', '#C1694F', '#6C5A96'];
  const container = document.createElement('div');
  container.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:500;overflow:hidden;';
  document.body.appendChild(container);
  for (let i = 0; i < 26; i++) {
    const piece = document.createElement('div');
    const size = 6 + Math.random() * 6;
    piece.style.cssText = `position:absolute;top:-20px;left:${Math.random()*100}%;width:${size}px;height:${size}px;
      background:${colors[i % colors.length]};border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
      animation:confetti-fall ${1.6 + Math.random()*1.2}s ease-in forwards;animation-delay:${Math.random()*0.3}s;`;
    container.appendChild(piece);
  }
  setTimeout(() => container.remove(), 3200);
}

// ============================== رسوم توضيحية بسيطة لوضعيات الصلاة (SVG بدون صور خارجية) ==============================
// رسم توضيحي مبسّط ومحتشم لهيئة المصلي في كل وضعية (بلا ملامح وجه، جسم مكسو بالكامل، بأسلوب مسطّح واضح)
const POSE_IMAGES = {
  takbir: 'icons/prayer-steps/step1-takbeer.jpg',
  qiyam: 'icons/prayer-steps/step2-qiyam.png',
  ruku: 'icons/prayer-steps/step3-ruku.png',
  itidal: 'icons/prayer-steps/step4-qawma.png',
  sujood: 'icons/prayer-steps/step5-sujood.png',
  julus: 'icons/prayer-steps/step6-jalsa.png',
};
function poseSVG(pose) {
  const src = POSE_IMAGES[pose] || POSE_IMAGES.qiyam;
  return `<img src="${src}" alt="وضعية الصلاة" style="width:100%;height:100%;object-fit:contain;border-radius:10px;background:rgba(0,0,0,.03)" loading="lazy" />`;
}

// ============================== التنقل ==============================
let currentTab = 'home';
let lastRenderedTab = null; // لتحديد هل حصل تبديل تاب فعلي (لتشغيل حركة الانتقال) أو مجرد تحديث بيانات عادي
let currentMode = 'child'; // 'child' | 'parent'
let modalStack = [];

const root = document.getElementById('app');

// تصنيف نوع المهمة لفروع "شجرة الحسنات" الأربعة
function hasanahCategory(name) {
  if (!name) return 'kindness';
  if (name.includes('صلاة') || name.includes('مسجد')) return 'salah';
  if (name.includes('قرآن') || name.includes('حفظ')) return 'quran';
  if (name.includes('أذكار') || name.includes('ذكر')) return 'dhikr';
  return 'kindness'; // بر الوالدين، صدقة، مساعدة، وأي عمل خير آخر
}

function applyThemeClasses() {
  document.body.classList.toggle('dark', !!state.darkMode);
  document.body.classList.toggle('animate-icons', state.animatedIcons !== false);
  document.body.classList.toggle('animate-text', state.animatedText !== false);
  document.body.classList.toggle('zoom-mode', !!state.zoomMode);
  // لازم القائمة تشمل كل الثيمات الممكنة (بما فيها ثيمات الأحداث الأسبوعية) وإلا تفضل الصقة على الطفل بعد أول اثنين/خميس/جمعة
  const themes = ['theme-default','theme-ramadan','theme-eid','theme-mawlid','theme-israa','theme-hijri','theme-shaban','theme-fasting','theme-jumuah'];
  themes.forEach(t => document.body.classList.remove(t));
  const activeTheme = getCurrentAppTheme();
  document.body.classList.add(activeTheme);
  // لون التطبيق المُشترى من المتجر يُطبَّق في الأيام العادية وأيام الأحداث الأسبوعية (صيام الاثنين/الخميس، الجمعة)
  // ولا يزاحم فقط زينة المناسبات الهجرية الخاصة (رمضان/العيد/المولد/الإسراء/شعبان)
  const normalDays = ['theme-default', 'theme-fasting', 'theme-jumuah'];
  if (normalDays.includes(activeTheme) && state.appColorTheme) {
    const t = APP_COLOR_THEMES.find(x => x.id === state.appColorTheme);
    if (t) { document.body.style.setProperty('--primary', t.primary); document.body.style.setProperty('--gold', t.gold); }
  } else {
    document.body.style.removeProperty('--primary');
    document.body.style.removeProperty('--gold');
  }
  // لون الخلفية المُشترى من المتجر - يُطبَّق دائمًا (حتى في الوضع المعتم) إن كان الطفل قد اختار لونًا غير الافتراضي
  const bgTheme = backgroundColorThemes.find(x => x.id === state.currentBackgroundTheme);
  if (bgTheme && bgTheme.id !== 'default') {
    document.body.style.setProperty('--background', state.darkMode ? bgTheme.darkBg || bgTheme.bg : bgTheme.bg);
  } else {
    document.body.style.removeProperty('--background');
  }
  // شكل التطبيق كله يتحول لثيم ناري (أحمر/برتقالي) طول ما الباقة الأسطورية سارية، ويرجع طبيعي تلقائيًا بعد انتهائها
  document.body.classList.toggle('legendary-fire-theme', hasAllAccess());
  document.body.classList.toggle('large-text', !!state.largeText);
  document.body.classList.toggle('calm-mode', !!state.calmMode);
  if (hasAllAccess()) {
    document.body.style.setProperty('--primary', '#FF4B2B');
    document.body.style.setProperty('--gold', '#FF8C42');
  }
}

// ============================== إعلانات الدعم (تبرع / بريميوم) ==============================
// تُعرض عند دخول الموقع، وتختفي بالضغط على X لهذه الزيارة فقط، وتظهر من جديد تلقائيًا بعد أي تحديث/إعادة تحميل للصفحة
let donateAdDismissed = false;
let premiumAdDismissed = false;
let donateFormSent = false;
let selectedSubTierId = 'silver-plan'; // آخر باقة اشتراك (غير بريميوم) ضغط عليها المستخدم "تواصل واتساب"
let premiumFormSent = false;
let lastDonateRefNo = '';
let lastPremiumRefNo = '';
// طلبات التبرع والاشتراك بتتبعت على نفس رقم واتساب المسؤول الرسمي بالتطبيق (OFFICIAL_WHATSAPP بالأسفل)

function generateRefNo(prefix) {
  const n = Math.floor(100000 + Math.random() * 900000);
  return prefix + '-' + n;
}
function nowStampAr() {
  const d = new Date();
  return todayStr() + ' — ' + d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
}

function renderPremiumAdCard() {
  if (premiumAdDismissed || getActiveSubscriptionTier()) return ''; // أي باقة سارية = مفيش إعلان اشتراك
  return `
  <div class="top-ad-strip">
    <span class="top-ad-strip-icon">${icon('crown')}</span>
    <span class="top-ad-strip-text">اشترك في باقة بريميوم لميزات حصرية</span>
    <button type="button" class="top-ad-strip-btn" data-action="switch-tab" data-tab="subscription">اشترك</button>
    <button type="button" class="top-ad-strip-close" data-action="dismiss-premium-ad" aria-label="إغلاق">✕</button>
  </div>`;
}

function renderAdhanBanner() {
  if (!adhanBannerPrayer) return '';
  return `
  <div class="container" style="padding-top:0">
    <div class="weekly-card" style="background:linear-gradient(135deg,var(--primary),var(--gold))">
      <div class="row"><b>${icon('mosque')} حان الآن وقت صلاة ${adhanBannerPrayer}</b></div>
      <p class="msg mt8">لا تنسَ الصلاة في وقتها، فهي أحب الأعمال إلى الله</p>
      <button class="btn block mt8" style="background:#fff;color:var(--primary)" data-action="dismiss-adhan-banner">${icon('check')} تمام</button>
    </div>
  </div>`;
}

function render() {
  try {
    renderUnsafe();
    if (typeof translateDom === 'function') translateDom(document.body);
  } catch (e) {
    // شاشة بيضاء فاضية بدون أي رسالة كانت بتحصل لو أي خطأ وقع أثناء الرسم؛ دلوقتي بنعرض شاشة أمان بدل كراش صامت
    console.error('render error', e);
    if (!window.__renderCrashHandled) {
      window.__renderCrashHandled = true;
      root.innerHTML = `<div class="container center" style="padding-top:60px">
        <h1 class="title">حدث خطأ غير متوقع</h1>
        <p class="muted mt8">حاول العودة للصفحة الرئيسية، أو أعد تحميل التطبيق لو استمرت المشكلة</p>
        <button class="btn block mt16" onclick="try{currentTab='home';modalStack=[];window.__renderCrashHandled=false;render();}catch(e){location.reload();}">العودة للرئيسية</button>
        <button class="btn secondary block mt8" onclick="location.reload()">إعادة تحميل التطبيق</button>
      </div>`;
    }
  }
}
// وقت الشاشة: هل الطفل تعدّى الحد المسموح اليوم أو إحنا دلوقتي في وقت النوم؟
function isWithinBedtime() {
  if (!state.bedtimeStart || !state.bedtimeEnd) return false;
  const toMin = t => { const m = /^(\d{1,2}):(\d{2})$/.exec(t); return m ? Number(m[1]) * 60 + Number(m[2]) : null; };
  const start = toMin(state.bedtimeStart), end = toMin(state.bedtimeEnd);
  if (start === null || end === null || start === end) return false;
  const now = new Date(); const cur = now.getHours() * 60 + now.getMinutes();
  return start < end ? (cur >= start && cur < end) : (cur >= start || cur < end);
}
function childLockReason() {
  if (state.screenLimitMinutes > 0) {
    const limit = state.screenLimitMinutes + (state.extraTimeGrantedToday || 0);
    if ((state.screenTimeUsedToday || 0) >= limit) return 'limit';
  }
  if (isWithinBedtime()) return 'bedtime';
  return null;
}
// حماية من محاولات إعادة استخدام كود (كوبون أو تفعيل اشتراك) مُستخدم قبل كده: لو حصلت مرتين، حظر مؤقت 8 ساعات
function isCodeLocked() { return !!(state.codeLockUntil && Date.now() < state.codeLockUntil); }
function triggerCodeLock() {
  state.codeLockUntil = Date.now() + 8 * 3600000; // 8 ساعات
  saveState();
}
// ============================== حماية من النقرات الآلية/غير البشرية (بوتات) ==============================
// نظام بسيط بيراقب معدل الضغطات: محدش بيقدر يضغط عشرات الأزرار في أقل من ثانية بشكل طبيعي.
// عمدًا الحظر هنا **مؤقت** (ساعة واحدة) مش نهائي أبدًا: أي نظام آلي كشف بيقع أحيانًا في أخطاء (false positives)،
// وحظر نهائي لطفل بسبب ضغطه بسرعة وهو متحمس (سلوك طبيعي جدًا للأطفال) هيبقى ضرر حقيقي بلا أي طريقة للرجوع
// (التطبيق مفهوش سيرفر يقدر "يرفع" عنه الحظر). الحظر المؤقت بيدي نفس الحماية العملية من غير مخاطرة زي دي.
let recentActionTimestamps = [];
function isSecurityLocked() { return !!(state.securityLockUntil && Date.now() < state.securityLockUntil); }
function triggerSecurityLock() {
  state.securityLockUntil = Date.now() + 3600000; // ساعة واحدة
  saveState();
}
function checkBotLikeActivity() {
  const now = Date.now();
  recentActionTimestamps.push(now);
  recentActionTimestamps = recentActionTimestamps.filter(t => now - t < 5000); // آخر 5 ثوانٍ بس
  const inLastSecond = recentActionTimestamps.filter(t => now - t < 1000).length;
  // بشري عادي (حتى لو طفل متحمس بيدوس بسرعة) مش بيتخطى كده؛ الأرقام دي متعمّدة عالية عشان تتجنب حظر أطفال حقيقيين
  if (inLastSecond >= 12 || recentActionTimestamps.length >= 35) {
    triggerSecurityLock();
    recentActionTimestamps = [];
    return true;
  }
  return false;
}
function renderLockScreen(icon_, title, desc, until, colorA, colorB) {
  const remainingMs = Math.max(0, until - Date.now());
  const h = Math.floor(remainingMs / 3600000);
  const m = Math.floor((remainingMs % 3600000) / 60000);
  return `<div class="container center" style="padding-top:70px">
    <div class="icon-lg" style="color:${colorA};margin:0 auto;width:64px;height:64px">${icon(icon_)}</div>
    <h1 class="title mt12">${title}</h1>
    <p class="muted mt8">${desc}</p>
    <div class="card center mt16" style="background:linear-gradient(135deg,${colorA},${colorB});color:#fff">
      <div style="font-size:28px;font-weight:900">${h} س ${m} د</div>
      <p class="small mt8">هيتفتح التطبيق تلقائيًا لوحده بعد ما الوقت ده يخلص</p>
    </div>
  </div>`;
}
function renderCodeLockScreen() {
  return renderLockScreen('lock', '🔒 تم حظرك مؤقتًا',
    'حصلت محاولة استخدام كود (كوبون أو اشتراك) مُستخدم قبل كده أكتر من مرة، فتم حظر التطبيق مؤقتًا لمدة 8 ساعات لحماية النظام',
    state.codeLockUntil, '#C0392B', '#8B2E20');
}
function renderSecurityLockScreen() {
  return renderLockScreen('shield', '🛡️ توقف مؤقت للحماية',
    'لاحظنا ضغطات سريعة جدًا وغير طبيعية على التطبيق، فتم إيقافه مؤقتًا لمدة ساعة كإجراء حماية تلقائي. لو ده حصل بالغلط، هيرجع التطبيق يفتح لوحده بعد الوقت ده',
    state.securityLockUntil, '#4A5FA8', '#2E3A6E');
}
function renderChildLockScreen(reason) {
  const isBed = reason === 'bedtime';
  return `<div class="container center" style="padding-top:70px">
    <div class="icon-lg" style="color:var(--gold);margin:0 auto;width:56px;height:56px">${icon('moon')}</div>
    <h1 class="title mt12">${isBed ? 'حان وقت النوم' : 'انتهى وقتك اليوم'}</h1>
    <p class="muted mt8">${isBed ? 'حان الآن وقت النوم، سيفتح التطبيق تلقائيًا الساعة ' + esc(state.bedtimeEnd) : 'استخدمت وقتك المسموح لك اليوم في التطبيق، ارجع بكرة إن شاء الله وهتلاقي مهامك في انتظارك'}</p>
    <button class="btn secondary block mt16" data-action="open-parent-gate">${icon('lock')} وضع الوالدين</button>
  </div>`;
}

function renderUnsafe() {
  applyThemeClasses();
  const tickerRoot = document.getElementById('dhikr-ticker-root');
  if (tickerRoot) tickerRoot.style.display = currentMode === 'parent' ? 'none' : '';
  if (isCodeLocked()) {
    root.innerHTML = renderOfflineBanner() + renderCodeLockScreen();
  } else if (isSecurityLocked()) {
    root.innerHTML = renderOfflineBanner() + renderSecurityLockScreen();
  } else if (currentMode === 'parent') {
    root.innerHTML = renderParentDashboard();
  } else if (childLockReason()) {
    root.innerHTML = renderOfflineBanner() + renderChildLockScreen(childLockReason());
  } else {
    const tabChanged = lastRenderedTab !== currentTab;
    lastRenderedTab = currentTab;
    root.innerHTML = renderOfflineBanner() + renderChildTopbar() + renderPremiumAdCard() + renderAdhanBanner() + renderEventBanner() + renderWeeklyEventCard() + `<div class="${tabChanged ? 'tab-content-anim' : ''}">${renderTabContent()}</div>` + renderRoamingPet() + renderBottomNav() + renderTutorialOverlay();
  }
  renderModals();
  // لو مودال السورة مفتوح ونصها محمّل مسبقًا في الذاكرة، نرسمه فورًا بدل ما يفضل عالق على "جاري التحميل"
  // (بيحصل لو أي زرار جوه المودال ده - زي تأكيد الحفظ - عمل render() تاني من غير ما يعيد تحميل النص من النت)
  if (currentQuranSurahId != null && quranPages.length > 0) {
    const c = document.getElementById('surah-text-' + currentQuranSurahId);
    if (c && !c.querySelector('.quran-book')) { renderQuranPage(c); bindContainer(c); }
  }
  bindEvents();
}

// ============================== الشريط العلوي ==============================
function renderChildTopbar() {
  const level = getCurrentLevel(state.totalEarnedPoints);
  return `
  <div class="container" style="padding-bottom:0">
    <div class="topbar">
      <div>
        <div class="name"><span${(validGlowId() || hasAllAccess() || tierNameColor()) ? (' style="' + (((nameGlowStyles.find(g => g.id === validGlowId())) || (hasAllAccess() ? { css: 'color:#FF3B30;text-shadow:0 0 6px #FF3B30,0 0 14px #FF3B30' } : { css: 'color:' + tierNameColor() + ';text-shadow:0 0 8px ' + tierNameColor() + '88' })).css || '') + '"') : ''}>${icon(level.icon)} ${esc(state.childName)}</span> ${(state.diamondBadgeOwned || hasAllAccess()) ? icon('diamond') : ''} ${(state.supporterBadgeOwned || hasAllAccess()) ? '🔥' : ''} ${getActiveSubscriptionTier() ? getActiveSubscriptionTier().icon : ''}</div>
        <div class="muted">${level.name}</div>
      </div>
      <div class="row" style="gap:8px">
        <div class="points">${icon('coin')} ${state.points}</div>
        ${state.diamonds > 0 ? `<div class="points" style="color:#4FA3E0">${icon('diamond')} ${state.diamonds}</div>` : ''}
        ${state.gold > 0 ? `<div class="points" style="color:#D4A017">🟡 ${state.gold}</div>` : ''}
        ${state.silver > 0 ? `<div class="points" style="color:#8A8FA0">⚪ ${state.silver}</div>` : ''}
        <button class="icon-btn" data-action="toggle-dark">${icon(state.darkMode ? 'sun' : 'moon')}</button>
        <button class="icon-btn" data-action="open-profile">${icon('person')}</button>
      </div>
    </div>
  </div>`;
}

// ============================== الشريط المتحرك للأذكار والصلاة على النبي ==============================
// يعرض كل عبارات الذكر واحدة تلو الأخرى بترتيب ثابت، ثم يعيد الدورة من الأول تلقائيًا إلى الأبد.
// العنصر يعيش في #dhikr-ticker-root (خارج المنطقة التي يعيد render() رسمها بالكامل) والمؤقت يعمل مرة واحدة
// فقط عند الإقلاع، فلا يتوقف ولا يُعاد ضبطه مهما تفاعل الطفل مع بقية التطبيق.
let dhikrTickerIndex = 0;
function renderDhikrTicker() {
  return `
  <div class="dhikr-ticker-pro" id="dhikr-ticker-box">
    <span class="dhikr-ticker-icon">${icon('sparkle')}</span>
    <span id="dhikr-ticker-text" class="dhikr-ticker-text show" data-mode="dhikr">${tickerPhrases[0]}</span>
  </div>`;
}
function rotateDhikrTicker() {
  const el = document.getElementById('dhikr-ticker-text');
  if (!el || el.dataset.mode === 'coupon') return; // ماينفعش يقاطع رسالة الكوبون وهي ظاهرة
  dhikrTickerIndex = (dhikrTickerIndex + 1) % tickerPhrases.length; // يمر على كل الأذكار بالترتيب ثم يبدأ من جديد تلقائيًا
  el.classList.remove('show');
  setTimeout(() => {
    el.textContent = tickerPhrases[dhikrTickerIndex];
    el.dataset.mode = 'dhikr';
    el.classList.add('show');
  }, 300);
}
// كل دقيقة، شريط الأذكار بيعرض لمدة 5 ثوانٍ رسالة "عندك كوبون؟" قابلة للضغط، بدل ذكر عادي، ثم يرجع تلقائي
function showCouponTickerPrompt() {
  const el = document.getElementById('dhikr-ticker-text');
  if (!el) return;
  el.classList.remove('show');
  setTimeout(() => {
    el.textContent = '🎟️ هل لديك كوبون؟ انقر لاستخدامه';
    el.dataset.mode = 'coupon';
    el.classList.add('show');
  }, 300);
  setTimeout(() => {
    if (el.dataset.mode !== 'coupon') return;
    el.classList.remove('show');
    setTimeout(() => {
      el.textContent = tickerPhrases[dhikrTickerIndex];
      el.dataset.mode = 'dhikr';
      el.classList.add('show');
    }, 300);
  }, 5000);
}

// ============================== بطاقة الحدث الأسبوعي (صيام الاثنين/الخميس - خطبة الجمعة) ==============================
function renderWeeklyEventCard() {
  const w = getWeeklyEvent();
  if (!w) return '';
  if (w.kind === 'fasting') {
    const approved = state.weeklyApproved[w.id] === todayStr();
    const pending = state.weeklyClaimed[w.id] === todayStr() && !approved;
    return `
    <div class="container" style="padding-top:0">
      <div class="weekly-card">
        <div class="row" style="align-items:flex-start">
          <div class="icon-lg">${icon(w.icon)}</div>
          <div style="flex:1;margin-right:10px">
            <div style="font-weight:900;font-size:15px">${w.name}</div>
            <div class="msg" style="opacity:.95;font-size:12.5px;margin-top:4px">${w.message}</div>
          </div>
        </div>
        ${approved ? `<div class="khutba-note">${icon('checkCircle')} تم رصد النقاط، بارك الله فيك</div>` :
          pending ? `<div class="khutba-note">${icon('hourglass')} بانتظار تأكيد الوالدين</div>` :
          `<button class="btn block mt8" style="background:#fff;color:var(--primary)" data-action="request-weekly" data-id="${w.id}" data-pts="${w.points}">${icon('check')} صمت اليوم (+${w.points} بعد تأكيد الوالدين)</button>`}
      </div>
    </div>`;
  }
  if (w.kind === 'khutba') {
    const approved = state.weeklyApproved[w.id] === todayStr();
    const pending = state.weeklyClaimed[w.id] === todayStr() && !approved;
    const note = esc(state.khutbaNotes[todayStr()] || '');
    return `
    <div class="container" style="padding-top:0">
      <div class="weekly-card">
        <div class="row" style="align-items:flex-start">
          <div class="icon-lg">${icon(w.icon)}</div>
          <div style="flex:1;margin-right:10px">
            <div style="font-weight:900;font-size:15px">${w.name}</div>
            <div class="msg" style="opacity:.95;font-size:12.5px;margin-top:4px">${w.message}</div>
          </div>
        </div>
        ${approved ? `<div class="khutba-note">${icon('checkCircle')} أخذت مكافأتك، جزاك الله خيراً</div><div class="khutba-note">${note}</div>` :
          pending ? `<div class="khutba-note">${icon('hourglass')} بانتظار الوالدين ليقرأوا ما كتبته ويؤكدوا مكافأتك</div><div class="khutba-note">${note}</div>` :
          `<textarea id="khutba-input" placeholder="اكتب هنا أهم حاجة اتعلمتها من خطبة الجمعة...">${note}</textarea>
           <button class="btn block mt8" style="background:#fff;color:var(--primary)" data-action="submit-khutba" data-id="${w.id}" data-pts="${w.points}">${icon('pen')} إرسال لوالديّ</button>`}
      </div>
    </div>`;
  }
  // بقية أيام الأسبوع (الصدقة، بر الوالدين، القرآن، الأخلاق) بنفس آلية الصيام: تأكيد الطفل ثم اعتماد الوالدين
  const approved2 = state.weeklyApproved[w.id] === todayStr();
  const pending2 = state.weeklyClaimed[w.id] === todayStr() && !approved2;
  return `
  <div class="container" style="padding-top:0">
    <div class="weekly-card">
      <div class="row" style="align-items:flex-start">
        <div class="icon-lg">${icon(w.icon)}</div>
        <div style="flex:1;margin-right:10px">
          <div style="font-weight:900;font-size:15px">${w.name}</div>
          <div class="msg" style="opacity:.95;font-size:12.5px;margin-top:4px">${w.message}</div>
        </div>
      </div>
      ${approved2 ? `<div class="khutba-note">${icon('checkCircle')} تم رصد النقاط، بارك الله فيك</div>` :
        pending2 ? `<div class="khutba-note">${icon('hourglass')} بانتظار تأكيد الوالدين</div>` :
        `<button class="btn block mt8" style="background:#fff;color:var(--primary)" data-action="request-weekly" data-id="${w.id}" data-pts="${w.points}">${icon('check')} فعلتها اليوم (+${w.points} بعد تأكيد الوالدين)</button>`}
    </div>
  </div>`;
}

// ============================== بانر المناسبات الإسلامية ==============================
function renderEventBanner() {
  const event = getCurrentIslamicEvent();
  if (!event) return '';
  if (state.eventClaimed[event.id] === todayStr()) return '';
  return `
  <div class="container" style="padding-top:0">
    <div class="banner">
      <div class="icon-lg">${icon(event.icon)}</div>
      <div style="font-weight:900;font-size:16px;margin-top:6px">${event.name}</div>
      <div class="msg">${event.message}</div>
      <button class="btn" style="background:#fff;color:var(--primary)" data-action="claim-event" data-id="${event.id}" data-pts="${event.bonusPoints}">
        ${icon('gift')} احصل على ${event.bonusPoints} نقطة
      </button>
    </div>
  </div>`;
}

// ============================== محتوى التابات ==============================
// ============================== نظام قفل الميزات كعقوبة من الوالدين (الغش/الكذب) ==============================
function isFeatureLocked(tabId) {
  const until = state.lockedFeatures && state.lockedFeatures[tabId];
  return !!(until && until > Date.now());
}
function formatRemaining(ms) {
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
  if (h > 24) return Math.ceil(h / 24) + ' يوم تقريبًا';
  if (h > 0) return h + ' ساعة و' + m + ' دقيقة';
  return m + ' دقيقة';
}
function renderLockedScreen(tabId) {
  const t = ALL_TABS.find(x => x.id === tabId);
  const remaining = state.lockedFeatures[tabId] - Date.now();
  return `<div class="container center">
    <div class="mt16" style="font-size:52px">${icon('lock')}</div>
    <h1 class="title mt8">هذه الميزة مقفولة مؤقتًا</h1>
    <p class="muted">قسم "${t ? t.label : ''}" مقفول حاليًا بواسطة والديك.</p>
    <p class="muted mt8">هيتفتح تاني بعد: <b>${formatRemaining(remaining)}</b></p>
    <p class="muted mt16">اتكلم مع والديك لو حابب تعرف السبب أو تتفق معاهم على حاجة.</p>
  </div>`;
}

function renderTabContent() {
  if (currentTab !== 'home' && isFeatureLocked(currentTab)) return renderLockedScreen(currentTab);
  switch (currentTab) {
    case 'home': return renderHomeTab();
    case 'pet': return renderPetTab();
    case 'assistant': return renderAssistantTab();
    case 'stories': return renderStoriesTab();
    case 'quiz': return renderQuizTab();
    case 'games': return renderGamesTab();
    case 'challenges': return renderChallengesTab();
    case 'rewards': return renderRewardsTab();
    case 'achievements': return renderAchievementsTab();
    case 'quran': return renderQuranTab();
    case 'hadith': return renderHadithTab();
    case 'adhkar': return renderAdhkarTab();
    case 'sunnah': return renderSunnahTab();
    case 'prayerTimes': return renderPrayerTimesTab();
    case 'contributors': return renderContributorsTab();
    case 'otherServices': return renderOtherServicesTab();
    case 'inviteFriend': return renderInviteFriendTab();
    case 'diamondVault': return renderDiamondVaultTab();
    case 'events': return eventSession ? renderEventSessionMCQ() : (eventScrambleSession ? renderEventScrambleSession() : renderEventsTab());
    case 'asmaHusna': return renderAsmaHusnaTab();
    case 'kaffara': return renderKaffaraTab();
    case 'safeVideos': return renderSafeVideosTab();
    case 'halalScanner': return renderHalalScannerTab();
    case 'tree': return renderTreeTab();
    case 'scenarios': return renderScenariosTab();
    case 'tasbih': return renderTasbihTab();
    case 'shop': return renderShopTab();
    case 'subscription': return renderSubscriptionTab();
    case 'calendar': return renderCalendarTab();
    case 'prayer': return renderPrayerTab();
    default: return '';
  }
}

// حديث اليوم: يتغير كل يوم تلقائيًا من مجموعة الأحاديث الموثّقة الموجودة في التطبيق
// ============================== كوبونات الهدايا (كروت خربشة) ==============================
function findActiveCoupon(code) {
  const clean = String(code || '').trim().toUpperCase();
  if (!clean) return null;
  const today = todayStr();
  const weekly = weeklyCoupons.find(c => c.code.toUpperCase() === clean && today >= c.validFrom && today <= c.validUntil);
  if (weekly) return weekly;
  // الكوبون الاستثنائي: صالح دايمًا، بس يُستخدم مرة واحدة فقط لكل حساب (يُمنع تكراره في revealCouponReward)
  if (typeof masterCoupon !== 'undefined' && masterCoupon.code.toUpperCase() === clean) return masterCoupon;
  // كوبونات المتجر: صالحة دايمًا، كل كود يُستخدم مرة واحدة فقط
  if (typeof storeCoupons !== 'undefined') {
    const fromStore = storeCoupons.find(c => c.code.toUpperCase() === clean);
    if (fromStore) return fromStore;
  }
  return null;
}
function renderCouponPromoCard() {
  // الخانة تفضل ظاهرة دايمًا (حتى لو الكوبون الحالي اتصرف)، عشان المستخدم يقدر يجرب أي كود في أي وقت
  // ولا تختفي بعد استخدام الكوبون؛ التحقق من صلاحية الكود بيحصل جوه المودال نفسه (findActiveCoupon)
  return `
    <div class="card mt12" style="border:1px solid var(--gold);cursor:pointer" data-action="open-coupon-redeem">
      <div class="row" style="justify-content:space-between">
        <div class="row"><span style="font-size:22px">🎟️</span><b>عندك كوبون هدية؟</b></div>
        <span class="muted small">اضغط هنا</span>
      </div>
    </div>`;
}

function renderHadithOfTheDay() {
  if (typeof hadiths === 'undefined' || !hadiths.length) return '';
  const h = hadiths[hashStr(todayStr()) % hadiths.length];
  return `
    <div class="card mt12" style="border:1px solid var(--primary)">
      <div class="row"><b>${icon('scroll')} حديث اليوم</b></div>
      <p class="mt8" style="font-weight:800;line-height:1.9">«${esc(h.text)}»</p>
      <p class="muted small mt8">${esc(h.narrator)} · ${esc(h.source)}</p>
      ${h.explanation ? `<p class="muted small mt8">${esc(h.explanation)}</p>` : ''}
      <button class="btn secondary block mt8" data-action="speak-hadith-of-day">${icon('speaker')} استمع للحديث</button>
    </div>`;
}

function renderHomeTab() {
  const allTasks = [...defaultTasks, ...state.customTasks];
  const rows = allTasks.map(t => {
    const approved = state.tasksApproved[t.id] === todayStr();
    const pending = state.tasksPending[t.id] === todayStr();
    let control;
    if (approved) control = `<button class="checkbox done" disabled>${icon('check')}</button>`;
    else if (pending) control = `<span class="pending-badge">${icon('hourglass')} ${tr('task_pending')}</span>`;
    else control = `<button class="checkbox" data-action="request-task" data-id="${t.id}">${tr('task_done_btn')}</button>`;
    return `
    <div class="task-row">
      <div>
        <div class="name">${esc(t.name)}</div>
        <div class="pts">+${t.points} ${tr('points_suffix')}${!approved && !pending ? ' (بعد تأكيد الوالدين)' : ''}</div>
      </div>
      ${control}
    </div>`;
  }).join('');

  const encouragementBanner = (state.pendingEncouragements && state.pendingEncouragements.length) ? `
    <div class="card mt12" style="border:1px solid var(--gold)">
      <div class="row"><b>${icon('heart')} رسائل تشجيع لك</b></div>
      ${state.pendingEncouragements.map(m => `<p class="mt8">${esc(m)}</p>`).join('')}
      <button class="btn secondary block mt12" data-action="dismiss-encouragements">${icon('check')} تم</button>
    </div>` : '';

  const totalTasksCount = allTasks.length;
  const doneTodayCount = allTasks.filter(t => state.tasksApproved[t.id] === todayStr()).length;
  const dayPct = totalTasksCount ? Math.round((doneTodayCount / totalTasksCount) * 100) : 0;
  const progressBar = `
    <div class="card">
      <div class="row" style="justify-content:space-between"><b>${icon('star')} تقدّم اليوم</b><span class="muted small">${doneTodayCount} / ${totalTasksCount}</span></div>
      <div class="stat-bar-track mt8"><div class="stat-bar-fill" style="width:${dayPct}%;background:var(--primary)"></div></div>
    </div>`;
  return `
  <div class="container">
    <div class="decor-banner">${icon('mosque')} ${icon('sparkle')} ${icon('moon')}</div>
    <h1 class="title">${icon('checklist')} ${tr('page_home')}</h1>
    ${progressBar}
    <p class="muted mb8">${icon('hands')} اضغط "حصل" بعد ما تخلص المهمة، وهتاخد نقاطها لما الوالدين يأكدوا</p>
    <p class="muted mb8 small">${icon('calendar')} كل المهام تتجدد تلقائيًا كل يوم جديد، عشان تقدر تكسب حسناتها من الأول من تاني</p>
    <button class="btn secondary block mb12" data-action="switch-tab" data-tab="prayerTimes">${icon('prayerTimes')} مواقيت الصلاة</button>
    ${encouragementBanner}
    <div class="card" style="border:1px solid var(--gold)">
      <div class="row"><b>${icon('sparkle')} اقتراح اليوم لك</b></div>
      <p class="mt8">${getDailySuggestion(state.childAge)}</p>
    </div>
    ${renderHadithOfTheDay()}
    <div class="card secret-friend-card mt12" data-action="open-secret-friend">
      <div class="row" style="gap:10px;align-items:center">
        <div class="secret-friend-avatar">${secretFriendMascotSvg(56)}</div>
        <div style="flex:1">
          <div style="font-weight:900">${icon('sparkle')} صديقك السري</div>
          <div class="muted small mt8">لو عملت غلطة أو في حاجة مضايقاك، احكيلي وهساعدك</div>
        </div>
      </div>
    </div>
    <div class="card">${rows || '<p class="muted">لا توجد مهام بعد</p>'}</div>
  </div>`;
}

// ============================== جزيرة الحسنات ==============================
// حيوانك الأليف يجري على الشاشة تلقائيًا فوق شريط التنقل، إحياءً للتطبيق (يمكن إيقافه من تاب "حيواني")
function renderRoamingPet() {
  if (!state.petRoamingEnabled) return '';
  const pet = pets.find(p => p.id === state.currentPet) || pets[0];
  if (!pet) return '';
  return `<div class="roaming-pet" data-action="pet-speak"><div class="roaming-pet-bob">${bigPetIcon(pet.icon)}</div></div>`;
}

// يظهر فقاعة كلام مؤقتة بجانب الحيوان الأليف عند الضغط عليه
function showPetBubble(text) {
  const old = document.getElementById('pet-bubble');
  if (old) old.remove();
  const bubble = document.createElement('div');
  bubble.id = 'pet-bubble';
  bubble.className = 'pet-bubble';
  bubble.textContent = text;
  document.body.appendChild(bubble);
  setTimeout(() => bubble.remove(), 4000);
}

function renderCertificateModal(id) {
  const a = achievementsList.find(x => x.id === id);
  if (!a) return '';
  const dateRaw = state.unlockedAchievements[id] || todayStr();
  const dparts = String(dateRaw).split('-'); // YYYY-MM-DD
  const day = dparts[2] || '', month = dparts[1] || '', year = dparts[0] || '';
  const frame = certificateFrames.find(f => f.id === state.currentCertFrame) || certificateFrames[0];
  // الشهادة صورة ثابتة (تصميم المستخدم الأصلي) مفيهاش أي تعديل؛ بس 3 حقول متغيرة بتتظبط فوقها: الاسم، الإنجاز، وأرقام التاريخ كل واحد في خانته
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <div class="certificate-frame-wrap" style="border:${frame.border}${hasTierAtLeast('gold-plan') ? ';box-shadow:0 0 18px 3px ' + (tierNameColor() || '#D9A441') + '99' : ''}">
        <div class="certificate-box">
          <img class="certificate-bg-img" src="icons/certificate-template.jpg" alt="شهادة تقدير" />
          <div class="cert-field cert-field-name">${esc(state.childName)}</div>
          <div class="cert-field cert-field-achv">${esc(a.title)}</div>
          <div class="cert-field cert-field-day">${esc(day)}</div>
          <div class="cert-field cert-field-month">${esc(month)}</div>
          <div class="cert-field cert-field-year">${esc(year)}</div>
        </div>
      </div>
      <button class="btn block mt16" data-action="share-achievement" data-id="${a.id}">${icon('chat')} شارك إنجازك</button>
      <button class="btn secondary block mt8" data-action="print-certificate">${icon('scroll')} طباعة الشهادة</button>
      <button class="btn secondary block mt8" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

function renderPetTab() {
  return `
  <div class="container">
    <h1 class="title">${icon('heart')} ${tr('page_pet')}</h1>
    <p class="muted mb8">اعتنِ به بحسناتك اليومية ليكبر ويسعد ويلعب معك</p>
    <button class="btn secondary block mb12" data-action="toggle-pet-roaming">
      ${icon(state.petRoamingEnabled ? 'stop' : 'checkCircle')} ${state.petRoamingEnabled ? 'إيقاف حركة الحيوان على الشاشة' : 'تشغيل حركة الحيوان على الشاشة'}
    </button>
    ${renderPetSection()}
  </div>`;
}

function renderIslandTab() {
  const unlocks = getIslandUnlocks(state.totalEarnedPoints);
  const scene = renderIslandScene(unlocks);
  const next = unlocks.next;
  const progressPct = next ? Math.min(100, Math.round((state.totalEarnedPoints / next.min) * 100)) : 100;

  const milestoneRows = islandMilestones.map(m => {
    const done = state.totalEarnedPoints >= m.min;
    return `<div class="island-milestone-row ${done ? 'done' : ''}">
      <span class="i">${icon(done ? 'checkCircle' : 'lock')}</span>
      <span>${m.label}</span>
      <span class="muted small" style="margin-inline-start:auto">${m.min} حسنة</span>
    </div>`;
  }).join('');

  return `
  <div class="container">
    <h1 class="title">${icon('tree')} ${tr('page_island')}</h1>
    <p class="muted mb8">كل حسنة تكسبها تجعل جزيرتك أجمل: أشجار، أزهار، مساجد، وطيور تظهر شيئًا فشيئًا</p>
    <div class="island-frame">${scene}</div>

    ${next ? `
    <div class="card mt12">
      <div class="row"><span class="muted small">حتى: ${next.label}</span><span class="muted small">${state.totalEarnedPoints} / ${next.min}</span></div>
      <div class="island-progress mt8"><div class="island-progress-fill" style="width:${progressPct}%"></div></div>
    </div>` : `<div class="card mt12 center"><b>${icon('crown')} ما شاء الله! جزيرتك اكتملت بكل زينتها</b></div>`}

    ${renderPetSection()}

    <div class="card mt12">
      <div class="row" style="cursor:pointer" data-action="toggle-island-milestones">
        <b>${icon('checklist')} كل مراحل الجزيرة</b>
        <span class="i">${icon(islandMilestonesOpen ? 'door' : 'door')}</span>
      </div>
      ${islandMilestonesOpen ? `<div class="mt8">${milestoneRows}</div>` : ''}
    </div>
  </div>`;
}

let islandMilestonesOpen = false;

// يبني مشهد الجزيرة كـ SVG واحد بحسب ما فُتح من مراحل، بدون أي صور خارجية
function renderIslandScene(u) {
  const treePositions = [[62, 150], [320, 145], [110, 168], [270, 172], [190, 158]];
  const grownTrees = treePositions.slice(0, u.treeCount).map(([x, y], i) => `
    <g transform="translate(${x},${y})" class="island-tree" style="animation-delay:${i * 0.15}s">
      <ellipse cx="0" cy="27" rx="15" ry="3.5" fill="rgba(0,0,0,.12)"/>
      <rect x="-3" y="8" width="6" height="19" rx="2.5" fill="url(#trunkGrad)"/>
      <circle cx="0" cy="-2" r="17" fill="url(#leafGradDark)"/>
      <circle cx="-10" cy="5" r="12" fill="url(#leafGrad)"/>
      <circle cx="10" cy="5" r="12" fill="url(#leafGrad)"/>
      <circle cx="0" cy="-6" r="11" fill="url(#leafGradLight)"/>
    </g>`).join('');
  // بذرة صغيرة في كل مكان لم تصبح شجرة بعد، حتى لا تبدو الجزيرة فارغة قبل جمع الحسنات
  const seedlings = treePositions.slice(u.treeCount).map(([x, y], i) => `
    <g transform="translate(${x},${y + 20}) scale(0.85)" class="island-seedling" style="color:#3C8055;animation-delay:${i * 0.2}s">${ICONS.seedling}</g>`).join('');

  const flowerPositions = [[40, 178], [140, 182], [230, 180], [300, 178], [180, 185]];
  const flowers = u.flowers ? flowerPositions.map(([x, y], i) => `
    <g transform="translate(${x},${y}) scale(0.5)" class="island-flower" style="animation-delay:${i * 0.2}s;color:${['#D9A441','#C1694F','#6C5A96','#4A5FA8','#D9A441'][i]}">${ICONS.flower}</g>`).join('') : '';

  const fountain = u.fountain ? `
    <g transform="translate(200,168) scale(1.1)" class="island-fountain" style="color:#4A5FA8">${ICONS.fountain}</g>` : '';

  const mosque = u.mosque ? `
    <g transform="translate(95,118)" class="island-mosque">
      <ellipse cx="0" cy="45" rx="38" ry="4" fill="rgba(0,0,0,.1)"/>
      <rect x="-24" y="16" width="48" height="27" rx="2" fill="url(#wallGrad)" stroke="#C9A24B" stroke-width="1.3"/>
      <path d="M-16 43V32a6 6 0 0 1 12 0v11Z" fill="#7A5A2E"/>
      <circle cx="0" cy="6" r="15" fill="url(#domeGrad)" stroke="#C9A24B" stroke-width="1.3"/>
      <rect x="-33" y="20" width="8" height="25" fill="url(#wallGrad)" stroke="#C9A24B" stroke-width="1.2"/>
      <rect x="25" y="20" width="8" height="25" fill="url(#wallGrad)" stroke="#C9A24B" stroke-width="1.2"/>
      <path d="M-33 20 L-29 8 L-25 20Z" fill="#C9A24B"/>
      <path d="M33 20 L29 8 L25 20Z" fill="#C9A24B"/>
      <circle cx="0" cy="-11" r="2.2" fill="#C9A24B"/>
      <path d="M0 -16 l-2.4 3.5 h4.8Z" fill="#C9A24B"/>
      <circle cx="-8" cy="30" r="2.6" fill="#EFE6D3" opacity=".8"/>
      <circle cx="8" cy="30" r="2.6" fill="#EFE6D3" opacity=".8"/>
    </g>` : '';

  const mosque2 = u.mosque2 ? `
    <g transform="translate(300,128) scale(0.8)" class="island-mosque">
      <rect x="-22" y="14" width="44" height="26" rx="2" fill="url(#wallGrad)" stroke="#C9A24B" stroke-width="1.3"/>
      <circle cx="0" cy="6" r="14" fill="url(#domeGrad)" stroke="#C9A24B" stroke-width="1.3"/>
      <circle cx="0" cy="-10" r="2" fill="#C9A24B"/>
    </g>` : '';

  const birds = u.birds ? `
    <g class="island-birds" style="color:#4A5FA8">
      <g transform="translate(60,40)" class="bird-fly-1">${ICONS.bird}</g>
      <g transform="translate(150,25) scale(0.8)" class="bird-fly-2">${ICONS.bird}</g>
    </g>` : '';

  const clouds = u.clouds ? `
    <g style="color:rgba(255,255,255,.85)">
      <g transform="translate(50,30) scale(1.4)" class="island-cloud cloud-1">${ICONS.cloud}</g>
      <g transform="translate(250,20) scale(1.1)" class="island-cloud cloud-2">${ICONS.cloud}</g>
    </g>` : `<g style="color:rgba(255,255,255,.6)"><g transform="translate(280,25) scale(1)" class="island-cloud cloud-1">${ICONS.cloud}</g></g>`;

  const rainbow = u.rainbow ? `
    <g transform="translate(200,190) scale(3.2)" style="color:#C1694F;opacity:.85" class="island-rainbow">${ICONS.rainbowArc}</g>` : '';

  // الشمس أو القمر يظهران دائمًا بحسب الوقت الحالي، لإحياء المشهد حتى قبل فتح أي مكافأة
  const night = isNightNow();
  const sunMoon = night
    ? `<circle cx="335" cy="35" r="16" fill="#EDEDF5"/><circle cx="329" cy="30" r="2.6" fill="#D8D8E8"/><circle cx="340" cy="41" r="1.8" fill="#D8D8E8"/>`
    : `<circle cx="335" cy="35" r="19" fill="url(#sunGrad)"/>`;

  return `
  <svg viewBox="0 0 400 220" class="island-svg">
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="var(--island-sky-top)"/>
        <stop offset="100%" stop-color="var(--island-sky-bottom)"/>
      </linearGradient>
      <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="var(--island-sea-top)"/>
        <stop offset="100%" stop-color="var(--island-sea-bottom)"/>
      </linearGradient>
      <radialGradient id="sunGrad" cx="35%" cy="30%" r="75%"><stop offset="0%" stop-color="#FFF3C4"/><stop offset="100%" stop-color="#F2C464"/></radialGradient>
      <linearGradient id="leafGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#4C9166"/><stop offset="100%" stop-color="#2F6B44"/></linearGradient>
      <linearGradient id="leafGradDark" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3C8055"/><stop offset="100%" stop-color="#215538"/></linearGradient>
      <linearGradient id="leafGradLight" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#6BAE86"/><stop offset="100%" stop-color="#4C9166"/></linearGradient>
      <linearGradient id="trunkGrad" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#9C6B3A"/><stop offset="100%" stop-color="#7A5228"/></linearGradient>
      <linearGradient id="wallGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FBF6EA"/><stop offset="100%" stop-color="#E9DBB8"/></linearGradient>
      <radialGradient id="domeGrad" cx="35%" cy="25%" r="80%"><stop offset="0%" stop-color="#FBF6EA"/><stop offset="100%" stop-color="#DCC98C"/></radialGradient>
    </defs>
    <rect x="0" y="0" width="400" height="220" fill="url(#sky)"/>
    ${sunMoon}
    ${rainbow}
    ${clouds}
    ${birds}
    <rect x="0" y="170" width="400" height="50" fill="url(#sea)"/>
    <path d="M0 178 Q30 174 60 178 T120 178 T180 178 T240 178 T300 178 T360 178 T400 178" fill="none" stroke="rgba(255,255,255,.35)" stroke-width="2" class="island-wave"/>
    <path d="M0 188 Q30 184 60 188 T120 188 T180 188 T240 188 T300 188 T360 188 T400 188" fill="none" stroke="rgba(255,255,255,.22)" stroke-width="2" class="island-wave" style="animation-delay:.4s"/>
    <path d="M0 178 Q40 172 80 178 T160 178 T240 178 T320 178 T400 178 V220 H0 Z" fill="var(--island-sand)"/>
    <path d="M20 178 Q100 150 200 156 T380 178 V178 Q200 200 20 178 Z" fill="var(--island-grass)"/>
    ${mosque}${mosque2}
    ${grownTrees}
    ${seedlings}
    ${flowers}
    ${fountain}
  </svg>`;
}

// ============================== قسم الحيوان الأليف ==============================
function getPetStage(totalPoints) {
  if (totalPoints >= 600) return 'grown';
  if (totalPoints >= 150) return 'young';
  return 'baby';
}
function isNightNow() {
  const h = new Date().getHours();
  return h >= 21 || h < 5;
}
function renderPetSection() {
  const pet = pets.find(p => p.id === state.currentPet) || pets[0];
  const stage = getPetStage(state.totalEarnedPoints);
  const night = isNightNow();
  const scale = stage === 'baby' ? 0.75 : stage === 'young' ? 1 : 1.3;
  const stageLabel = stage === 'baby' ? 'صغير' : stage === 'young' ? 'ناشئ' : 'كبير وقوي';

  const petShopItems = pets.map(p => {
    const owned = p.cost === 0 || state.petsOwned.includes(p.id) || hasAllAccess();
    const selected = state.currentPet === p.id;
    return `
    <div class="pet-shop-item ${selected ? 'selected' : ''}">
      <span class="i" style="width:26px;height:26px;color:var(--primary)">${icon(p.icon)}</span>
      <div class="small" style="font-weight:800">${p.name}</div>
      ${selected ? `<span class="badge">${icon('check')}</span>` :
        owned ? `<button class="btn secondary" data-action="select-pet" data-id="${p.id}">اختيار</button>` :
        `<button class="btn" data-action="buy-pet" data-id="${p.id}" data-cost="${p.cost}">${icon('coin')} ${p.cost}</button>`}
    </div>`;
  }).join('');

  return `
  <div class="card mt12 center pet-card">
    <div class="muted small mb8">رفيقك: ${pet.name} · ${stageLabel}${night ? ' · نائم الآن 🌙' : ''}</div>
    <div class="pet-stage-wrap" data-action="tap-pet" id="pet-figure" style="transform:scale(${scale})">
      <span class="pet-icon-big ${night ? 'pet-sleep' : 'pet-idle'}">${bigPetIcon(pet.icon)}</span>
      ${state.currentPetAccessory ? `<span class="pet-accessory-badge">${icon(petAccessories.find(a => a.id === state.currentPetAccessory)?.icon || 'star')}</span>` : ''}
    </div>
    <p class="muted small mt8">اضغط على ${pet.name} ليتفاعل معك</p>
    <div id="pet-msg-zone"></div>
    <div class="pet-shop-row mt12">${petShopItems}</div>
  </div>`;
}

let storyCategoryFilter = 'all';
function renderStoriesTab() {
  const filtered = storyCategoryFilter === 'all' ? stories : stories.filter(s => getStoryCategory(s.id) === storyCategoryFilter);
  const filterBtns = `<div class="story-filter-row">
    <button class="story-filter-btn ${storyCategoryFilter === 'all' ? 'active' : ''}" data-action="filter-stories" data-cat="all">الكل</button>
    ${Object.keys(STORY_CATEGORIES).map(k => `
      <button class="story-filter-btn ${storyCategoryFilter === k ? 'active' : ''}" data-action="filter-stories" data-cat="${k}">${STORY_CATEGORIES[k].label}</button>
    `).join('')}
  </div>`;
  const items = filtered.map(s => {
    const cost = storyCost(s.id);
    const owned = state.storiesOwned.includes(s.id) || hasAllAccess();
    const cat = STORY_CATEGORIES[getStoryCategory(s.id)];
    return `
    <div class="story-item" data-action="${owned ? 'open-story' : 'buy-story'}" data-id="${s.id}" data-cost="${cost}">
      <div class="emoji" style="background:linear-gradient(145deg,${cat.c1},${cat.c2})">${owned ? icon(cat.icon) : icon('lock')}</div>
      <div class="info">
        <div class="t">${s.title}</div>
        <div class="s">${s.teaser || ''}</div>
        <div class="story-cat-chip">${cat.label}</div>
      </div>
      ${owned ? '' : `<span class="badge">${icon('coin')} ${cost}</span>`}
    </div>`;
  }).join('');
  return `<div class="container"><h1 class="title">${icon('bookOpenStar')} ${tr('page_stories')}</h1>${filterBtns}${items}</div>`;
}

// ============================== اختر مغامرتك: نقطة قرار تفاعلية داخل قصص الأخلاق ==============================
const storyDecisionChoice = {}; // storyId -> 'A' | 'B' (مؤقت أثناء الجلسة، مش محفوظ بشكل دائم)
function hashStr(str) { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0; return h; }
// كل قصة سعرها 500 نقطة على الأقل (بحد أقصى 2000)، السعر ثابت لكل قصة حسب معرّفها
function storyCost(id) { return 500 + (hashStr(String(id)) % 31) * 50; }

function renderStoryDecision(storyId) {
  const tpl = storyDecisionTemplates[hashStr(storyId) % storyDecisionTemplates.length];
  const choice = storyDecisionChoice[storyId];
  if (!choice) {
    return `
    <div class="card mt12" style="border:2px dashed var(--gold)">
      <div style="font-weight:900">${icon('compass')} اختر مغامرتك</div>
      <p class="mt8">${tpl.prompt}</p>
      <button class="btn block mt8" data-action="story-decision" data-story="${storyId}" data-choice="A">${tpl.optionA}</button>
      <button class="btn secondary block mt8" data-action="story-decision" data-story="${storyId}" data-choice="B">${tpl.optionB}</button>
    </div>`;
  }
  const wisdom = choice === 'A' ? tpl.wisdomA : tpl.wisdomB;
  return `
  <div class="card mt12" style="border:2px solid var(--primary)">
    <div style="font-weight:900">${icon('sparkle')} الحكمة</div>
    <p class="mt8">${wisdom}</p>
  </div>`;
}

function renderStoryReader(id) {
  const s = stories.find(x => x.id === id);
  if (!s) return '';
  const cost = storyCost(s.id);
  const owned = state.storiesOwned.includes(s.id) || hasAllAccess();
  const cover = storyCoverScene(getStoryCategory(s.id));
  if (!owned) {
    return `
    <div class="modal-overlay" data-action="close-modal-overlay">
      <div class="modal-box" onclick="event.stopPropagation()">
        <div class="story-cover">${cover}</div>
        <h2 style="text-align:center;font-weight:900;margin:10px 0">${s.title}</h2>
        <p class="muted center">${s.teaser || ''}</p>
        <div class="mt16"></div>
        <button class="btn block" data-action="buy-story" data-id="${s.id}" data-cost="${cost}">${icon('coin')} افتح القصة مقابل ${cost}</button>
        <button class="btn secondary block mt8" data-action="close-modal">${tr("close")}</button>
      </div>
    </div>`;
  }
  const catId = getStoryCategory(s.id);
  const paragraphs = s.content.split('\n\n');
  // نعرض لوحة كوميك مصوّرة كل فقرتين تقريبًا (بحد أدنى 3 لوحات لأي قصة قصيرة) لإعطاء إحساس القصة المصوّرة الحقيقية
  const panelEvery = 2;
  // في قصص الأخلاق نضيف نقطة قرار تفاعلية "اختر مغامرتك" في منتصف القصة تقريبًا
  const decisionAt = catId === 'akhlaq' ? Math.ceil(paragraphs.length / 2) : -1;
  const storyBody = paragraphs.map((p, i) => {
    const panel = (i > 0 && i % panelEvery === 0) ? comicPanel(catId, Math.floor(i / panelEvery)) : '';
    const decision = (i === decisionAt) ? renderStoryDecision(s.id) : '';
    return `${panel}<p class="mt12">${p}</p>${decision}`;
  }).join('');
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <div class="reader">
        <div class="story-cover">${cover}</div>
        <h2>${s.title}</h2>
        <div class="center mb8" id="narrator-controls" data-text="${encodeURIComponent(s.title + '. ' + s.content)}">
          <button class="btn" data-action="narrate-toggle">${icon('speaker')} استمع للقصة</button>
          <button class="btn secondary" data-action="narrate-stop" style="display:none">${icon('stop')} إيقاف</button>
        </div>
        <div class="mt12">${storyBody}</div>
      </div>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// اختيار عنصر عشوائي جديد من مجموعة أسئلة، مع تفادي تكرار نفس السؤال الذي ظهر قبل قليل مباشرة
// (بهذا الشكل تبدو الأسئلة كأنها لا تنتهي أبدًا مهما لعب الطفل)
function pickNextIndex(poolLength, avoid) {
  if (poolLength <= 1) return 0;
  let idx;
  do { idx = Math.floor(Math.random() * poolLength); } while (idx === avoid);
  return idx;
}

// ---- الاختبار ----
let quizIndex = null;
let lastQuizIndex = null;
function renderQuizTab() {
  if (quizIndex === null) quizIndex = pickNextIndex(quizQuestions.length, lastQuizIndex);
  const q = quizQuestions[quizIndex];
  const opts = q.options.map((opt, i) =>
    `<button class="btn secondary block mt8" data-action="answer-quiz" data-i="${i}">${opt}</button>`
  ).join('');
  return `
  <div class="container">
    <h1 class="title">${icon('brain')} ${tr('page_quiz')}</h1>
    <div class="card">
      <div style="font-weight:800;font-size:16px">${q.q}</div>
      <div class="mt16">${opts}</div>
    </div>
  </div>`;
}

// ---- التحديات: يومي + أسبوعي + مناسبات ----
function renderChallengesTab() {
  const target = 3;
  const todayCount = state.tasksApprovedToday || 0;
  const dailyClaimed = state.dailyChallengeClaimed === todayStr();
  const dailyReady = todayCount >= target;
  const weekKey = getWeekKey();
  const weeklyClaimed = state.weeklyChallengeClaimed === weekKey;
  const weeklyReady = (state.loginStreak || 0) >= 3;
  const seasonal = getCurrentIslamicEvent();
  const weekly = getWeeklyEvent();

  return `
  <div class="container">
    <h1 class="title">${icon('star')} ${tr('page_challenges')}</h1>
    <p class="muted mb8">تحديات يومية وأسبوعية تزيد حماسك لفعل الخير</p>

    <div class="card mt12">
      <div class="row"><b>${icon('checklist')} تحدي اليوم</b></div>
      <p class="muted small mt8">أنجز ${target} مهام اليوم (${Math.min(todayCount, target)}/${target})</p>
      <div class="island-progress mt8"><div class="island-progress-fill" style="width:${Math.min(100, todayCount / target * 100)}%"></div></div>
      ${dailyClaimed
        ? `<button class="btn secondary block mt12" disabled>${icon('check')} تم استلام مكافأة اليوم</button>`
        : dailyReady
          ? `<button class="btn block mt12" data-action="claim-daily-challenge">${icon('gift')} استلم 30 نقطة</button>`
          : `<button class="btn secondary block mt12" disabled>أكمل مهامك أولاً</button>`}
    </div>

    <div class="card mt12">
      <div class="row"><b>${icon('calendar')} تحدي الأسبوع</b></div>
      <p class="muted small mt8">افتح التطبيق 3 أيام متتالية (${Math.min(state.loginStreak || 0, 3)}/3)</p>
      <div class="island-progress mt8"><div class="island-progress-fill" style="width:${Math.min(100, (state.loginStreak || 0) / 3 * 100)}%"></div></div>
      ${weeklyClaimed
        ? `<button class="btn secondary block mt12" disabled>${icon('check')} تم استلام مكافأة الأسبوع</button>`
        : weeklyReady
          ? `<button class="btn block mt12" data-action="claim-weekly-challenge">${icon('gift')} استلم 60 نقطة</button>`
          : `<button class="btn secondary block mt12" disabled>استمر في الدخول يوميًا</button>`}
    </div>

    ${(state.parentChallenges || []).filter(c => c.status !== 'done').map(c => `
    <div class="card mt12" style="border:1px solid var(--primary)">
      <div class="row"><b>${icon('sparkle')} ${esc(c.name)}</b></div>
      <p class="muted small mt8">تحدي خاص من والديك، قيمته ${c.points} نقطة</p>
      ${c.status === 'pending'
        ? `<button class="btn secondary block mt12" disabled>${icon('hourglass')} بانتظار تأكيد الوالدين</button>`
        : `<button class="btn block mt12" data-action="complete-parent-challenge" data-id="${c.id}">${icon('check')} أنجزت التحدي!</button>`}
    </div>`).join('')}

    ${weekly ? `
    <div class="card mt12">
      <div class="row"><b>${icon(weekly.icon)} ${weekly.name}</b></div>
      <p class="muted small mt8">${weekly.message}</p>
    </div>` : ''}

    ${seasonal ? `
    <div class="card mt12" style="border:1px solid var(--gold)">
      <div class="row"><b>${icon(seasonal.icon)} ${seasonal.name}</b></div>
      <p class="muted small mt8">${seasonal.message}</p>
      <p class="muted small mt8">${icon('gift')} مكافأة هذه المناسبة متاحة أعلى الصفحة الرئيسية</p>
    </div>` : ''}
  </div>`;
}

// ---- الألعاب الإسلامية ----
// ============================== فاعل الخير: محادثة إرشادية (تحاول الاتصال بذكاء اصطناعي خارجي، وتتراجع تلقائيًا للنظام المحلي الآمن عند أي مشكلة) ==============================
let assistantChat = []; // { role:'user'|'assistant', kind:'text'|'image'|'audio', text?, src? } - مؤقتة أثناء الجلسة فقط
let assistantMediaRecorder = null;
let assistantThinking = false;
const ASSISTANT_API_URL = 'https://apis.davidcyril.name.ng/ai/felo'; // API خارجي مجهول (احتياطي حاليًا)
// السيرفر الخاص بيك (لو شغّلته من مجلد backend/ المرفق) — لما تحطه شغال، بدّل القيمة دي برابطه الحقيقي
const OWN_ASSISTANT_SERVER_URL = ''; // مثال: 'https://your-server.com/ask'
const ASSISTANT_API_TIMEOUT_MS = 8000;
// كلمات غير مناسبة إطلاقًا لتطبيق أطفال - أي رد يحتوي عليها يُستبعد فورًا ويُستبدل بالرد المحلي الآمن
const ASSISTANT_UNSAFE_PATTERNS = [/جنس/i, /عاري/i, /مخدرات/i, /انتحار/i, /سياس/i, /كافر/i, /طائفي/i];
function isAssistantReplyUnsafe(text) {
  if (!text || typeof text !== 'string') return true;
  if (text.length > 1200) return true; // رد طويل جدًا غالبًا خرج عن السياق
  return ASSISTANT_UNSAFE_PATTERNS.some(p => p.test(text));
}
async function pushAssistantReply(text) {
  assistantThinking = true;
  render();
  const localFallback = pickAssistantReply(text);
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ASSISTANT_API_TIMEOUT_MS);
    const framedQuestion = 'أنت مساعد إسلامي اسمه "فاعل الخير" داخل تطبيق أطفال، جاوب بالعربية بإجابة قصيرة ومحترمة ومناسبة للأطفال المسلمين فقط، وابتعد عن أي موضوع سياسي أو جدلي أو غير لائق. السؤال: ' + text;
    let reply;
    if (OWN_ASSISTANT_SERVER_URL) {
      // لو حاطط رابط سيرفرك الخاص (اللي بيشغّل opencode)، استخدمه بدل الـ API الخارجي المجهول
      const res = await fetch(OWN_ASSISTANT_SERVER_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: text }),
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error('bad status');
      const data = await res.json();
      reply = data && data.response;
    } else {
      const res = await fetch(ASSISTANT_API_URL + '?text=' + encodeURIComponent(framedQuestion), { signal: controller.signal });
      clearTimeout(timer);
      if (!res.ok) throw new Error('bad status');
      const data = await res.json();
      reply = extractAssistantApiText(data);
    }
    if (isAssistantReplyUnsafe(reply)) throw new Error('unsafe or empty reply');
    assistantChat.push({ role: 'assistant', kind: 'text', text: reply });
  } catch (e) {
    // أي مشكلة (لا إنترنت، تأخير، رد فاضي أو غير مناسب) → نرجع فورًا للنظام المحلي الآمن بدل ما نسيب الطفل من غير رد
    assistantChat.push({ role: 'assistant', kind: 'text', text: localFallback });
  }
  assistantThinking = false;
  render();
}
// يحاول استخراج النص الرئيسي من أشكال استجابة JSON المختلفة المحتملة
function extractAssistantApiText(data) {
  if (!data) return null;
  if (typeof data === 'string') return data;
  const fields = ['response', 'text', 'message', 'content', 'reply', 'answer', 'result'];
  for (const f of fields) {
    if (typeof data[f] === 'string' && data[f].trim()) return data[f].trim();
  }
  return null;
}
function renderAssistantTab() {
  const bubbles = assistantChat.map(m => {
    const cls = m.role === 'user' ? 'user' : 'assistant';
    let inner = '';
    if (m.kind === 'text') inner = esc(m.text).replace(/\n/g, '<br>');
    else if (m.kind === 'image') inner = `<img class="assistant-img" src="${m.src}" />`;
    else if (m.kind === 'audio') inner = `<audio controls src="${m.src}" style="max-width:100%"></audio>`;
    return `<div class="assistant-bubble ${cls}">${inner}</div>`;
  }).join('') + (assistantThinking ? `<div class="assistant-bubble assistant">${icon('hourglass')} بيفكر...</div>` : '');
  const suggestions = assistantChat.length ? '' : `<div class="assistant-suggestions">${assistantSuggestedQuestions.map(q => `
    <button class="assistant-suggestion" data-action="ask-suggested" data-q="${esc(q)}">${esc(q)}</button>`).join('')}</div>`;
  return `<div class="container">
    <h1 class="title">${icon('sparkle')} ${tr('page_assistant')}</h1>
    <p class="muted mb8">اسأل عن أي حاجة في ديننا وهساعدك بإذن الله</p>
    <p class="muted small mb8">${icon('warning')} الإجابات بتيجي من نظام ذكاء اصطناعي، ممكن تخطئ أحيانًا، راجع دايمًا مع والديك</p>
    ${suggestions}
    <div class="assistant-chat">
      ${bubbles || '<p class="muted center">ابدأ بسؤال من فوق أو اكتب سؤالك تحت 👇</p>'}
    </div>
    <div class="assistant-composer">
      <button class="icon-btn" data-action="assistant-attach-image">${icon('camera')}</button>
      <button class="icon-btn ${assistantMediaRecorder ? 'recording' : ''}" data-action="assistant-toggle-record">${icon('mic')}</button>
      <input type="text" id="assistant-input" placeholder="اكتب سؤالك هنا..." />
      <button class="icon-btn" style="background:var(--primary);color:#fff" data-action="ask-assistant">${icon('sendIcon')}</button>
    </div>
    <input type="file" id="assistant-image-input" accept="image/*" style="display:none" onchange="handleAssistantImage(this)" />
  </div>`;
}

let gameType = 'ayah';
let gameIndex = null;
let lastAyahIndex = null;
let lastSahabaIndex = null;
let lastTrueFalseIndex = null;
let lastAsmaIndex = null;
let lastRevelationIndex = null;
let scrambleWordIndex = null;
let scrambleBuffer = []; // مصفوفة أرقام الحروف اللي الطفل اختارها بالترتيب

const GAME_MODES = [
  { id: 'ayah', label: 'أكمل الآية', icon: 'bookOpenStar' },
  { id: 'sahaba', label: 'من الصحابي؟', icon: 'shield' },
  { id: 'truefalse', label: 'صح ولا غلط', icon: 'checkCircle' },
  { id: 'asma', label: 'اسم الله الحسنى', icon: 'star' },
  { id: 'revelation', label: 'مكية ولا مدنية؟', icon: 'mosque' },
  { id: 'scramble', label: 'رتب الحروف', icon: 'pen' },
];

function renderGamesTab() {
  const switcher = `
    <div class="story-filter-row">${GAME_MODES.map(m => `
      <button class="story-filter-btn ${gameType === m.id ? 'active' : ''}" data-action="switch-game" data-game="${m.id}">${icon(m.icon)} ${m.label}</button>`).join('')}
    </div>`;
  let body;

  if (gameType === 'ayah') {
    if (gameIndex === null) gameIndex = pickNextIndex(ayahGames.length, lastAyahIndex);
    const g = ayahGames[gameIndex];
    const opts = shuffle(g.options).map(opt =>
      `<button class="btn secondary block mt8" data-action="answer-ayah-game" data-answer="${esc(g.blank)}" data-picked="${esc(opt)}">${esc(opt)}</button>`).join('');
    body = `
    <div class="card mt16">
      <p class="muted small">أكمل الآية الكريمة بالكلمة الصحيحة</p>
      <div style="font-size:20px;font-weight:800;line-height:2.2;text-align:center" dir="rtl">${g.text}</div>
      <div class="mt16">${opts}</div>
    </div>`;

  } else if (gameType === 'sahaba') {
    if (gameIndex === null) gameIndex = pickNextIndex(sahabaGames.length, lastSahabaIndex);
    const g = sahabaGames[gameIndex];
    const opts = g.options.map((opt, i) =>
      `<button class="btn secondary block mt8" data-action="answer-sahaba-game" data-i="${i}">${esc(opt)}</button>`).join('');
    body = `
    <div class="card mt16">
      <div style="font-weight:800;font-size:16px">${esc(g.q)}</div>
      <div class="mt16">${opts}</div>
    </div>`;

  } else if (gameType === 'truefalse') {
    if (gameIndex === null) gameIndex = pickNextIndex(trueFalseGames.length, lastTrueFalseIndex);
    const g = trueFalseGames[gameIndex];
    body = `
    <div class="card mt16">
      <p class="muted small">هل العبارة دي صح ولا غلط؟</p>
      <div style="font-weight:800;font-size:17px;line-height:2;text-align:center">${esc(g.q)}</div>
      <div class="row mt16" style="gap:8px">
        <button class="btn block" style="background:#2F6B44" data-action="answer-truefalse-game" data-picked="true">${icon('checkCircle')} صح</button>
        <button class="btn block" style="background:#C0392B" data-action="answer-truefalse-game" data-picked="false">${icon('xCircle')} غلط</button>
      </div>
    </div>`;

  } else if (gameType === 'asma') {
    if (gameIndex === null) gameIndex = pickNextIndex(asmaAlHusna.length, lastAsmaIndex);
    const g = asmaAlHusna[gameIndex];
    let wrongPool = shuffle(asmaAlHusna.filter((x, i) => i !== gameIndex)).slice(0, 3).map(x => x.name);
    const opts = shuffle([g.name, ...wrongPool]).map(opt =>
      `<button class="btn secondary block mt8" data-action="answer-asma-game" data-picked="${esc(opt)}" data-answer="${esc(g.name)}">${esc(opt)}</button>`).join('');
    body = `
    <div class="card mt16">
      <p class="muted small">أي اسم من أسماء الله الحسنى يدل على المعنى ده؟</p>
      <div style="font-weight:800;font-size:17px;line-height:2;text-align:center">${esc(g.meaning)}</div>
      <div class="mt16">${opts}</div>
    </div>`;

  } else if (gameType === 'revelation') {
    if (gameIndex === null) gameIndex = pickNextIndex(surahs.length, lastRevelationIndex);
    const g = surahs[gameIndex];
    body = `
    <div class="card mt16">
      <p class="muted small">هل سورة "${esc(g.name)}" مكية ولا مدنية؟</p>
      <div style="font-weight:900;font-size:22px;text-align:center;margin:10px 0">${esc(g.name)}</div>
      <div class="row mt16" style="gap:8px">
        <button class="btn block" data-action="answer-revelation-game" data-picked="مكية" data-answer="${esc(g.revelation)}">مكية</button>
        <button class="btn block" data-action="answer-revelation-game" data-picked="مدنية" data-answer="${esc(g.revelation)}">مدنية</button>
      </div>
    </div>`;

  } else if (gameType === 'scramble') {
    if (scrambleWordIndex === null) { scrambleWordIndex = Math.floor(Math.random() * wordScrambleGames.length); scrambleBuffer = []; }
    const g = wordScrambleGames[scrambleWordIndex];
    const letters = g.word.split('');
    // نحافظ على ترتيب خلط ثابت طول محاولة الطفل عن طريق تخزينه بترتيب الفهارس بدل الحروف نفسها
    if (!window.__scrambleOrder || window.__scrambleOrderWord !== g.word) {
      window.__scrambleOrder = shuffle(letters.map((_, i) => i));
      window.__scrambleOrderWord = g.word;
    }
    const order = window.__scrambleOrder;
    const chosenSet = new Set(scrambleBuffer);
    const tiles = order.map(i => `
      <button class="btn secondary" style="min-width:44px;opacity:${chosenSet.has(i) ? '.35' : '1'}" ${chosenSet.has(i) ? 'disabled' : ''} data-action="scramble-pick" data-i="${i}">${esc(letters[i])}</button>`).join('');
    const builtWord = scrambleBuffer.map(i => letters[i]).join('');
    body = `
    <div class="card mt16">
      <p class="muted small">رتّب الحروف عشان تكوّن الكلمة الصحيحة</p>
      <p class="muted small">تلميح: ${esc(g.hint)}</p>
      <div class="center" style="font-weight:900;font-size:26px;min-height:40px;letter-spacing:4px;margin:14px 0">${esc(builtWord) || '⬦⬦⬦⬦'}</div>
      <div class="center" style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${tiles}</div>
      <div class="row mt16" style="gap:8px">
        <button class="btn secondary block" data-action="scramble-clear">${icon('xCircle')} مسح</button>
        <button class="btn block" data-action="scramble-submit">${icon('check')} تأكيد</button>
      </div>
    </div>`;
  }

  return `
  <div class="container">
    <h1 class="title">${icon('gift')} ${tr('page_games')}</h1>
    <p class="muted mb8">العب واكسب نقاطًا وأنت تتعلم</p>
    ${switcher}${body}
  </div>`;
}

// ---- المكافآت: هدية يومية + عجلة حظ أسبوعية + هدية شهرية ----
const wheelPrizes = [15, 25, 40, 60, 100, 30, 50, 20];
let wheelSpinning = false;
function wheelColors() { return ['#2F6B44', '#D9A441', '#4A5FA8', '#C0392B', '#3C8055', '#C9A24B', '#6C5A96', '#8B5A2B']; }
function wheelBackground() {
  const colors = wheelColors(); const n = wheelPrizes.length; const seg = 360 / n;
  return `conic-gradient(${colors.map((c, i) => `${c} ${i * seg}deg ${(i + 1) * seg}deg`).join(', ')})`;
}
function wheelLabelsHtml() {
  const n = wheelPrizes.length; const seg = 360 / n;
  return wheelPrizes.map((p, i) => {
    const angle = i * seg + seg / 2;
    return `<span class="wheel-label" style="transform:rotate(${angle}deg) translateY(-64px) rotate(${-angle}deg)">${p}</span>`;
  }).join('');
}
function renderRewardsTab() {
  const dailyDone = state.lastDailyGiftDate === todayStr();
  const weeklyDone = state.lastWheelWeek === getWeekKey();
  const monthlyDone = state.lastMonthlyGift === getMonthKey();
  return `
  <div class="container">
    <h1 class="title">${icon('gift')} ${tr('page_rewards')}</h1>
    <p class="muted mb8">هدايا يومية وأسبوعية وشهرية تنتظرك، استمر في فعل الخير لتستحقها</p>

    <div class="card mt12 reward-card">
      <div class="row"><b>${icon('gift')} الهدية اليومية</b></div>
      <p class="muted small mt8">افتح صندوق مفاجآت مليء بالنقاط كل يوم</p>
      ${dailyDone
        ? `<button class="btn secondary block mt12" disabled>${icon('check')} فتحتها اليوم، عُد غدًا</button>`
        : `<button class="btn block mt12" data-action="open-daily-gift">${icon('gift')} افتح الهدية</button>`}
    </div>

    <div class="card mt12 reward-card center">
      <b>${icon('sparkle')} عجلة الحظ الأسبوعية</b>
      <p class="muted small mt8">أدرها مرة كل أسبوع واكسب نقاطًا مفاجئة</p>
      <div class="wheel-wrap mt12">
        <div class="wheel" id="luck-wheel" style="background:${wheelBackground()}">${wheelLabelsHtml()}</div>
        <div class="wheel-pointer">${icon('star')}</div>
      </div>
      ${weeklyDone
        ? `<button class="btn secondary block mt12" disabled>${icon('check')} أدرتها هذا الأسبوع</button>`
        : `<button class="btn block mt12" data-action="spin-wheel">${icon('sparkle')} أدر العجلة</button>`}
    </div>

    <div class="card mt12 reward-card">
      <div class="row"><b>${icon('crown')} الهدية الشهرية</b></div>
      <p class="muted small mt8">مكافأة كبيرة تُفتح مرة كل شهر لمن يواظب</p>
      ${monthlyDone
        ? `<button class="btn secondary block mt12" disabled>${icon('check')} استلمتها هذا الشهر</button>`
        : `<button class="btn block mt12" data-action="open-monthly-gift">${icon('crown')} استلم الهدية</button>`}
    </div>
  </div>`;
}

// ---- الإنجازات ----
function renderAchievementsTab() {
  const unlockedCount = achievementsList.filter(a => state.unlockedAchievements[a.id]).length;
  const rows = achievementsList.map(a => {
    const unlocked = !!state.unlockedAchievements[a.id];
    const canCertify = unlocked && a.certifiable;
    return `
    <div class="list-item" ${canCertify ? `data-action="open-certificate" data-id="${a.id}"` : ''}>
      <div class="emoji" style="${unlocked ? '' : 'filter:grayscale(1);opacity:.4'}">${icon(a.icon)}</div>
      <div class="info"><div class="t">${a.title}</div><div class="s">${a.desc}</div></div>
      <span class="i" style="width:20px;height:20px;color:${unlocked ? 'var(--primary)' : 'var(--muted-foreground)'}">${icon(unlocked ? (canCertify ? 'scroll' : 'checkCircle') : 'lock')}</span>
    </div>`;
  }).join('');
  return `
  <div class="container">
    <h1 class="title">${icon('crown')} ${tr('page_achievements')}</h1>
    <p class="muted mb8">فتحت ${unlockedCount} من ${achievementsList.length} إنجازًا، استمر في فعل الخير لتفتح البقية. الإنجازات الكبيرة (زي حفظ سور القرآن أو الأحاديث) بتفتحلك شهادة تقدير رسمية 📜 — اضغط عليها لطباعتها</p>
    ${rows}
    ${renderStatsChart()}
  </div>`;
}

// ---- إحصائيات بسيطة برسم بياني SVG بدون أي مكتبات خارجية ----
function renderStatsChart() {
  const stats = [
    { label: 'الحسنات', value: state.tasksApprovedTotal || 0, max: 100, color: 'var(--primary)' },
    { label: 'الأذكار', value: state.dhikrCompletedCount || 0, max: 50, color: 'var(--gold)' },
    { label: 'القرآن (محفوظ)', value: state.memorizedSurahs.length || 0, max: 20, color: '#4A5FA8' },
    { label: 'الاختبارات', value: state.quizCorrectCount || 0, max: 50, color: '#C1694F' },
    { label: 'الإنجازات', value: Object.keys(state.unlockedAchievements).length, max: achievementsList.length, color: '#6C5A96' },
    { label: 'أيام متتالية', value: state.loginStreak || 0, max: 30, color: '#3C8055' },
  ];
  const bars = stats.map(s => {
    const pct = Math.min(100, Math.round((s.value / s.max) * 100));
    return `
    <div class="stat-row">
      <div class="stat-label">${s.label}</div>
      <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${pct}%;background:${s.color}"></div></div>
      <div class="stat-value">${s.value}</div>
    </div>`;
  }).join('');
  return `
  <div class="card mt16">
    <h2 class="section-title">${icon('star')} إحصائياتي</h2>
    ${bars}
  </div>`;
}
let surahSearchQuery = '';
function handleSurahSearch(v) {
  surahSearchQuery = v;
  render();
  const el = document.getElementById('surah-search');
  if (el) { el.focus(); el.selectionStart = el.selectionEnd = el.value.length; }
}
function renderQuranTab() {
  const lastSurah = state.lastOpenedSurah ? surahs.find(x => x.id === state.lastOpenedSurah) : null;
  const continueCard = lastSurah ? `
    <div class="card" data-action="open-surah" data-id="${lastSurah.id}" style="cursor:pointer;border:1px solid var(--primary)">
      <div class="row"><b>${icon('bookOpenStar')} أكمل من حيث توقفت</b></div>
      <p class="mt8">${esc(lastSurah.name)}</p>
    </div>` : '';
  const q = surahSearchQuery.trim();
  const filtered = q ? surahs.filter(s => s.name.includes(q)) : surahs;
  const items = filtered.map(s => {
    const memorized = state.memorizedSurahs.includes(s.id);
    return `
    <div class="list-item" data-action="open-surah" data-id="${s.id}">
      <div class="emoji">${icon('bookOpenStar')}</div>
      <div class="info"><div class="t">${s.name}</div><div class="s">${s.revelation} · ${s.versesCount} آية</div></div>
      ${memorized ? `<span class="badge">${icon('star')} محفوظة</span>` : ''}
    </div>`;
  }).join('');
  const memCount = state.memorizedSurahs.length;
  return `<div class="container"><h1 class="title">${icon('bookOpenStar')} ${tr('page_quran')}</h1>
    <p class="muted mb8">حفظت ${memCount} من ${surahs.length} سورة حتى الآن، استمر بارك الله فيك</p>
    ${continueCard}
    <input type="text" id="surah-search" value="${esc(surahSearchQuery)}" placeholder="ابحث عن سورة..." class="mb12" oninput="handleSurahSearch(this.value)" />
    ${items || '<p class="muted center">لا توجد سورة بهذا الاسم</p>'}</div>`;
}

function renderSurahDetail(id) {
  const s = surahs.find(x => x.id === Number(id));
  if (!s) return '';
  state.lastOpenedSurah = s.id; saveState();
  const audioUrl = `https://cdn.islamic.network/quran/audio-surah/128/${state.selectedReciter || 'ar.alafasy'}/${s.id}.mp3`;
  const progress = (state.ayahMemoryProgress && state.ayahMemoryProgress[s.id]) || 0;
  const pending = state.ayahMemoryPending && state.ayahMemoryPending[s.id];
  const pct = Math.min(100, Math.round((progress / s.versesCount) * 100));
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 style="text-align:center;font-weight:900">${s.name}</h2>
      <p class="muted center">${s.revelation} · ${s.versesCount} آية · السورة رقم ${s.id}</p>

      <div class="card mt12" style="border:1px solid var(--gold)">
        <div style="font-weight:900">${icon('star')} تحدي الحفظ آية بآية</div>
        <div class="stat-row mt8">
          <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${pct}%;background:var(--primary)"></div></div>
          <div class="stat-value">${progress}/${s.versesCount}</div>
        </div>
        <p class="muted small mt8">كل آية تحفظها وتؤكدها لوالديك = نقاط، وكل 5 آيات = جائزة إضافية!</p>
        ${progress >= s.versesCount
          ? `<div class="badge mt8" style="display:inline-block">${icon('crown')} أتممت حفظ السورة كاملة! 🎉</div>`
          : pending
            ? `<button class="btn secondary block mt8" disabled>${icon('hourglass')} بانتظار تأكيد الوالدين (حتى الآية ${pending})</button>`
            : `<div class="mt12">
                <div class="center" style="font-weight:800">وصلت في حفظك لحد الآية رقم <span id="ayah-slider-val-${s.id}" style="color:var(--primary);font-size:20px">${progress + 1}</span> من ${s.versesCount}</div>
                <input type="range" id="ayah-slider-${s.id}" min="${progress + 1}" max="${s.versesCount}" step="1" value="${progress + 1}" style="width:100%;margin-top:8px" oninput="document.getElementById('ayah-slider-val-${s.id}').textContent=this.value" />
                <div class="muted small center">اسحب الشريط ووقّفه عند آخر آية حفظتها بالظبط</div>
                <button class="btn block mt8" data-action="request-ayah-memorized" data-id="${s.id}">${icon('sparkle')} أرسل للتأكيد</button>
              </div>`}
      </div>

      <div class="center mt8">
        <button class="btn" data-action="play-surah-audio" data-url="${audioUrl}">${icon('speaker')} استماع للتلاوة</button>
        <button class="btn secondary mt8" data-action="open-reciter-picker">${icon('sparkle')} اختر صوت الشيخ (${esc((quranReciters.find(r => r.id === (state.selectedReciter || 'ar.alafasy')) || {}).name || '')})</button>

      </div>
      <audio id="surah-audio-player" style="width:100%;margin-top:10px;display:none" controls></audio>
      <p class="muted center small mt8">${icon('sparkle')} كرر الاستماع والقراءة عدة مرات، فالتكرار أفضل طريقة للحفظ</p>

      <div class="reader mt16" id="surah-text-${s.id}" dir="rtl">
        ${(currentQuranSurahId === s.id && quranPages.length > 0) ? '' : '<p class="muted center">جاري تحميل نص السورة من مصحف موثوق (يحتاج إنترنت)...</p>'}
      </div>

      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// يجلب النص الحقيقي للسورة من مصدر قرآني موثوق (API عام معروف) بدل كتابته يدوياً لتفادي أي خطأ
let currentQuranSurahId = null;
let quranPages = [];
let quranPageIndex = 0;
const QURAN_AYAHS_PER_PAGE = 6;

function loadSurahText(id) {
  const container = document.getElementById('surah-text-' + id);
  if (!container) return;
  if (currentQuranSurahId === Number(id) && quranPages.length > 0) {
    // النص محمّل مسبقًا في الذاكرة لنفس السورة، مفيش داعي نجيبه من النت تاني
    renderQuranPage(container); bindContainer(container); return;
  }
  currentQuranSurahId = Number(id);
  fetch(`https://api.alquran.cloud/v1/surah/${id}/quran-uthmani`)
    .then(r => { if (!r.ok) throw new Error('bad-response'); return r.json(); })
    .then(json => {
      const ayahs = (json && json.data && json.data.ayahs) || [];
      if (!ayahs.length) throw new Error('empty');
      quranPages = [];
      for (let i = 0; i < ayahs.length; i += QURAN_AYAHS_PER_PAGE) {
        quranPages.push(ayahs.slice(i, i + QURAN_AYAHS_PER_PAGE));
      }
      quranPageIndex = 0;
      renderQuranPage(container);
      bindContainer(container);
    })
    .catch(() => {
      container.innerHTML = `<p class="muted center">تعذّر تحميل نص السورة الآن (تحتاج اتصال إنترنت لعرض النص هنا).</p>
        <a class="btn secondary block mt8" href="https://quran.com/${id}" target="_blank" rel="noopener">افتح السورة كاملة على quran.com</a>`;
    });
}

// يرسم صفحة المصحف الحالية على هيئة صفحة كتاب حقيقية، قابلة للتقليب بالأزرار
function renderQuranPage(container) {
  const total = quranPages.length;
  const page = quranPages[quranPageIndex] || [];
  const pageHtml = page.map(a => `${a.text} <span style="color:var(--gold);font-weight:800">﴿${a.numberInSurah}﴾</span>`).join(' ');
  container.innerHTML = `
    <div class="quran-book">
      <div class="quran-page-flip" id="quran-page-inner">
        <p style="line-height:2.7;font-size:19px;text-align:justify">${pageHtml}</p>
      </div>
    </div>
    <div class="quran-page-nav">
      <button class="btn secondary" data-action="quran-prev-page" ${quranPageIndex === 0 ? 'disabled' : ''}>${icon('door')} السابقة</button>
      <span class="quran-page-num">صفحة ${quranPageIndex + 1} / ${total}</span>
      <button class="btn" data-action="quran-next-page" ${quranPageIndex >= total - 1 ? 'disabled' : ''}>التالية ${icon('door')}</button>
    </div>
    <p class="muted center mt12">المصدر: مصحف</p>`;
}

// يعيد رسم الصفحة الحالية مع تأثير تقليب سلس، بدون إعادة تحميل السورة من الإنترنت
function flipQuranPage(direction) {
  const container = document.getElementById('surah-text-' + currentQuranSurahId);
  if (!container) return;
  renderQuranPage(container);
  bindContainer(container);
  const pageEl = document.getElementById('quran-page-inner');
  if (pageEl) pageEl.classList.add(direction === 'next' ? 'flip-next' : 'flip-prev');
  playTickSound();
}

// ---- الأحاديث ----
let hadithTopicFilter = 'الكل';
let hadithAgreedOnly = false;
let hadithSearchQuery = '';
function renderHadithTab() {
  const topics = ['الكل', ...Array.from(new Set(hadiths.map(h => h.topic)))];
  const chips = topics.map(t => `<button class="btn ${t === hadithTopicFilter ? '' : 'secondary'}" style="font-size:12px;padding:6px 12px" data-action="filter-hadith" data-topic="${t}">${t}</button>`).join(' ');
  const q = hadithSearchQuery.trim();
  const list = hadiths.filter(h =>
    (hadithTopicFilter === 'الكل' || h.topic === hadithTopicFilter) &&
    (!hadithAgreedOnly || h.source === 'متفق عليه') &&
    (!q || h.text.includes(q) || (h.explanation || '').includes(q))
  ).slice(0, 40);
  const items = list.map(h => {
    const memorized = (state.memorizedHadiths || []).includes(h.id);
    const pending = (state.pendingMemorizedHadiths || []).includes(h.id);
    const label = memorized ? 'حفظته ✓ (مؤكَّد)' : pending ? '⏳ بانتظار تأكيد الوالدين' : 'علّمه كمحفوظ';
    return `
    <div class="card">
      <div style="font-weight:800">${h.text}</div>
      <div class="muted mt8">${h.narrator} - ${h.source}</div>
      <div class="mt8">${h.explanation}</div>
      <button class="btn secondary block mt8" data-action="toggle-memorized-hadith" data-id="${h.id}">
        ${icon(memorized ? 'checkCircle' : pending ? 'hourglass' : 'star')} ${label}
      </button>
    </div>`;
  }).join('');
  return `<div class="container"><h1 class="title">${icon('chat')} ${tr('page_hadith')}</h1>
    <input type="text" id="hadith-search" value="${esc(hadithSearchQuery)}" placeholder="ابحث في الأحاديث..." class="mb12" oninput="handleHadithSearch(this.value)" />
    <button class="btn ${hadithAgreedOnly ? '' : 'secondary'} block mb12" data-action="toggle-agreed-hadith">${icon('checkCircle')} عرض الأحاديث المتفق عليها فقط ${hadithAgreedOnly ? '✓' : ''}</button>
    <div class="row" style="flex-wrap:wrap;gap:6px;margin-bottom:14px">${chips}</div>
    ${items.length ? items : '<p class="muted center">لا توجد أحاديث متفق عليها في هذا التصنيف</p>'}
    <p class="muted center mt12">عرض ${list.length} حديثًا من ${hadiths.length} إجمالًا</p>
  </div>`;
}

// ---- سنن الرسول ﷺ ----
let sunnahCatFilter = 'all';
// بحث الأحاديث: نحدّث المتغيّر ونعيد الرسم بدون فقدان تركيز الحقل (نعيد التركيز عليه يدويًا)
function handleHadithSearch(v) {
  hadithSearchQuery = v;
  render();
  const el = document.getElementById('hadith-search');
  if (el) { el.focus(); el.selectionStart = el.selectionEnd = el.value.length; }
}

let sunnahSearchQuery = '';
function handleSunnahSearch(v) {
  sunnahSearchQuery = v;
  render();
  const el = document.getElementById('sunnah-search');
  if (el) { el.focus(); el.selectionStart = el.selectionEnd = el.value.length; }
}
function renderSunnahTab() {
  const chips = ['all', ...Object.keys(SUNNAH_CATEGORIES)].map(c => `
    <button class="story-filter-btn ${sunnahCatFilter === c ? 'active' : ''}" data-action="filter-sunnah" data-cat="${c}">${c === 'all' ? 'الكل' : SUNNAH_CATEGORIES[c].label}</button>`).join('');
  const sq = sunnahSearchQuery.trim();
  const list = prophetSunnahs.filter(s => (sunnahCatFilter === 'all' || s.cat === sunnahCatFilter) && (!sq || s.title.includes(sq) || s.desc.includes(sq)));
  const items = list.map(s => `
    <div class="list-item">
      <div class="emoji">${icon(SUNNAH_CATEGORIES[s.cat].icon)}</div>
      <div class="info"><div class="t">${s.title}</div><div class="s">${s.desc}</div><div class="s muted small mt8">${s.source}</div></div>
    </div>`).join('');
  return `<div class="container">
    <h1 class="title">${icon('sunnah')} ${tr('page_sunnah')}</h1>
    <p class="muted mb8">سنن يومية بسيطة كان يحرص عليها النبي ﷺ، اجعلها عادة يومية واكسب أجرها</p>
    <input type="text" id="sunnah-search" value="${esc(sunnahSearchQuery)}" placeholder="ابحث في السنن..." class="mb12" oninput="handleSunnahSearch(this.value)" />
    <div class="story-filter-row">${chips}</div>
    <div class="mt12">${items.length ? items : '<p class="muted center">لا توجد سنن في هذا التصنيف</p>'}</div>
  </div>`;
}

// ---- الأذكار ----
// ============================== شجرتي (شجرة الحسنات + إهداء حسنة) ==============================
// ============================== خزنة الألماس: ميزات نادرة لا تُفتح إلا بالألماس ==============================
// ============================== أسماء الله الحسنى ==============================
// ============================== حاسبة الكفارة (صيام كفارة أي ذنب بأي مدة) ==============================
// ============================== رفيق الحلال: فحص الإضافات الغذائية (E-Numbers) وقراءة الباركود ==============================
let halalScanResult = null; // { rawText, matches: [{code,name,status,note}] }
let halalScanLoading = false;
let barcodeScanActive = false;
let barcodeStream = null;
let barcodeResult = null; // { code, product } من Open Food Facts
function loadTesseract() {
  if (typeof Tesseract !== 'undefined') return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('تعذّر تحميل مكتبة قراءة النص، تأكد من اتصالك بالإنترنت'));
    document.head.appendChild(s);
  });
}
function extractENumbers(text) {
  const found = new Set((text.match(/E\s?-?\s?\d{3}[a-zA-Z]?/gi) || []).map(m => m.toUpperCase().replace(/\s|-/g, '')));
  return Array.from(found).map(code => eNumbersDatabase.find(e => e.code === code)).filter(Boolean);
}

// ---- قراءة الباركود (الشفرة العمودية) عبر كاميرا الجهاز مباشرة ----
function startBarcodeScan() {
  if (typeof BarcodeDetector === 'undefined') {
    showMessageCard('error', 'غير مدعوم على جهازك', 'متصفحك لا يدعم قراءة الباركود مباشرة، جرّب متصفح كروم على أندرويد');
    return;
  }
  barcodeResult = null;
  barcodeScanActive = true;
  render();
  navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
    .then(stream => {
      barcodeStream = stream;
      const video = document.getElementById('barcode-video');
      if (!video) { stopBarcodeScan(); return; }
      video.srcObject = stream;
      video.play();
      const detector = new BarcodeDetector({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128'] });
      const scanLoop = () => {
        if (!barcodeScanActive) return;
        detector.detect(video).then(codes => {
          if (codes.length > 0) {
            const code = codes[0].rawValue;
            stopBarcodeScan();
            lookupBarcode(code);
          } else if (barcodeScanActive) {
            requestAnimationFrame(scanLoop);
          }
        }).catch(() => { if (barcodeScanActive) requestAnimationFrame(scanLoop); });
      };
      scanLoop();
    })
    .catch(() => {
      barcodeScanActive = false; render();
      showMessageCard('error', 'تعذّر فتح الكاميرا', 'اسمح للتطبيق بالوصول إلى الكاميرا وحاول مرة أخرى');
    });
}
function stopBarcodeScan() {
  barcodeScanActive = false;
  if (barcodeStream) { barcodeStream.getTracks().forEach(t => t.stop()); barcodeStream = null; }
  render();
}
// يبحث عن المنتج عبر Open Food Facts (قاعدة بيانات مفتوحة ومجانية) - يحتاج إنترنت، والتغطية غير كاملة لكل المنتجات خصوصًا المحلية
function lookupBarcode(code) {
  halalScanLoading = true; render();
  fetch(`https://world.openfoodfacts.org/api/v2/product/${code}.json`)
    .then(r => r.json())
    .then(data => {
      halalScanLoading = false;
      if (data.status !== 1 || !data.product) {
        barcodeResult = { code, notFound: true };
      } else {
        const ingredientsText = data.product.ingredients_text_ar || data.product.ingredients_text || '';
        barcodeResult = {
          code,
          name: data.product.product_name_ar || data.product.product_name || 'منتج غير معروف الاسم',
          image: data.product.image_front_small_url,
          ingredientsText,
          matches: extractENumbers(ingredientsText),
        };
      }
      render();
    })
    .catch(() => {
      halalScanLoading = false;
      barcodeResult = { code, error: true };
      render();
    });
}

function renderHalalScannerTab() {
  return `<div class="container">
    <h1 class="title">${icon('halalScanner')} رفيق الحلال</h1>
    <p class="muted mb12">امسح باركود المنتج، أو صوّر قائمة المكونات، وهنفحص لك رموز الإضافات (E-Numbers)</p>

    ${barcodeScanActive ? `
      <div class="card center" style="padding:0;overflow:hidden">
        <video id="barcode-video" style="width:100%;display:block;background:#000" muted playsinline></video>
        <button class="btn secondary block" style="margin:10px" data-action="cancel-barcode-scan">${tr('cancel')}</button>
      </div>
    ` : `
      <div class="card center">
        <div style="font-size:40px">${icon('halalScanner')}</div>
        <button class="btn block mt12" data-action="trigger-barcode-scan">${icon('halalScanner')} امسح الباركود</button>
        <p class="muted small mt8">يحتاج إنترنت للبحث عن المنتج، والتغطية غير كاملة لكل المنتجات خصوصًا المحلية منها</p>
      </div>
      <div class="card center mt12">
        <p class="muted small">أو لو الباركود مش موجود في القاعدة، صوّر قائمة المكونات مباشرة:</p>
        <input type="file" id="halal-scan-input" accept="image/*" capture="environment" style="display:none" onchange="handleHalalScanFile(this)" />
        <button class="btn secondary block mt8" data-action="trigger-halal-scan">${icon('halalScanner')} صوّر قائمة المكونات</button>
      </div>
    `}

    ${halalScanLoading ? `<p class="muted center mt12">${icon('hourglass')} جاري البحث والتحليل...</p>` : ''}
    ${barcodeResult ? renderBarcodeResult() : ''}
    ${halalScanResult ? renderHalalScanResults() : ''}

    <div class="card mt16">
      <div style="font-weight:900">${icon('sparkle')} تنبيه مهم</div>
      <p class="muted small mt8">التصنيف هنا إرشادي عام وليس فتوى شرعية قاطعة، فمصدر المادة قد يختلف بين الشركات والدول. الرموز "مشبوهة" تحتاج تأكيد من الشركة المصنّعة أو منتج معتمد حلال.</p>
    </div>
  </div>`;
}
function renderBarcodeResult() {
  if (barcodeResult.error) return `<div class="card mt12 center"><p class="muted">حصل خطأ في البحث، تأكد من اتصالك بالإنترنت وحاول تاني</p></div>`;
  if (barcodeResult.notFound) return `<div class="card mt12 center"><p class="muted">المنتج (${barcodeResult.code}) مش موجود في قاعدة البيانات المفتوحة، جرّب تصوير قائمة المكونات بدل كده</p></div>`;
  return `<div class="card mt12">
    <div class="row">
      ${barcodeResult.image ? `<img src="${barcodeResult.image}" style="width:44px;height:44px;border-radius:8px;object-fit:cover" />` : ''}
      <div><b>${barcodeResult.name}</b><div class="muted small">${barcodeResult.code}</div></div>
    </div>
    ${barcodeResult.matches && barcodeResult.matches.length ? '' : `<p class="muted small mt8">مفيش رموز E-Number موجودة في بيانات المكونات لهذا المنتج</p>`}
  </div>${barcodeResult.matches && barcodeResult.matches.length ? renderMatchesList(barcodeResult.matches) : ''}`;
}
function renderMatchesList(matches) {
  const statusMeta = {
    halal: { label: 'حلال', color: '#3FBF6A', icon: 'checkCircle' },
    haram: { label: 'حرام', color: '#D9534F', icon: 'xCircle' },
    mushbooh: { label: 'مشبوه - تحقق منه', color: '#D9A441', icon: 'warning' },
  };
  return matches.map(m => {
    const sm = statusMeta[m.status];
    return `<div class="card mt8" style="border:2px solid ${sm.color}">
      <div class="row"><b>${m.code}</b> <span style="color:${sm.color};font-weight:900">${icon(sm.icon)} ${sm.label}</span></div>
      <div class="mt8">${m.name}</div>
      <p class="muted small mt8">${m.note}</p>
    </div>`;
  }).join('');
}
function renderHalalScanResults() {
  const { matches } = halalScanResult;
  if (matches.length === 0) {
    return `<div class="card mt12 center"><p class="muted">ملقيناش أي رمز E-Number واضح في الصورة، جرّب تصوير أوضح</p></div>`;
  }
  return `<div class="mt12">${renderMatchesList(matches)}</div>`;
}

// ============================== حاسبة الكفارة (صيام كفارة أي ذنب بأي مدة) ==============================
function renderKaffaraTab() {
  const plans = state.kaffaraPlans || [];
  const activeHtml = plans.map(p => {
    const done = p.doneDates.length;
    const pct = Math.round((done / p.totalDays) * 100);
    const doneToday = p.doneDates.includes(todayStr());
    const finished = done >= p.totalDays;
    return `
    <div class="card mt12" style="border:1px solid var(--primary)">
      <div style="font-weight:900">${esc(p.label || 'كفارة')}</div>
      <div class="stat-row mt8">
        <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${pct}%;background:var(--primary)"></div></div>
        <div class="stat-value">${done}/${p.totalDays}</div>
      </div>
      ${finished
        ? `<div class="badge mt8" style="display:inline-block">${icon('crown')} أتممت الكفارة! تقبل الله منك 🎉</div>`
        : doneToday
          ? `<p class="muted small mt8">${icon('checkCircle')} تم تسجيل صيام اليوم، جزاك الله خيرًا</p>`
          : `<button class="btn block mt8" data-action="mark-kaffara-day" data-id="${p.id}">${icon('check')} سجّل صيام اليوم</button>`}
      ${!finished ? `<button class="btn secondary small mt8" data-action="delete-kaffara-plan" data-id="${p.id}">${icon('trash')} إلغاء الخطة</button>` : ''}
    </div>`;
  }).join('');
  return `<div class="container">
    <h1 class="title">${icon('kaffara')} حاسبة الكفارة</h1>
    <p class="muted mb12">تساعدك تنظّم صيام كفارة أي ذنب، بالمدة اللي تحددها، مع تذكير يومي لطيف حتى تخلّصها</p>
    <div class="card">
      <input type="text" id="kaffara-label" placeholder="اكتب سبب الكفارة (اختياري)" class="mb8" />
      <input type="number" id="kaffara-days" placeholder="كام يوم عايز تصوم؟" class="mb8" min="1" />
      <button class="btn block" data-action="add-kaffara-plan">${icon('kaffara')} ابدأ خطة الصيام</button>
    </div>
    ${activeHtml}
  </div>`;
}

// ============================== فيديوهات آمنة (يضيفها الوالدين، تشغيل معزول بلا اقتراحات أو تعليقات) ==============================
function extractYoutubeId(input) {
  const s = (input || '').trim();
  const m = s.match(/(?:youtu\.be\/|[?&]v=|embed\/|shorts\/)([a-zA-Z0-9_-]{11})/);
  if (m) return m[1];
  if (/^[a-zA-Z0-9_-]{11}$/.test(s)) return s;
  return null;
}
// يحدد نوع الرابط: يوتيوب (تشغيل عبر iframe معزول) أو رابط فيديو عادي (تشغيل عبر <video> مباشرة)
function classifyVideoUrl(input) {
  const s = (input || '').trim();
  if (!s) return null;
  const ytId = extractYoutubeId(s);
  if (ytId && (s.includes('youtu') || /^[a-zA-Z0-9_-]{11}$/.test(s))) return { type: 'youtube', ref: ytId };
  if (/^https?:\/\//i.test(s)) return { type: 'direct', ref: s };
  return null;
}
function renderSafeVideosTab() {
  const videos = state.customVideos || [];
  const grid = videos.map(v => {
    const type = v.type || (/^[a-zA-Z0-9_-]{11}$/.test(v.id) ? 'youtube' : null);
    const ref = v.ref || v.id;
    return `
    <div class="card" data-action="play-safe-video" data-id="${v.id}" style="cursor:pointer;padding:0;overflow:hidden">
      ${type === 'youtube'
        ? `<img src="https://img.youtube.com/vi/${ref}/hqdefault.jpg" style="width:100%;display:block" alt="${esc(v.title)}" />`
        : `<div style="width:100%;aspect-ratio:16/9;background:var(--muted);display:flex;align-items:center;justify-content:center">${icon('safeVideos')}</div>`}
      <div style="padding:10px;font-weight:800">${icon('speaker')} ${esc(v.title)}</div>
    </div>`;
  }).join('');
  return `<div class="container">
    <h1 class="title">${icon('safeVideos')} فيديوهات آمنة</h1>
    <p class="muted mb12">فيديوهات اختارها والداك بنفسهم، بمشغّل معزول بدون اقتراحات ولا تعليقات</p>
    ${videos.length ? `<div class="grid-2">${grid}</div>` : `<p class="muted center mt16">${icon('sparkle')} لسه مفيش فيديوهات مضافة، اطلب من والديك يضيفوا فيديوهات من لوحة التحكم</p>`}
  </div>`;
}
function renderSafeVideoPlayerModal(id) {
  const v = (state.customVideos || []).find(x => x.id === id);
  if (!v) return '';
  const type = v.type || (/^[a-zA-Z0-9_-]{11}$/.test(v.id) ? 'youtube' : null);
  const ref = v.ref || v.id;
  if (!type || !ref) return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <p class="muted">تعذّر تشغيل هذا الفيديو، جرّب تحذفه وتضيفه تاني برابط صحيح</p>
      <button class="btn secondary block mt8" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
  const player = type === 'youtube'
    ? `<iframe src="https://www.youtube-nocookie.com/embed/${ref}?rel=0&modestbranding=1&iv_load_policy=3&fs=1&playsinline=1"
        style="position:absolute;top:0;left:0;width:100%;height:100%;border:0" allow="autoplay; encrypted-media" allowfullscreen></iframe>`
    : `<video src="${ref}" controls playsinline style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:contain;background:#000"></video>`;
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()" style="padding:0;overflow:hidden">
      <div style="position:relative;padding-top:56.25%">${player}</div>
      <div style="padding:14px">
        <div style="font-weight:800">${esc(v.title)}</div>
        <button class="btn secondary block mt8" data-action="close-modal">${tr("close")}</button>
      </div>
    </div>
  </div>`;
}

// ============================== أسماء الله الحسنى ==============================
function renderAsmaHusnaTab() {
  const progress = state.namesMemoryProgress || 0;
  const pending = state.namesMemoryPending || 0;
  const pct = Math.round((progress / asmaAlHusna.length) * 100);
  const listItems = asmaAlHusna.map((n, i) => `
    <div class="list-item ${i < progress ? 'names-memorized' : ''}">
      <div class="emoji" style="background:${i < progress ? 'linear-gradient(145deg,#FDE68A,#D9A441)' : 'var(--muted)'}">${i < progress ? icon('check') : (i + 1)}</div>
      <div class="info"><div class="t">${n.name}</div><div class="s">${n.meaning}</div></div>
    </div>`).join('');
  return `<div class="container">
    <h1 class="title">${icon('asmaHusna')} أسماء الله الحسنى</h1>
    <div class="card" style="border:1px solid var(--gold)">
      <div style="font-weight:900">${icon('star')} تحدي حفظ الأسماء الحسنى</div>
      <div class="stat-row mt8">
        <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${pct}%;background:#4A9FD9"></div></div>
        <div class="stat-value">${progress}/${asmaAlHusna.length}</div>
      </div>
      <p class="muted small mt8">كل اسم تحفظه وتؤكده مع والديك يديك ألماسة، وكل ١٠ أسماء جائزة إضافية!</p>
      ${progress >= asmaAlHusna.length
        ? `<div class="badge mt8" style="display:inline-block">${icon('crown')} حفظت كل الأسماء الحسنى! 🎉</div>`
        : pending > 0
          ? `<button class="btn secondary block mt8" disabled>${icon('hourglass')} بانتظار تأكيد الوالدين (حتى الاسم ${pending})</button>`
          : `<button class="btn block mt8" data-action="request-name-memorized">${icon('diamond')} حفظت اسمًا جديدًا! (${asmaAlHusna[progress].name})</button>`}
    </div>
    <div class="mt12">${listItems}</div>
  </div>`;
}

// ============================== الفعاليات الحصرية (تُشترى بالألماس مرة واحدة وتفضل ملكك للأبد) ==============================
const EVENTS_LIST = [
  { id: 'ev_word_treasure', kind: 'scramble', name: 'كنز الحروف الذهبي', desc: '10 كلمات إسلامية راقية، رتّب حروفها واكسب كنزًا من النقاط', cost: 50, icon: 'pen', color: '#B8862E' },
  { id: 'ev_ayah_count', kind: 'mcq', name: 'سباق آيات القرآن', desc: 'خمّن عدد آيات كل سورة في جولة من 10 أسئلة', cost: 120, icon: 'bookOpenStar', color: '#2F6B44' },
  { id: 'ev_sahaba_gold', kind: 'mcq', name: 'مغامرة الصحابة الكبرى', desc: 'جولة صعبة من 10 أسئلة عن أعلام الصحابة رضي الله عنهم', cost: 250, icon: 'shield', color: '#6B4E9E' },
  { id: 'ev_asma_gold', kind: 'mcq', name: 'لغز الأسماء الحسنى الذهبي', desc: 'جولة من 10 أسئلة تختبر حفظك لأسماء الله الحسنى ومعانيها', cost: 400, icon: 'star', color: '#B8862E' },
  { id: 'ev_prophets_gold', kind: 'mcq', name: 'رحلة الأنبياء العظماء', desc: 'جولة من 10 أسئلة عميقة عن قصص الأنبياء عليهم السلام', cost: 650, icon: 'crescentStar', color: '#2B6CB0' },
  { id: 'ev_grand_finale', kind: 'mcq', name: 'التحدي الأسطوري الأخير', desc: 'أصعب 10 أسئلة في التطبيق كله، جولة نهائية لأبطال حصالة الحسنات فقط', cost: 1000, icon: 'crown', color: '#C0392B' },
];
let eventSession = null; // جلسة فعالية أسئلة نشطة حاليًا (10 أسئلة متتالية)
let eventScrambleSession = null; // جلسة فعالية "رتب الحروف" نشطة حاليًا

function getEventPool(id) {
  if (id === 'ev_word_treasure') return goldenScrambleWords;
  if (id === 'ev_sahaba_gold') return [...sahabaGames, ...sahabaGamesGold];
  if (id === 'ev_prophets_gold') return prophetsQuizGold;
  if (id === 'ev_grand_finale') return quizQuestions.filter(q => q.points >= 15);
  if (id === 'ev_ayah_count') {
    return surahs.map(s => {
      const wrongs = shuffle(surahs.filter(x => x.id !== s.id)).slice(0, 3).map(x => x.versesCount);
      const options = shuffle([s.versesCount, ...wrongs]).map(String);
      return { q: 'كام آية في سورة "' + s.name + '"؟', options, answer: options.indexOf(String(s.versesCount)), points: 15 };
    });
  }
  if (id === 'ev_asma_gold') {
    return asmaAlHusna.map((a, i) => {
      const wrongs = shuffle(asmaAlHusna.filter((x, j) => j !== i)).slice(0, 3).map(x => x.name);
      const options = shuffle([a.name, ...wrongs]);
      return { q: 'أي اسم من أسماء الله الحسنى يدل على هذا المعنى: "' + a.meaning + '"؟', options, answer: options.indexOf(a.name), points: 15 };
    });
  }
  return [];
}

function renderEventsTab() {
  const owned = state.ownedEvents || [];
  const best = state.eventBestScores || {};
  const cards = EVENTS_LIST.map(ev => {
    const isOwned = owned.includes(ev.id) || hasAllAccess();
    const bestScore = best[ev.id];
    return `<div class="card diamond-vault-card mt12" style="border:1px solid ${ev.color}">
      <div class="row"><div class="diamond-vault-icon" style="color:${ev.color}">${icon(ev.icon)}</div>
        <div><div style="font-weight:900">${esc(ev.name)}</div><div class="muted small">${esc(ev.desc)}</div></div>
      </div>
      ${typeof bestScore === 'number' ? `<p class="muted small mt8">أفضل نتيجة لك: ${bestScore} / 10</p>` : ''}
      ${isOwned
        ? `<button class="btn block mt8" style="background:${ev.color}" data-action="start-event" data-id="${ev.id}">${icon('gift')} ابدأ الفعالية</button>`
        : `<button class="btn block mt8" style="background:#2B6CB0" data-action="buy-event" data-id="${ev.id}" data-cost="${ev.cost}">${icon('diamond')} افتح مقابل ${ev.cost} ألماسة</button>`}
    </div>`;
  }).join('');
  return `<div class="container">
    <h1 class="title">${icon('crown')} ${tr('page_events')}</h1>
    <div class="card center" style="background:linear-gradient(135deg,#B8862E,#F2D27A);color:#fff">
      <div style="font-size:36px">${icon('crown')}</div>
      <p class="mt8">فعاليات حصرية جدًا تُفتح مرة واحدة بالألماس النادر وتفضل ملكك للأبد، كل فعالية جولة من 10 أسئلة ومكافأة عند إتمامها كاملة</p>
      <div class="row center mt8" style="gap:6px"><span>${icon('diamond')}</span><b>${state.diamonds || 0}</b><span>ألماسة متاحة</span></div>
    </div>
    ${cards}
  </div>`;
}

function renderEventSessionMCQ() {
  const ev = EVENTS_LIST.find(e => e.id === eventSession.eventId);
  const q = eventSession.pool[eventSession.index];
  const opts = q.options.map((opt, i) =>
    `<button class="btn secondary block mt8" data-action="answer-event-mcq" data-i="${i}">${esc(String(opt))}</button>`).join('');
  return `<div class="container">
    <h1 class="title">${icon(ev.icon)} ${esc(ev.name)}</h1>
    <p class="muted mb8">سؤال ${eventSession.index + 1} من ${eventSession.pool.length} • إجاباتك الصحيحة: ${eventSession.correct}</p>
    <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${Math.round((eventSession.index / eventSession.pool.length) * 100)}%;background:${ev.color}"></div></div>
    <div class="card mt16"><div style="font-weight:800;font-size:17px;line-height:2">${esc(q.q)}</div><div class="mt16">${opts}</div></div>
    <button class="btn secondary block mt12" data-action="quit-event-session">${icon('xCircle')} إنهاء الفعالية والخروج</button>
  </div>`;
}

function renderEventScrambleSession() {
  const ev = EVENTS_LIST.find(e => e.id === eventScrambleSession.eventId);
  const g = eventScrambleSession.words[eventScrambleSession.index];
  const letters = g.word.split('');
  if (!window.__eventScrambleOrder || window.__eventScrambleOrderWord !== g.word) {
    window.__eventScrambleOrder = shuffle(letters.map((_, i) => i));
    window.__eventScrambleOrderWord = g.word;
  }
  const order = window.__eventScrambleOrder;
  const chosenSet = new Set(eventScrambleSession.buffer);
  const tiles = order.map(i => `
    <button class="btn secondary" style="min-width:44px;opacity:${chosenSet.has(i) ? '.35' : '1'}" ${chosenSet.has(i) ? 'disabled' : ''} data-action="event-scramble-pick" data-i="${i}">${esc(letters[i])}</button>`).join('');
  const built = eventScrambleSession.buffer.map(i => letters[i]).join('');
  return `<div class="container">
    <h1 class="title">${icon(ev.icon)} ${esc(ev.name)}</h1>
    <p class="muted mb8">كلمة ${eventScrambleSession.index + 1} من ${eventScrambleSession.words.length} • صح: ${eventScrambleSession.correct}</p>
    <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${Math.round((eventScrambleSession.index / eventScrambleSession.words.length) * 100)}%;background:${ev.color}"></div></div>
    <div class="card mt16">
      <p class="muted small">تلميح: ${esc(g.hint)}</p>
      <div class="center" style="font-weight:900;font-size:26px;min-height:40px;letter-spacing:4px;margin:14px 0">${esc(built) || '⬦⬦⬦⬦'}</div>
      <div class="center" style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${tiles}</div>
      <div class="row mt16" style="gap:8px">
        <button class="btn secondary block" data-action="event-scramble-clear">${icon('xCircle')} مسح</button>
        <button class="btn block" data-action="event-scramble-submit">${icon('check')} تأكيد</button>
      </div>
    </div>
    <button class="btn secondary block mt12" data-action="quit-event-session">${icon('xCircle')} إنهاء الفعالية والخروج</button>
  </div>`;
}

function finishEventSession() {
  const ev = EVENTS_LIST.find(e => e.id === eventSession.eventId);
  const total = eventSession.pool.length, correct = eventSession.correct;
  let bonus = 0;
  if (correct === total) { bonus = 50; addPoints(bonus); }
  state.eventBestScores = state.eventBestScores || {};
  const prevBest = state.eventBestScores[ev.id] || 0;
  if (correct > prevBest) state.eventBestScores[ev.id] = correct;
  saveState(); celebrate(); playAchievementSound();
  eventSession = null;
  showMessageCard('success', 'انتهت الفعالية! 🏆', 'أجبت صح على ' + correct + ' من ' + total + (bonus ? '، وحصلت على ' + bonus + ' نقطة مكافأة الإتمام الكامل! 🎉' : '') + '.');
  render();
}
function finishEventScrambleSession() {
  const ev = EVENTS_LIST.find(e => e.id === eventScrambleSession.eventId);
  const total = eventScrambleSession.words.length, correct = eventScrambleSession.correct;
  let bonus = 0;
  if (correct === total) { bonus = 50; addPoints(bonus); }
  state.eventBestScores = state.eventBestScores || {};
  const prevBest = state.eventBestScores[ev.id] || 0;
  if (correct > prevBest) state.eventBestScores[ev.id] = correct;
  saveState(); celebrate(); playAchievementSound();
  eventScrambleSession = null;
  showMessageCard('success', 'انتهت الفعالية! 🏆', 'رتّبت صح ' + correct + ' من ' + total + ' كلمة' + (bonus ? '، وحصلت على ' + bonus + ' نقطة مكافأة الإتمام الكامل! 🎉' : '') + '.');
  render();
}

function renderDiamondVaultTab() {
  const diamondFrame = certificateFrames.find(f => f.diamondOnly);
  const diamondPot = treePotSkins.find(p => p.diamondOnly);
  const items = [
    { key: 'badge', name: 'وسام النجم الماسي', desc: 'شارة ألماسية متلألئة تظهر بجانب اسمك في كل مكان بالتطبيق', cost: 5, owned: state.diamondBadgeOwned || hasAllAccess(), iconName: 'crown' },
    { key: 'certFrame', name: diamondFrame.name, desc: 'إطار حصري لشهادات التقدير، لا يُشترى بالنقاط أبدًا', cost: diamondFrame.diamondCost, owned: state.certFramesOwned.includes(diamondFrame.id) || hasAllAccess(), iconName: 'bookOpenStar' },
    { key: 'potSkin', name: diamondPot.name, desc: 'إناء أسطوري لشجرة حسناتك، حصري لمن يحفظون القرآن', cost: diamondPot.diamondCost, owned: state.potSkinsOwned.includes(diamondPot.id) || hasAllAccess(), iconName: 'tree' },
  ];
  const cards = items.map(it => `
    <div class="card diamond-vault-card">
      <div class="row">
        <div class="diamond-vault-icon">${icon(it.iconName)}</div>
        <div><div style="font-weight:900">${it.name}</div><div class="muted small">${it.desc}</div></div>
      </div>
      ${it.owned
        ? `<div class="badge mt8" style="display:inline-block;background:#4A9FD9;color:#fff">${icon('check')} ${tr('currently_active')}</div>`
        : `<button class="btn block mt8" style="background:#2B6CB0" data-action="buy-with-diamonds" data-key="${it.key}" data-cost="${it.cost}">${icon('diamond')} افتح مقابل ${it.cost} ألماسة</button>`}
    </div>`).join('');

  return `<div class="container">
    <h1 class="title">${icon('diamondVault')} خزنة العملات</h1>
    <p class="muted center mt8">كل عملاتك في مكان واحد</p>
    <div class="grid-2 mt12">
      <div class="card center" style="background:linear-gradient(135deg,#2B6CB0,#4FA3E0);color:#fff">
        <div style="font-size:26px">${icon('diamond')}</div>
        <div style="font-size:22px;font-weight:900">${state.diamonds || 0}</div>
        <div class="small mt8">ألماس</div>
      </div>
      <div class="card center" style="background:linear-gradient(135deg,#B8862E,#D4A017);color:#fff">
        <div style="font-size:26px">🟡</div>
        <div style="font-size:22px;font-weight:900">${state.gold || 0}</div>
        <div class="small mt8">ذهب</div>
      </div>
      <div class="card center" style="background:linear-gradient(135deg,#8A8FA0,#C7CBD1);color:#fff">
        <div style="font-size:26px">⚪</div>
        <div style="font-size:22px;font-weight:900">${state.silver || 0}</div>
        <div class="small mt8">فضة</div>
      </div>
      <div class="card center" style="background:linear-gradient(135deg,#4A9FD9,#7FC4E8);color:#fff">
        <div style="font-size:26px">🪙</div>
        <div style="font-size:22px;font-weight:900">${state.points || 0}</div>
        <div class="small mt8">نقاط</div>
      </div>
    </div>
    <p class="muted center mt12">الألماس يُجمع من حفظ آيات القرآن، الذهب والفضة من فعاليات نادرة أو شحن حقيقي، والنقاط من المهام اليومية</p>
    ${renderCouponPromoCard()}
    <h2 class="section-title mt16">🎖️ ميزات حصرية بالألماس</h2>
    ${cards}
  </div>`;
}

// ============================== أوضاع وأدوات عامة (مفتوحة للجميع، مالهاش علاقة بالباقات) ==============================
function fastingStreak() {
  const set = new Set(state.fastingDays || []);
  let n = 0; const d = new Date();
  if (!set.has(d.toLocaleDateString('en-CA'))) d.setDate(d.getDate() - 1);
  while (set.has(d.toLocaleDateString('en-CA'))) { n++; d.setDate(d.getDate() - 1); }
  return n;
}
// ============================== التقويم الهجري (الشهر واليوم هجريان بالكامل، لا يظهر أي تاريخ ميلادي) ==============================
let hijriView = null;     // { year, month } الشهر المعروض حاليًا
let hijriSelDay = null;   // اليوم المحدد داخل الشهر المعروض

// أيام يُستحب صيامها: الاثنين والخميس، الأيام البيض، تاسع وعاشر محرم، وعرفة
function isSunnahFastDay(y, m, d, dow) {
  if (dow === 1 || dow === 4) return true;
  if (m !== 12 && d >= 13 && d <= 15) return true;
  if (m === 1 && (d === 9 || d === 10)) return true;
  if (m === 12 && d === 9) return true;
  return false;
}

function hijriFullDate(y, m, d) {
  const dow = jdnDayOfWeek(hijriToJDN(y, m, d));
  return `${weekdayName(dow)} ${formatHijri({ year: y, month: m, day: d })}`;
}

// تحويل مفتاح تخزين داخلي (YYYY-MM-DD) إلى نص هجري للعرض، بحيث لا يرى المستخدم تاريخًا ميلاديًا أبدًا
function hijriFromKey(key) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(key || ''));
  if (!m) return esc(String(key || ''));
  const jdn = gregorianToJDN(+m[1], +m[2], +m[3]) + hijriOffsetDays();
  return esc(formatHijri(jdnToIslamic(jdn)));
}

const CAL_CHEV_R = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>';
const CAL_CHEV_L = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>';

function renderCalendarTab() {
  const t = getTodayHijri();
  if (!hijriView) hijriView = { year: t.year, month: t.month };
  const { year, month } = hijriView;
  const isThisMonth = year === t.year && month === t.month;
  const len = hijriMonthLength(year, month);
  if (!hijriSelDay || hijriSelDay > len) hijriSelDay = isThisMonth ? t.day : 1;
  const todayJ = getTodayJDN();
  const fasted = new Set(state.fastingDays || []);
  const grid = buildHijriMonthGrid(year, month);

  const weekdays = [6, 0, 1, 2, 3, 4, 5].map(d => `<div class="hcal-wd${d === 5 ? ' fri' : ''}">${weekdayName(d, true)}</div>`).join('');
  const cells = grid.cells.map(c => {
    if (!c) return '<div class="hcal-cell empty"></div>';
    const j = hijriToJDN(year, month, c.day);
    const evs = getHijriDayEvents(month, c.day);
    const major = evs.some(e => e.id !== 'white-days');
    const white = evs.some(e => e.id === 'white-days');
    const did = fasted.has(hijriToDateKey(year, month, c.day));
    const cls = ['hcal-cell', j === todayJ ? 'today' : '', c.day === hijriSelDay ? 'sel' : '', c.dow === 5 ? 'fri' : ''].filter(Boolean).join(' ');
    return `<button type="button" class="${cls}" data-action="hijri-select" data-day="${c.day}" aria-label="${c.day} ${hijriMonthName(month)}">
      <span class="n">${c.day}</span>
      <span class="dots">${did ? '<i class="d-fast"></i>' : ''}${major ? '<i class="d-ev"></i>' : ''}${white ? '<i class="d-white"></i>' : ''}</span>
    </button>`;
  }).join('');

  // تفاصيل اليوم المحدد
  const selJ = hijriToJDN(year, month, hijriSelDay);
  const selDow = jdnDayOfWeek(selJ);
  const selKey = hijriToDateKey(year, month, hijriSelDay);
  const selEvents = getHijriDayEvents(month, hijriSelDay);
  const isFuture = selJ > todayJ;
  const didFast = fasted.has(selKey);
  const sunnah = isSunnahFastDay(year, month, hijriSelDay, selDow);
  const eventsHtml = selEvents.map(e => `
    <div class="hcal-event"><div class="ic">${icon(e.icon)}</div><div><b>${e.name}</b><p class="muted small">${e.message}</p></div></div>`).join('');
  const fastBtn = isFuture
    ? `<p class="muted small mt12">لا يمكن تسجيل صيام يوم لم يأتِ بعد</p>`
    : `<button class="btn block mt12 ${didFast ? 'secondary' : ''}" data-action="cal-toggle-fast" data-key="${selKey}">${icon(didFast ? 'xCircle' : 'check')} ${didFast ? 'إلغاء تسجيل الصيام' : 'سجّل صيام هذا اليوم'}</button>`;

  // إحصائيات الشهر
  let monthFasts = 0;
  for (let d = 1; d <= len; d++) if (fasted.has(hijriToDateKey(year, month, d))) monthFasts++;

  // المناسبات القادمة
  const upcoming = getUpcomingHijriEvents(3).map(u => `
    <div class="hcal-up"><div class="ic">${icon(u.event.icon)}</div><div class="info"><div class="t">${u.event.name}</div>
    <div class="s">${u.ongoing ? 'جارية الآن' : (u.days === 1 ? 'غدًا' : 'بعد ' + u.days + ' يوم')}</div></div></div>`).join('');

  const entries = (state.gratitudeEntries || []).slice(-10).reverse().map(g => `
    <div class="list-item"><div class="info"><div class="t">${esc(g.text)}</div><div class="s">${hijriFromKey(g.date)}</div></div>
    <button class="btn secondary" style="padding:6px 10px" aria-label="حذف" data-action="delete-gratitude" data-date="${esc(g.date)}" data-text="${esc(g.text)}">${icon('trash')}</button></div>`).join('');

  return `<div class="container">
    <h1 class="title">${icon('calendar')} ${tr('page_calendar')}</h1>

    <div class="card hcal">
      <div class="hcal-head">
        <button class="hcal-nav" data-action="hijri-prev" aria-label="الشهر السابق">${CAL_CHEV_R}</button>
        <div class="hcal-title">
          <div class="m">${hijriMonthName(month)}</div>
          <div class="y">${year}${hijriLang() === 'en' ? ' AH' : ' هـ'}</div>
        </div>
        <button class="hcal-nav" data-action="hijri-next" aria-label="الشهر التالي">${CAL_CHEV_L}</button>
      </div>
      <div class="hcal-grid">${weekdays}${cells}</div>
      <div class="hcal-foot">
        <div class="hcal-legend"><span><i class="d-ev"></i> مناسبة</span><span><i class="d-white"></i> أيام بيض</span><span><i class="d-fast"></i> صمتُه</span></div>
        ${isThisMonth ? '' : `<button class="btn secondary" style="padding:6px 12px;font-size:12px" data-action="hijri-today">اليوم</button>`}
      </div>
    </div>

    <div class="card hcal-day">
      <div class="hcal-day-head">
        <div class="big">${hijriSelDay}</div>
        <div><div style="font-weight:900">${hijriFullDate(year, month, hijriSelDay)}</div>
        ${sunnah ? `<span class="badge" style="display:inline-block;margin-top:4px">${icon('fastMoon')} يوم يُستحب صيامه</span>` : ''}</div>
      </div>
      ${eventsHtml || '<p class="muted small mt8">لا مناسبة خاصة في هذا اليوم</p>'}
      ${fastBtn}
    </div>

    <div class="card">
      <div class="row" style="justify-content:space-between"><b>${icon('fastMoon')} متتبّع الصيام</b></div>
      <div class="grid-2 mt8">
        <div class="stat-tile"><b>${monthFasts}</b><span>أيام الصيام في هذا الشهر</span></div>
        <div class="stat-tile"><b>${fastingStreak()}</b><span>أيام متتالية</span></div>
      </div>
      <p class="muted small mt8">سجل شخصي للمتابعة فقط، بدون نقاط</p>
    </div>

    ${upcoming ? `<div class="card"><h2 class="section-title">${icon('star')} المناسبات القادمة</h2>${upcoming}</div>` : ''}

    <div class="card">
      <div style="font-weight:900">${icon('heart')} دفتر الشكر</div>
      <p class="muted small mt8">اكتب شيئًا واحدًا تشكر الله عليه اليوم</p>
      <input type="text" id="gratitude-input" maxlength="100" placeholder="الحمد لله على..." class="mt8" />
      <button class="btn block mt8" data-action="save-gratitude">${icon('check')} احفظ</button>
      ${entries ? `<div class="mt12">${entries}</div>` : ''}
    </div>
  </div>`;
}

// ============================== تابة الاشتراك: 5 باقات شهرية ==============================
function getActiveSubscriptionTier() {
  if (!state.activeSubscription) return null;
  return subscriptionTiers.find(t => t.id === state.activeSubscription.tierId) || null;
}
// أعلى باقة اشتراك (آخر عنصر في subscriptionTiers) بتفتح كل حاجة في التطبيق مجانًا طول مدة الاشتراك (شهر)
function tierRank() {
  const t = getActiveSubscriptionTier();
  return t ? subscriptionTiers.findIndex(x => x.id === t.id) : -1;
}
function hasTierAtLeast(id) {
  const need = subscriptionTiers.findIndex(x => x.id === id);
  return need >= 0 && tierRank() >= need;
}
// إطارات/توهجات بتتفتح مؤقتًا بالباقة (تراكمية من أول باقة لحد الباقة الحالية) وتقفل تاني بانتهائها
function tierUnlocks(kind, id) {
  const r = tierRank();
  for (let i = 0; i <= r; i++) {
    const list = subscriptionTiers[i].perks && subscriptionTiers[i].perks[kind];
    if (list && list.includes(id)) return true;
  }
  return false;
}
function frameOwned(id) { return (state.ownedFierceFrames || []).includes(id) || hasAllAccess() || tierUnlocks('frames', id); }
function glowOwned(id) { return (state.ownedNameGlows || []).includes(id) || hasAllAccess() || tierUnlocks('glows', id); }
function validGlowId() { return (state.currentNameGlow && glowOwned(state.currentNameGlow)) ? state.currentNameGlow : ''; }
function validFrameId() { return (state.currentProfileFrame && frameOwned(state.currentProfileFrame)) ? state.currentProfileFrame : null; }
function tierNameColor() {
  const t = getActiveSubscriptionTier();
  return t ? t.color : null;
}
function hasAllAccess() {
  const t = getActiveSubscriptionTier();
  return !!(t && t.id === subscriptionTiers[subscriptionTiers.length - 1].id);
}
function renderSubscriptionTab() {
  const active = getActiveSubscriptionTier();
  const cards = subscriptionTiers.map(t => {
    const isActive = active && active.id === t.id;
    const featuresHtml = t.features.map(f => `<div class="row" style="gap:6px;align-items:flex-start;margin-top:6px"><span>✨</span><span class="small">${esc(f)}</span></div>`).join('');
    let actionHtml;
    if (isActive) {
      actionHtml = `<div class="badge mt8" style="display:inline-block;background:${t.color};color:#fff">${icon('check')} مفعّلة — تنتهي ${hijriFromKey(state.activeSubscription.expiresDate)}</div>`;
      const claimedToday = state.lastDailyBonusDate === todayStr();
      const p = t.perks || {};
      const giftParts = [];
      if (p.dailyDiamonds) giftParts.push(p.dailyDiamonds + ' 💎');
      if (p.dailyGold) giftParts.push(p.dailyGold + ' 🟡');
      if (p.dailySilver) giftParts.push(p.dailySilver + ' ⚪');
      if (hasTierAtLeast('diamond-plan')) {
        const lastC = state.lastWeeklyChestDate ? new Date(state.lastWeeklyChestDate).getTime() : 0;
        const daysLeft = Math.ceil((7 * 86400000 - (Date.now() - lastC)) / 86400000);
        actionHtml += (Date.now() - lastC >= 7 * 86400000)
          ? `<button class="btn block mt8" style="background:${t.color}" data-action="claim-weekly-chest">📦 افتح صندوق الأسبوع (هدية ثابتة كبيرة)</button>`
          : `<div class="muted small mt8">📦 صندوق الأسبوع الجاي بعد ${daysLeft} يوم</div>`;
      }
      if (giftParts.length) {
        actionHtml += claimedToday
          ? `<div class="muted small mt8">${icon('check')} استلمت هدية النهاردة، تعال بكرة تاني</div>`
          : `<button class="btn block mt8" style="background:${t.color}" data-action="claim-daily-sub-bonus">🎁 استلم هدية اليوم (${giftParts.join(' + ')})</button>`;
      }
    } else if (t.method === 'gold') {
      actionHtml = `<button class="btn block mt8" style="background:${t.color}" data-action="buy-subscription-gold" data-tier="${t.id}" data-cost="${t.goldCost}">🟡 اشترك مقابل ${t.goldCost} ذهب (شهر واحد)</button>`;
    } else {
      actionHtml = `
        <button class="btn block mt8" style="background:#25D366" data-action="open-premium-form" data-tier="${t.id}">${icon('whatsapp')} تواصل واتساب للاشتراك</button>
        <div class="row mt8" style="gap:6px">
          <input type="text" id="sub-code-${t.id}" placeholder="عندك كود تفعيل؟ اكتبه هنا" style="flex:1" />
          <button class="btn secondary" data-action="activate-subscription-code" data-tier="${t.id}">${icon('check')}</button>
        </div>
        <div class="muted small mt8" id="sub-code-err-${t.id}" style="color:var(--danger)"></div>`;
    }
    return `
    <div class="card" style="border:2px solid ${t.color}${isActive ? ';box-shadow:0 0 0 3px ' + t.color + '33' : ''}">
      <div class="row"><b style="font-size:16px">${t.icon} ${esc(t.name)}</b></div>
      <div class="muted small mt8">مدة الاشتراك: ${t.durationDays} يوم (شهر واحد) من وقت التفعيل</div>
      ${featuresHtml}
      ${actionHtml}
    </div>`;
  }).join('');
  return `<div class="container">
    <h1 class="title">👑 الاشتراك</h1>
    <p class="muted center mt8">5 باقات، كل باقة تشتغل شهر واحد بالظبط من وقت التفعيل. باقة "بريميوم" بس هي اللي تتفتح مباشرة بالذهب، والباقي بيتواصل فيه واتساب مع صاحب التطبيق</p>
    ${hasAllAccess() ? `<div class="card center mt12" style="background:linear-gradient(135deg,#C0392B,#FF6B4A);color:#fff"><b>🔓 كل حاجة في التطبيق مفتوحة ليك مجانًا دلوقتي</b><div class="small mt8">بفضل باقتك الأسطورية السارية</div></div>` : ''}
    ${cards}
  </div>`;
}

// ============================== دعوة صديق ==============================
function getShareText() {
  return 'جرّب معايا تطبيق "حصالة الحسنات" 🌙 تطبيق إسلامي جميل للأطفال فيه قصص وألعاب وأذكار ومهام يومية!';
}
function renderInviteFriendTab() {
  const text = getShareText();
  const url = (typeof location !== 'undefined' && location.href) ? location.href.split('#')[0] : '';
  const waLink = 'https://wa.me/?text=' + encodeURIComponent(text + ' ' + url);
  const tgLink = 'https://t.me/share/url?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(text);
  const xLink = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(text) + '&url=' + encodeURIComponent(url);
  return `<div class="container">
    <h1 class="title">${icon('inviteFriend')} دعوة صديق</h1>
    <p class="muted mb12">شارك التطبيق مع أصدقائك وعائلتك، وخلّيهم يستفيدوا معاك</p>
    <div class="card center">
      <div style="font-size:44px">${icon('sparkle')}</div>
      <p class="mt8" style="font-weight:800">كل ما تشارك التطبيق، بتساعد طفل تاني يتعلّم دينه بطريقة ممتعة</p>
    </div>
    <div class="grid-2 mt12">
      <a class="btn block" style="background:#25D366;text-decoration:none" href="${waLink}" target="_blank" rel="noopener">${icon('chat')} واتساب</a>
      <a class="btn block" style="background:#229ED9;text-decoration:none" href="${tgLink}" target="_blank" rel="noopener">${icon('chat')} تيليجرام</a>
      <a class="btn block" style="background:#000;text-decoration:none" href="${xLink}" target="_blank" rel="noopener">${icon('chat')} X (تويتر)</a>
      <button class="btn block" data-action="native-share">${icon('sparkle')} أي جهة تانية</button>
    </div>
    <button class="btn secondary block mt12" data-action="copy-share-link">${icon('bookOpenStar')} نسخ رابط التطبيق</button>
  </div>`;
}

// ============================== خدمات أخرى (مكان جاهز لأي ميزات جديدة مستقبلًا) ==============================
// ملف التطبيق (APK) موجود داخل مجلد downloads بجانب index.html
const APK_DOWNLOAD = { url: 'downloads/hasalit-elhassanat.apk', fileName: 'hasalit-elhassanat.apk', sizeLabel: 'حوالي 6.6 ميجابايت' };
const upcomingServices = [
  { id: 'sehety', name: 'تطبيق صحتي', desc: 'تطبيق مستقل لمتابعة الصحة والعادات الصحية اليومية', icon: 'heart' },
];
function renderCouponRedeemModal() {
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <div style="font-size:34px">🎟️</div>
      <h2 style="font-weight:900;margin:8px 0 6px">كوبون هدية</h2>
      <p class="muted mt8">اكتب كود الكوبون اللي وصلكم، ولو لسه ساري هيديك هدية مفاجأة تخربشها بإيدك!</p>
      <input type="text" id="coupon-code-input" placeholder="مثال: HASANAT-W1" class="mt8" style="text-align:center;font-weight:900;letter-spacing:1px" />
      <div id="pin-error" class="center muted" style="color:var(--danger)"></div>
      <button class="btn block mt12" data-action="redeem-coupon-code">${icon('check')} تحقق من الكوبون</button>
      <button class="btn secondary block mt8" data-action="close-modal">إلغاء</button>
    </div>
  </div>`;
}

function renderCouponScratchModal() {
  const m = modalStack[modalStack.length - 1];
  const c = m && m.coupon;
  if (!c) return '';
  let rewardLabel;
  if (c.reward.type === 'diamonds') rewardLabel = '+' + c.reward.amount + ' ألماسة 💎';
  else if (c.reward.type === 'points') rewardLabel = '+' + c.reward.amount + ' نقطة ذهبية 🪙';
  else {
    const parts = [];
    if (c.reward.diamonds) parts.push('+' + c.reward.diamonds + ' 💎');
    if (c.reward.gold) parts.push('+' + c.reward.gold + ' 🟡');
    if (c.reward.silver) parts.push('+' + c.reward.silver + ' ⚪');
    if (c.reward.points) parts.push('+' + c.reward.points + ' 🪙');
    if (c.reward.frame) parts.push('🔥 إطار');
    if (c.reward.nameGlow) parts.push('✨ اسم متوهج');
    rewardLabel = parts.join(' ');
  }
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <h2 style="font-weight:900;margin-bottom:4px">${esc(c.label || 'كوبون هدية')}</h2>
      <p class="muted mb8">اخربش الكارت بإصبعك عشان تكشف جائزتك</p>
      <div style="position:relative;width:280px;height:160px;margin:0 auto;border-radius:16px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.2)">
        <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#F2D27A,#B8862E);color:#fff;font-weight:900;font-size:22px;text-align:center;padding:10px">${rewardLabel}</div>
        <canvas id="scratch-canvas" width="280" height="160" style="position:absolute;inset:0;touch-action:none;cursor:pointer;border-radius:16px"></canvas>
      </div>
      <button class="btn secondary block mt16" data-action="force-reveal-coupon">${icon('sparkle')} مش قادر أخربش؟ اكشفها لي</button>
    </div>
  </div>`;
}

function renderRegionalNoticeModal() {
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <div class="icon-lg" style="color:var(--gold);margin:0 auto">${icon('warning')}</div>
      <h2 style="font-weight:900;margin:8px 0 6px">تنبيه هام</h2>
      <p class="muted mt8" style="line-height:2;text-align:right">نودّ إعلامكم بأنكم قد تواجهون بعض المشكلات في تحميل التطبيق أو تشغيله بشكل صحيح في بعض المناطق أو على بعض الأجهزة، وهذا الأمر خارج عن إرادتنا في بعض الأحيان. نحن نعمل جاهدين حاليًا على دراسة هذه المشكلة وإصلاحها في أقرب وقت ممكن، ونعتذر عن أي إزعاج قد يسببه ذلك. شكرًا لتفهّمكم وصبركم، ونسأل الله أن يجعل هذا العمل في ميزان حسناتنا جميعًا.</p>
      <button class="btn block mt16" data-action="close-modal">تمام، فهمت</button>
    </div>
  </div>`;
}

function renderApkModal() {
  const ua = navigator.userAgent || '';
  const isIOS = /iPad|iPhone|iPod/.test(ua);
  const inApp = /; wv\)/.test(ua) || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
  const note = isIOS
    ? '<p class="muted small mt12">ملف التحميل مخصص لأجهزة الأندرويد. على الآيفون افتح الموقع من Safari واختر "إضافة إلى الشاشة الرئيسية"</p>'
    : inApp
      ? '<p class="muted small mt12">أنت تستخدم التطبيق بالفعل، وتقدر تشارك رابط التحميل مع أصحابك</p>'
      : '<p class="muted small mt12">بعد التحميل افتح الملف لتثبيته. لو ظهرت رسالة أمان، اسمح بالتثبيت من هذا المصدر</p>';
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <img src="icons/icon-192.png" alt="حصالة الحسنات" style="width:84px;height:84px;border-radius:20px;box-shadow:0 6px 16px rgba(0,0,0,.2)" />
      <h2 style="font-weight:900;margin:10px 0 6px">حصالة الحسنات</h2>
      <p style="font-weight:800">متوفر نسخة تحميل لتطبيق حصالة الحسنات متوافقة لكل الأجهزة</p>
      <p class="muted mt8">للتحميل انقر على تحميل</p>
      <button class="btn block mt16" id="apk-download-btn" data-action="download-apk">${icon('download')} تحميل</button>
      <p class="muted small mt8" id="apk-download-status">${APK_DOWNLOAD.sizeLabel}</p>
      ${note}
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}
function renderOtherServicesTab() {
  const apkCard = `
    <div class="card" data-action="open-apk-download" style="cursor:pointer;border:1px solid var(--primary)">
      <div class="row"><img src="icons/icon-192.png" alt="" style="width:44px;height:44px;border-radius:12px" />
        <div><div style="font-weight:900">حصالة الحسنات</div><div class="muted small">تطبيق حصالة الحسنات للتحميل على الجهاز</div></div>
      </div>
      <div class="badge mt8" style="display:inline-block;background:var(--primary);color:#fff">${icon('download')} متاح للتحميل</div>
    </div>`;
  const charityCard = `
    <div class="card" data-action="open-charities" style="cursor:pointer;border:1px solid var(--gold)">
      <div class="row"><span class="emoji" style="width:44px;height:44px;border-radius:12px;background:var(--muted);display:flex;align-items:center;justify-content:center">${icon('hands')}</span>
        <div><div style="font-weight:900">جمعيات خيرية</div><div class="muted small">أرقام تحويل موثوقة لجمعيات ومستشفيات ومشاريع خيرية</div></div>
      </div>
      <div class="badge mt8" style="display:inline-block;background:var(--gold);color:#fff">${icon('heart')} تحويل مباشر</div>
    </div>`;
  const cards = apkCard + charityCard + upcomingServices.map(s => `
    <div class="card">
      <div class="row"><span class="emoji" style="width:44px;height:44px;border-radius:12px;background:var(--muted);display:flex;align-items:center;justify-content:center">${icon(s.icon)}</span>
        <div><div style="font-weight:900">${s.name}</div><div class="muted small">${s.desc}</div></div>
      </div>
      <div class="badge mt8" style="display:inline-block;background:var(--gold);color:#fff">${icon('hourglass')} قريبًا</div>
    </div>`).join('');
  return `<div class="container">
    <h1 class="title">${icon('otherServices')} ${tr('page_other')}</h1>
    <p class="muted mb12">مشاريعنا وتطبيقاتنا، وخدمات جديدة جاية قريبًا إن شاء الله</p>
    ${cards}
  </div>`;
}

// ============================== لوحة المساهمين ==============================
function renderContributorsTab() {
  const palette = ['#D9A441', '#4A9FD9', '#C1694F', '#2E7D5B', '#6C5A96', '#B8862E', '#4FA3E0', '#E0577A'];
  const cards = contributors.map((c, i) => `
    <div class="card contributor-card">
      <div class="contributor-name" style="--glow-color:${c.color || palette[i % palette.length]}; animation-delay:${i * 0.4}s">${esc(c.name)}</div>
    </div>`).join('');
  return `<div class="container">
    <h1 class="title">${icon('contributors')} بأفكار رائعة ساهموا ليجعلوا التطبيق أفضل</h1>
    ${cards}
    <p class="muted center mt16">للمساهمة بأفكارك، <span class="link-text" data-action="open-report">اضغط هنا</span></p>
  </div>`;
}

function renderTreeTab() {
  const t = state.hasanahTree || { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
  const total = (t.salah || 0) + (t.quran || 0) + (t.dhikr || 0) + (t.kindness || 0);
  const legend = HASANAH_BRANCHES.map(b => `
    <div class="stat-row">
      <div class="stat-label">${b.label}</div>
      <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${Math.min(100, (t[b.key] || 0) * 8)}%;background:${b.color}"></div></div>
      <div class="stat-value">${t[b.key] || 0}</div>
    </div>`).join('');
  const dedications = (state.dedications || []).slice().reverse().slice(0, 6).map(d => `
    <div class="list-item">
      <div class="emoji">${icon('heart')}</div>
      <div class="info"><div class="t">${esc(d.name)}</div><div class="s">${esc(d.dua)}</div></div>
    </div>`).join('') || `<p class="muted">لسه ما أهديتش حسنة لحد، جرّب دلوقتي!</p>`;
  const potSkin = treePotSkins.find(p => p.id === state.currentPotSkin) || treePotSkins[0];
  return `<div class="container">
    <h1 class="title">${icon('tree')} ${tr('page_tree')}</h1>
    <p class="muted mb8">كل عمل خير بتعمله بيكبّر فرع من فروع شجرتك. اجمع النقاط في كل النواحي عشان شجرتك تبقى وارفة!</p>
    <div class="card center">${renderHasanahTreeSvg(t, potSkin)}</div>
    <div class="card mt12">${legend}<p class="muted mt8">مجموع أعمالك: ${total}</p></div>
    <h2 class="mt16 mb8" style="font-weight:900;font-size:16px">${icon('hands')} اهدي حسنة لشخص عزيز</h2>
    <p class="muted mb8">تقدر تهدي دعوة لجدك أو جدتك أو أي حد تحبه، وتكتبله دعاء بسيط.</p>
    <div class="card">
      <input id="dedication-name" type="text" placeholder="اسم الشخص (مثلاً: جدي)" maxlength="30" />
      <textarea id="dedication-dua" class="mt8" rows="2" placeholder="اكتب دعاء بسيط له..." maxlength="120"></textarea>
      <button class="btn block mt8" data-action="add-dedication">${icon('heart')} أهدي الحسنة</button>
    </div>
    <div class="mt12">${dedications}</div>
  </div>`;
}

// ============================== مرآة المواقف ==============================
let scenarioIndex = null;
let lastScenarioIndex = null;
// ============================== السبحة الرقمية ==============================
// يبني شكل سبحة حقيقية (خرزات على شكل قلادة) بدل الدائرة القديمة: خرزات مفرّغة لسه، وخرزات ممتلئة اتعدّت، وخرزة نابضة هي الحالية
function renderTasbihBeadsSVG(total, filledInLap, ringColor) {
  const cx = 100, cy = 92, R = 76;
  const gapDeg = 64; // فجوة أسفل السبحة يتدلى منها خيط الشرابة وخرزة الإمام
  const startDeg = 90 + gapDeg / 2;
  const sweepDeg = 360 - gapDeg;
  const n = Math.max(total, 2);
  let beads = '';
  for (let i = 0; i < n; i++) {
    const deg = startDeg + (sweepDeg * i) / (n - 1);
    const rad = (deg * Math.PI) / 180;
    const x = cx + R * Math.cos(rad);
    const y = cy + R * Math.sin(rad);
    const isCurrent = i === filledInLap % n;
    const isFilled = i < filledInLap;
    const rr = isCurrent ? 11 : 7.5;
    const fill = (isFilled || isCurrent) ? ringColor : 'var(--muted)';
    const cls = isCurrent ? 'tasbih-bead-current' : '';
    beads += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rr}" fill="${fill}" class="${cls}"/>`;
  }
  const imamX = cx, imamY = cy + R;
  return `<svg viewBox="0 0 200 200" style="width:220px;height:220px;margin:0 auto;display:block">
    ${beads}
    <line x1="${imamX}" y1="${imamY}" x2="${imamX}" y2="${imamY + 26}" stroke="var(--gold)" stroke-width="3" stroke-linecap="round"/>
    <circle cx="${imamX}" cy="${imamY}" r="10" fill="var(--gold)"/>
    <circle cx="${imamX}" cy="${imamY + 32}" r="5" fill="var(--gold)"/>
    <line x1="${imamX - 4}" y1="${imamY + 36}" x2="${imamX - 4}" y2="${imamY + 50}" stroke="var(--gold)" stroke-width="2" stroke-linecap="round"/>
    <line x1="${imamX}" y1="${imamY + 38}" x2="${imamX}" y2="${imamY + 54}" stroke="var(--gold)" stroke-width="2" stroke-linecap="round"/>
    <line x1="${imamX + 4}" y1="${imamY + 36}" x2="${imamX + 4}" y2="${imamY + 50}" stroke="var(--gold)" stroke-width="2" stroke-linecap="round"/>
  </svg>`;
}

function renderTasbihTab() {
  const cur = tasbihPhrases.find(t => t.id === state.currentTasbihId) || tasbihPhrases[0];
  const count = (state.tasbihCounts && state.tasbihCounts[cur.id]) || 0;
  const free = !!state.tasbihFreeMode;
  const inCycle = free ? count : count % cur.target;
  const beadsTotal = Math.min(cur.target, 33); // خيط السبحة الحقيقية 33 خرزة، وللأذكار الأطول (زي 100) بندور اللفة أكتر من مرة
  const lapPos = free ? count % beadsTotal : inCycle % beadsTotal;
  const lapsInCycle = Math.ceil(cur.target / beadsTotal);
  const currentLap = free ? Math.floor(count / beadsTotal) + 1 : Math.floor(inCycle / beadsTotal) + 1;
  const ringColor = free ? 'var(--gold)' : 'var(--primary)';
  const chips = tasbihPhrases.map(t => `
    <button class="story-filter-btn ${cur.id === t.id ? 'active' : ''}" data-action="tasbih-select" data-id="${t.id}">${t.text}</button>`).join('');
  const learnCards = tasbihPhrases.map(t => `
    <div class="card mt12">
      <div style="font-weight:900;font-size:16px">${t.text}</div>
      <p class="muted mt8"><b>المعنى:</b> ${t.meaning}</p>
      <p class="muted mt8"><b>الفضل:</b> ${t.virtue}</p>
    </div>`).join('');
  return `<div class="container">
    <h1 class="title">${icon('tasbih')} ${tr('page_tasbih')}</h1>
    <div class="story-filter-row">${chips}</div>
    <button class="btn secondary block mt8" data-action="toggle-tasbih-free-mode">
      ${icon(free ? 'checkCircle' : 'compass')} ${free ? 'وضع حر مفعّل (عداد بلا هدف) - ارجع للهدف المحدد' : 'التبديل لوضع تسبيح حر (عداد لا نهائي)'}
    </button>
    <div class="card center mt12 tasbih-card" data-action="tasbih-tap" style="cursor:pointer;user-select:none">
      ${renderTasbihBeadsSVG(beadsTotal, lapPos, ringColor)}
      <div style="font-weight:900;font-size:26px;margin-top:-6px">${inCycle}<span class="muted" style="font-size:14px"> / ${free ? '∞' : cur.target}</span></div>
      ${!free && cur.target > beadsTotal ? `<p class="muted small">اللفة ${currentLap} من ${lapsInCycle}</p>` : ''}
      <div class="mt8" style="font-weight:900;font-size:18px">${cur.text}</div>
      <p class="muted small mt8">اضغط في أي مكان على السبحة عشان تحرّك الخرزة وتسبّح</p>
      <p class="muted small">إجمالي مرات التسبيح بهذا الذكر: ${count}</p>
      <button class="btn secondary mt8" data-action="tasbih-reset" data-id="${cur.id}" onclick="event.stopPropagation()">${icon('xCircle')} تصفير العداد</button>
    </div>
    <h2 class="section-title mt16">${icon('bookOpenStar')} تعلّم معاني التسبيح</h2>
    ${learnCards}
  </div>`;
}

function renderScenariosTab() {
  if (scenarioIndex === null) scenarioIndex = pickNextIndex(situationScenarios.length, lastScenarioIndex);
  const s = situationScenarios[scenarioIndex];
  const opts = s.options.map((o, i) => `
    <button class="btn secondary block mt8" data-action="answer-scenario" data-i="${i}">${o}</button>`).join('');
  return `<div class="container">
    <h1 class="title">${icon('compass')} ${tr('page_scenarios')}</h1>
    <p class="muted mb8">مواقف من حياتك اليومية، اختر إيه رأيك تعمل فيها وشوف الحكمة وراها</p>
    <div class="card">
      <div style="font-weight:800;line-height:1.9;font-size:15px">${s.q}</div>
      <div class="mt12">${opts}</div>
    </div>
  </div>`;
}

function renderAdhkarTab() {
  const items = adhkarCategories.map(c => `
    <div class="list-item" data-action="open-adhkar-cat" data-id="${c.id}">
      <div class="emoji">${icon(c.icon)}</div>
      <div class="info"><div class="t">${c.title}</div><div class="s">${c.description}</div></div>
    </div>`).join('');
  return `<div class="container"><h1 class="title">${icon('beads')} ${tr('page_adhkar')}</h1>
    <p class="muted mb8">${icon('sparkle')} عداد الأذكار يتصفر كل يوم جديد علشان تبدأ ذكر ربك من الأول</p>
    ${items}</div>`;
}

function renderAdhkarCategory(id) {
  const c = adhkarCategories.find(x => x.id === id);
  if (!c) return '';
  const items = c.adhkar.map(d => {
    const tapped = state.dhikrProgress[d.id] || 0;
    const done = tapped >= d.count;
    return `
    <div class="card" data-action="tap-dhikr" data-id="${d.id}" data-count="${d.count}">
      <div style="font-weight:800;line-height:2">${d.text}</div>
      <div class="muted mt8">${d.virtue}</div>
      <div class="row mt8"><span class="badge">${done ? icon('check') : ''} ${Math.min(tapped, d.count)} / ${d.count}</span><span class="muted">اضغط للعد</span></div>
    </div>`;
  }).join('');
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 style="text-align:center;font-weight:900">${icon(c.icon)} ${c.title}</h2>
      <div class="mt16">${items}</div>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ---- متجر الشخصيات ----
function renderShopTab() {
  const items = avatars.map(a => {
    const owned = a.cost === 0 || state.avatarsOwned.includes(a.id) || hasAllAccess();
    const selected = state.currentAvatar === a.id;
    return `
    <div class="card center">
      <div class="icon-lg" style="width:34px;height:34px;margin:0 auto;color:var(--primary)">${icon(a.icon)}</div>
      <div style="font-weight:800;margin-top:6px">${a.name}</div>
      <div class="muted">${a.description}</div>
      ${selected ? `<div class="badge mt8" style="display:inline-block">مُختار حالياً ${icon('check')}</div>` :
        owned ? `<button class="btn block mt8" data-action="select-avatar" data-id="${a.id}">اختر هذه الشخصية</button>` :
        `<button class="btn block mt8" data-action="buy-avatar" data-id="${a.id}" data-cost="${a.cost}">${icon('coin')} ${tr('buy_for')} ${a.cost}</button>`}
    </div>`;
  }).join('');

  const themeItems = APP_COLOR_THEMES.map(t => {
    const owned = t.cost === 0 || state.colorThemesOwned.includes(t.id) || hasAllAccess();
    const selected = state.appColorTheme === t.id;
    return `
    <div class="card center">
      <div style="width:34px;height:34px;margin:0 auto;border-radius:50%;background:linear-gradient(135deg,${t.primary},${t.gold})"></div>
      <div style="font-weight:800;margin-top:6px">${t.name}</div>
      ${selected ? `<div class="badge mt8" style="display:inline-block">${tr('currently_active')} ${icon('check')}</div>` :
        owned ? `<button class="btn block mt8" data-action="select-theme" data-id="${t.id}">تفعيل هذا اللون</button>` :
        `<button class="btn block mt8" data-action="buy-theme" data-id="${t.id}" data-cost="${t.cost}">${icon('coin')} ${tr('buy_for')} ${t.cost}</button>`}
    </div>`;
  }).join('');

  const accItems = petAccessories.map(a => {
    const owned = state.petAccessoriesOwned.includes(a.id) || hasAllAccess();
    const selected = state.currentPetAccessory === a.id;
    return `
    <div class="card center">
      <div class="icon-lg" style="width:34px;height:34px;margin:0 auto;color:var(--gold)">${icon(a.icon)}</div>
      <div style="font-weight:800;margin-top:6px">${a.name}</div>
      ${selected ? `<div class="badge mt8" style="display:inline-block">على حيوانك الآن ${icon('check')}</div>` :
        owned ? `<button class="btn block mt8" data-action="select-pet-accessory" data-id="${a.id}">البس حيوانك إياها</button>` :
        `<button class="btn block mt8" data-action="buy-pet-accessory" data-id="${a.id}" data-cost="${a.cost}">${icon('coin')} ${tr('buy_for')} ${a.cost}</button>`}
    </div>`;
  }).join('');

  const frameItems = certificateFrames.filter(f => !f.diamondOnly).map(f => {
    const owned = f.cost === 0 || state.certFramesOwned.includes(f.id) || hasAllAccess();
    const selected = state.currentCertFrame === f.id;
    return `
    <div class="card center">
      <div style="width:44px;height:30px;margin:0 auto;border:${f.border};border-radius:6px"></div>
      <div style="font-weight:800;margin-top:6px">${f.name}</div>
      ${selected ? `<div class="badge mt8" style="display:inline-block">${tr('currently_active')} ${icon('check')}</div>` :
        owned ? `<button class="btn block mt8" data-action="select-cert-frame" data-id="${f.id}">تفعيل هذا الإطار</button>` :
        `<button class="btn block mt8" data-action="buy-cert-frame" data-id="${f.id}" data-cost="${f.cost}">${icon('coin')} ${tr('buy_for')} ${f.cost}</button>`}
    </div>`;
  }).join('');

  const potItems = treePotSkins.filter(p => !p.diamondOnly).map(p => {
    const owned = p.cost === 0 || state.potSkinsOwned.includes(p.id) || hasAllAccess();
    const selected = state.currentPotSkin === p.id;
    return `
    <div class="card center">
      <div style="width:34px;height:24px;margin:0 auto;border-radius:0 0 10px 10px;background:linear-gradient(180deg,${p.c1},${p.c2})"></div>
      <div style="font-weight:800;margin-top:6px">${p.name}</div>
      ${selected ? `<div class="badge mt8" style="display:inline-block">${tr('currently_active')} ${icon('check')}</div>` :
        owned ? `<button class="btn block mt8" data-action="select-pot-skin" data-id="${p.id}">تفعيل هذا الإناء</button>` :
        `<button class="btn block mt8" data-action="buy-pot-skin" data-id="${p.id}" data-cost="${p.cost}">${icon('coin')} ${tr('buy_for')} ${p.cost}</button>`}
    </div>`;
  }).join('');

  const bgItems = backgroundColorThemes.map(b => {
    const owned = b.cost === 0 || state.backgroundThemesOwned.includes(b.id) || hasAllAccess();
    const selected = state.currentBackgroundTheme === b.id;
    return `
    <div class="card center">
      <div style="width:44px;height:30px;margin:0 auto;border-radius:8px;background:${b.bg};border:2px solid ${b.splash}"></div>
      <div style="font-weight:800;margin-top:6px">${b.name}</div>
      ${selected ? `<div class="badge mt8" style="display:inline-block">${tr('currently_active')} ${icon('check')}</div>` :
        owned ? `<button class="btn block mt8" data-action="select-bg-theme" data-id="${b.id}">تفعيل هذه الخلفية</button>` :
        `<button class="btn block mt8" data-action="buy-bg-theme" data-id="${b.id}" data-cost="${b.cost}">${icon('coin')} ${tr('buy_for')} ${b.cost}</button>`}
    </div>`;
  }).join('');

  // إطارات نادرة فاخرة (ذهب/فضة/ماس) + أسماء متوهجة + لقب "داعم مميز" — أشكال تجميلية بحتة بدون أي صلاحية إدارية
  const currencyMeta = { gold: { emoji: '🟡', label: 'ذهب' }, silver: { emoji: '⚪', label: 'فضة' }, diamonds: { emoji: '💎', label: 'ماس' } };
  const goldCards = fierceFrames.map(f => {
    const cm = currencyMeta[f.currency];
    const owned = frameOwned(f.id);
    const selected = validFrameId() === f.id;
    return `
    <div class="card diamond-vault-card" style="border:1px solid #FF4B2B">
      <div class="row"><div><div style="font-weight:900">${f.name} 🔥</div><div class="muted small">إطار احتراقي فاخر جدًا وغالي جدًا</div></div></div>
      ${selected
        ? `<div class="badge mt8" style="display:inline-block;background:#FF4B2B;color:#fff">${icon('check')} ${tr('currently_active')}</div>`
        : owned
          ? `<button class="btn block mt8" style="background:#FF4B2B" data-action="select-profile-frame" data-id="${f.id}">استخدم هذا الإطار</button>`
          : `<button class="btn block mt8" style="background:#B8862E" data-action="buy-rare-item" data-key="frame:${f.id}" data-currency="${f.currency}" data-cost="${f.cost}">${cm.emoji} افتح مقابل ${f.cost} ${cm.label}</button>`}
    </div>`;
  }).join('');
  const glowCards = nameGlowStyles.map(g => {
    const cm = currencyMeta[g.currency];
    const owned = glowOwned(g.id);
    const selected = validGlowId() === g.id;
    return `
    <div class="card diamond-vault-card" style="border:1px solid #FF3B30">
      <div class="row"><div><div style="font-weight:900;${g.css}">${g.name} ✨</div><div class="muted small">اسمك يظهر متوهج بجانبه في كل التطبيق (شكل تجميلي فقط)</div></div></div>
      ${selected
        ? `<div class="badge mt8" style="display:inline-block;background:#FF3B30;color:#fff">${icon('check')} ${tr('currently_active')}</div>`
        : owned
          ? `<button class="btn block mt8" style="background:#FF3B30" data-action="select-name-glow" data-id="${g.id}">استخدم هذا التوهج</button>`
          : `<button class="btn block mt8" style="background:#B8862E" data-action="buy-rare-item" data-key="glow:${g.id}" data-currency="${g.currency}" data-cost="${g.cost}">${cm.emoji} افتح مقابل ${g.cost} ${cm.label}</button>`}
    </div>`;
  }).join('');
  const supporterCard = `
    <div class="card diamond-vault-card" style="border:1px solid #D4A017">
      <div class="row"><div><div style="font-weight:900">${supporterBadge.name}</div><div class="muted small">لقب وشكل تجميلي فقط (بدون أي صلاحية إدارية)، لأكثر الداعمين تميزًا</div></div></div>
      ${(state.supporterBadgeOwned || hasAllAccess())
        ? `<div class="badge mt8" style="display:inline-block;background:#D4A017;color:#fff">${icon('check')} ${tr('currently_active')}</div>`
        : `<button class="btn block mt8" style="background:#8A8FA0" data-action="buy-supporter-badge">🟡 ${supporterBadge.goldCost} ذهب أو ⚪ ${supporterBadge.silverCost} فضة</button>`}
    </div>`;

  return `<div class="container">
    <h1 class="title">${icon('bag')} ${tr('page_shop')}</h1><div class="grid-2">${items}</div>
    <h2 class="section-title mt16">${icon('sparkle')} ألوان التطبيق</h2><div class="grid-2">${themeItems}</div>
    <h2 class="section-title mt16">${icon('heart')} إكسسوارات الحيوان الأليف</h2><div class="grid-2">${accItems}</div>
    <h2 class="section-title mt16">${icon('bookOpenStar')} إطارات شهادة التقدير</h2><div class="grid-2">${frameItems}</div>
    <h2 class="section-title mt16">${icon('tree')} أواني شجرة الحسنات</h2><div class="grid-2">${potItems}</div>
    <h2 class="section-title mt16">${icon('prayerTimes')} ألوان الخلفية وشاشة البداية</h2><div class="grid-2">${bgItems}</div>
    <h2 class="section-title mt16">🔥 إطارات نادرة فاخرة (ذهب/فضة/ماس)</h2><div class="grid-2">${goldCards}</div>
    <h2 class="section-title mt16">✨ أسماء متوهجة</h2><div class="grid-2">${glowCards}</div>
    <h2 class="section-title mt16">🏅 ألقاب مميزة</h2>${supporterCard}
  </div>`;
}
// يبني خطوات الصلاة الصحيحة الكاملة بحسب عدد ركعاتها الفعلي (تشهد أول/أخير، والقيام لركعة جديدة)
function arabicOrdinal(n) {
  return ['الأولى', 'الثانية', 'الثالثة', 'الرابعة'][n - 1] || (n + '');
}
function buildPrayerSteps(rakahs) {
  const steps = [];
  for (let r = 1; r <= rakahs; r++) {
    if (r === 1) {
      steps.push({ title: 'تكبيرة الإحرام والنية', desc: 'استقبل القبلة، انوِ الصلاة بقلبك، ثم قل: "الله أكبر" رافعاً يديك حتى الأذنين أو الكتفين، وضع يدك اليمنى على اليسرى فوق صدرك.', pose: 'takbir' });
      steps.push({ title: `القيام - الركعة ${arabicOrdinal(r)}`, desc: 'اقرأ سورة الفاتحة، ثم سورة قصيرة أخرى من القرآن.', pose: 'qiyam' });
    } else {
      steps.push({ title: `القيام - الركعة ${arabicOrdinal(r)}`, desc: `قم قائلاً "الله أكبر"، واقرأ الفاتحة${r <= 2 ? ' ثم سورة أخرى' : ' وحدها غالبًا'}.`, pose: 'qiyam' });
    }
    steps.push({ title: 'الركوع', desc: 'قل: "الله أكبر" واحنِ ظهرك مستقيماً واضعاً يديك على ركبتيك، وقل: "سبحان ربي العظيم" ثلاث مرات.', pose: 'ruku' });
    steps.push({ title: 'الرفع من الركوع', desc: 'قم مستقيماً وقل: "سمع الله لمن حمده، ربنا ولك الحمد".', pose: 'itidal' });
    steps.push({ title: 'السجود الأول', desc: 'قل: "الله أكبر" واسجد على الجبهة والأنف واليدين والركبتين وأطراف القدمين، وقل: "سبحان ربي الأعلى" ثلاث مرات.', pose: 'sujood' });
    steps.push({ title: 'الجلوس بين السجدتين', desc: 'اجلس مطمئناً وقل: "رب اغفر لي".', pose: 'julus' });
    steps.push({ title: 'السجود الثاني', desc: 'كرر السجود تماماً كما فعلت أول مرة.', pose: 'sujood' });

    const isLast = r === rakahs;
    if (r === 2 && rakahs > 2) {
      steps.push({ title: 'التشهد الأول', desc: 'اجلس وقل: "التحيات لله والصلوات والطيبات، السلام عليك أيها النبي ورحمة الله وبركاته، السلام علينا وعلى عباد الله الصالحين، أشهد أن لا إله إلا الله وأشهد أن محمداً عبده ورسوله"، ثم قم للركعة التالية بلا تسليم.', pose: 'julus' });
    } else if (isLast) {
      steps.push({ title: 'التشهد الأخير', desc: 'اجلس وقل التشهد كاملاً، ثم أضف الصلاة الإبراهيمية: "اللهم صلِّ على محمد وعلى آل محمد كما صليت على إبراهيم وعلى آل إبراهيم، إنك حميد مجيد..."', pose: 'julus' });
      steps.push({ title: 'التسليم', desc: 'التفت بوجهك يميناً وقل: "السلام عليكم ورحمة الله"، ثم يساراً وكرر السلام، وبذلك تنتهي الصلاة.', pose: 'julus' });
    }
  }
  return steps;
}

// ============================== اتجاه القبلة ==============================
let qiblaBearing = null; // null=جاري التحديد، 'error'=فشل، رقم=درجة الاتجاه من الشمال
function computeQiblaBearing(lat, lon) {
  const toRad = d => d * Math.PI / 180;
  const kLat = toRad(21.4225), kLon = toRad(39.8262);
  const phi1 = toRad(lat), dLon = kLon - toRad(lon);
  const y = Math.sin(dLon) * Math.cos(kLat);
  const x = Math.cos(phi1) * Math.sin(kLat) - Math.sin(phi1) * Math.cos(kLat) * Math.cos(dLon);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
function openQiblaModal() {
  qiblaBearing = null;
  openModal('qibla');
  if (!navigator.geolocation) { qiblaBearing = 'error'; render(); return; }
  navigator.geolocation.getCurrentPosition(
    pos => { qiblaBearing = computeQiblaBearing(pos.coords.latitude, pos.coords.longitude); render(); },
    () => { qiblaBearing = 'error'; render(); },
    { timeout: 8000 }
  );
}
function renderQiblaModal() {
  let body;
  if (qiblaBearing === null) {
    body = `<p class="muted center mt12">${icon('hourglass')} جاري تحديد موقعك لحساب اتجاه القبلة...</p>`;
  } else if (qiblaBearing === 'error') {
    body = `<p class="muted center mt12">تعذّر تحديد موقعك. من فضلك اسمح للمتصفح بالوصول لموقعك وحاول مرة أخرى</p>`;
  } else {
    body = `
      <div class="qibla-compass mt12">
        <div class="qibla-ring">${icon('compass')}</div>
        <div class="qibla-needle" style="transform:translate(-50%,-100%) rotate(${qiblaBearing}deg)">${icon('mosque')}</div>
      </div>
      <p class="center mt12">اتجاه القبلة: <b>${Math.round(qiblaBearing)}°</b> من الشمال</p>
      <p class="muted center small">وجّه الجزء العلوي من جوالك ناحية الشمال (استخدم بوصلة حقيقية إن أمكن)، ثم أدر جسمك بمقدار الدرجة المذكورة نحو أيقونة المسجد</p>`;
  }
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <h2 style="font-weight:900">${icon('compass')} اتجاه القبلة</h2>
      ${body}
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== مواقيت الصلاة والتنبيه عند دخول الوقت ==============================
// نستخدم واجهة Aladhan العامة الموثوقة لحساب المواقيت الحقيقية حسب موقع الطفل
let prayerTimesToday = null;
let prayerTimesDate = '';
let prayerTimesApprox = false;   // true = المواقيت تقريبية لمدينة افتراضية لأن الموقع مش متاح
let prayerFetchBusy = false;
let prayerLastAttempt = 0;
const PRAYER_CACHE_KEY = 'hasana_prayer_cache_v1';
const PRAYER_FALLBACK = { lat: 30.0444, lon: 31.2357, name: 'القاهرة' };

// يقرأ مواقيت اليوم المخزّنة (تشتغل أوفلاين وبتوفّر طلبات الشبكة)
function loadCachedPrayerTimes() {
  try {
    const c = JSON.parse(localStorage.getItem(PRAYER_CACHE_KEY) || 'null');
    if (c && c.date === todayStr() && c.timings && c.timings.Fajr) {
      prayerTimesToday = c.timings; prayerTimesDate = c.date; prayerTimesApprox = !!c.approx;
      return true;
    }
  } catch (e) {}
  return false;
}
// آخر إحداثيات حقيقية اتحدّدت قبل كده (لو الموقع اتقفل النهاردة نستخدمها بدل المدينة الافتراضية)
function lastKnownCoords() {
  try {
    const c = JSON.parse(localStorage.getItem(PRAYER_CACHE_KEY) || 'null');
    if (c && !c.approx && typeof c.lat === 'number' && typeof c.lon === 'number') return { lat: c.lat, lon: c.lon };
  } catch (e) {}
  return null;
}
function requestPrayerTimes(lat, lon, approx) {
  return fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}&method=5`)
    .then(r => r.json())
    .then(json => {
      const t = json && json.data && json.data.timings;
      if (!t || !t.Fajr) throw new Error('bad prayer response');
      prayerTimesToday = t; prayerTimesDate = todayStr(); prayerTimesApprox = !!approx;
      try { localStorage.setItem(PRAYER_CACHE_KEY, JSON.stringify({ date: prayerTimesDate, timings: t, approx: !!approx, lat, lon })); } catch (e) {}
      render();
    });
}
function fetchPrayerTimesIfNeeded(force) {
  if (!force && prayerTimesDate === todayStr()) return;
  if (!force && loadCachedPrayerTimes()) return;
  if (prayerFetchBusy) return;
  if (!force && Date.now() - prayerLastAttempt < 10 * 60 * 1000) return; // لا نزعج المستخدم بطلب إذن الموقع كل دقيقة
  prayerLastAttempt = Date.now();
  prayerFetchBusy = true;
  const done = () => { prayerFetchBusy = false; };
  const fallback = () => {
    const k = lastKnownCoords() || PRAYER_FALLBACK;
    const approx = !lastKnownCoords();
    requestPrayerTimes(k.lat, k.lon, approx).catch(() => {}).then(done);
  };
  if (!navigator.geolocation) { fallback(); return; }
  navigator.geolocation.getCurrentPosition(
    pos => requestPrayerTimes(pos.coords.latitude, pos.coords.longitude, false).catch(() => {}).then(done),
    () => fallback(),
    { timeout: 8000, maximumAge: 3600000 }
  );
}
// ============================== تاب مواقيت الصلاة ==============================
function renderPrayerTimesTab() {
  const names = { Fajr: 'الفجر', Sunrise: 'الشروق', Dhuhr: 'الظهر', Asr: 'العصر', Maghrib: 'المغرب', Isha: 'العشاء' };
  if (!prayerTimesToday) {
    return `<div class="container">
      <h1 class="title">${icon('prayerTimes')} ${tr('page_prayerTimes')}</h1>
      <p class="muted center mt16">${icon('hourglass')} جاري تحميل مواقيت الصلاة...</p>
      <p class="muted center small mt8">تحتاج اتصال بالإنترنت أول مرة في اليوم. لو ما ظهرتش المواقيت اضغط إعادة المحاولة، ولدقة أفضل اسمح للتطبيق بالوصول لموقعك</p>
      <button class="btn block mt16" data-action="refresh-prayer-times">${icon('compass')} إعادة المحاولة</button>
    </div>`;
  }
  const now = new Date();
  const hhmm = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
  let nextKey = null;
  for (const key of Object.keys(names)) {
    if (key === 'Sunrise') continue;
    const t = (prayerTimesToday[key] || '').slice(0, 5);
    if (t && t > hhmm) { nextKey = key; break; }
  }
  // العدّ التنازلي للصلاة القادمة (بعد العشاء نحسب حتى فجر بكرة تقريبيًا)
  const toMin = (t) => { const m = /^(\d{1,2}):(\d{2})/.exec(t || ''); return m ? Number(m[1]) * 60 + Number(m[2]) : null; };
  const nowMin = now.getHours() * 60 + now.getMinutes();
  let remainMin = null;
  if (nextKey) { const tm = toMin(prayerTimesToday[nextKey]); if (tm !== null) remainMin = tm - nowMin; }
  else { const fm = toMin(prayerTimesToday.Fajr); if (fm !== null) { remainMin = fm + 1440 - nowMin; nextKey = 'Fajr'; } }
  const remainText = remainMin === null ? '' : (Math.floor(remainMin / 60) ? Math.floor(remainMin / 60) + ' ساعة و ' : '') + (remainMin % 60) + ' دقيقة';
  const countdown = remainMin === null ? '' : `
    <div class="card center" style="border:1px solid var(--gold)">
      <div class="muted small">الصلاة القادمة: ${names[nextKey]}</div>
      <div style="font-weight:900;font-size:20px;margin-top:4px">بعد ${remainText}</div>
    </div>`;
  const approxNote = prayerTimesApprox ? `<p class="muted small mb8" style="color:var(--danger)">${icon('warning')} المواقيت تقريبية لمدينة ${PRAYER_FALLBACK.name} لأن الموقع غير متاح. فعّل إذن الموقع ثم اضغط "تحديث" لمواقيت مدينتك بدقة</p>` : '';
  const rows = Object.keys(names).map(key => {
    const t = (prayerTimesToday[key] || '').slice(0, 5);
    const isNext = key === nextKey;
    return `
    <div class="task-row" style="${isNext ? 'border:2px solid var(--primary);border-radius:12px' : ''}">
      <div><div class="name">${isNext ? icon('sparkle') : ''} ${names[key]}</div>${isNext ? '<div class="pts">الصلاة القادمة</div>' : ''}</div>
      <b style="font-size:16px">${t || '--:--'}</b>
    </div>`;
  }).join('');
  return `<div class="container">
    <h1 class="title">${icon('prayerTimes')} ${tr('page_prayerTimes')}</h1>
    <p class="muted mb8">تُحسب تلقائيًا حسب موقعك الحالي، وتتحدّث كل يوم بالتوقيت الصحيح المناسب لمنطقتك</p>
    ${approxNote}
    ${countdown}
    <div class="card">${rows}</div>
    <button class="btn secondary block mt12" data-action="refresh-prayer-times">${icon('compass')} تحديث الموقع والمواقيت الآن</button>
    <p class="muted center small mt8">آخر تحديث: ${hijriFromKey(prayerTimesDate)}</p>
  </div>`;
}

// كل دقيقة: هل حان وقت إحدى الصلوات الآن؟ إن كان كذلك، نبّه المؤذن الطفل بنغمة محترمة وشعار على الشاشة (وليس أذانًا مُصنَّعًا، احترامًا لقدسية لفظ الأذان)
function checkPrayerTimeNow() {
  if (!prayerTimesToday) return;
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const names = { Fajr: 'الفجر', Dhuhr: 'الظهر', Asr: 'العصر', Maghrib: 'المغرب', Isha: 'العشاء' };
  Object.keys(names).forEach(key => {
    const t = prayerTimesToday[key];
    if (!t) return;
    const mm = /^(\d{1,2}):(\d{2})/.exec(t);
    if (!mm) return;
    const tMin = Number(mm[1]) * 60 + Number(mm[2]);
    // نسمح بفارق حتى 5 دقايق لأن المتصفح ممكن يبطّئ المؤقّت وهو في الخلفية، فكان التنبيه بيفوت
    if (nowMin >= tMin && nowMin - tMin <= 5 && state.lastAdhanNotified !== key + todayStr()) {
      state.lastAdhanNotified = key + todayStr();
      saveState();
      playPrayerReminderSound();
      sendPhoneNotification('حان وقت الصلاة 🕌', 'حان الآن وقت صلاة ' + names[key]);
      adhanBannerPrayer = names[key];
      render();
    }
  });
}
let adhanBannerPrayer = null;

// ============================== تذكيرات يومية: قرآن، صلاة على النبي، تسبيح، عبادات عامة ==============================
// تعمل مرة واحدة في اليوم لكل نوع، في وقت مناسب، فقط لو الطفل لسه ما عملش النشاط ده النهاردة
function checkDailyReminders() {
  if (!state.notificationsEnabled) return;
  const now = new Date();
  const hour = now.getHours();
  const today = todayStr();
  if (!state.lastReminderSent) state.lastReminderSent = {};
  const sent = state.lastReminderSent;

  // أذكار الصباح (بعد الفجر بشوية)
  if (hour === 7 && sent.azkarSabah !== today && state.tasksApproved['azkar_sabah'] !== today) {
    sent.azkarSabah = today; saveState();
    sendPhoneNotification('أذكار الصباح ☀️', 'ابدأ يومك بأذكار الصباح، فيها حفظ وبركة طول يومك');
  }

  // تذكير قراءة القرآن (بعد العصر تقريبًا)
  if (hour === 16 && sent.quran !== today && state.tasksApproved['quran_reading'] !== today) {
    sent.quran = today; saveState();
    sendPhoneNotification('وقت القرآن 📖', 'ما قرأتش القرآن النهاردة لسه، اقرأ ولو صفحة واحدة');
  }

  // تذكير عام بالعبادات (قبل المغرب، لو لسه معملش أي مهمة النهاردة)
  if (hour === 17 && sent.worship !== today && (state.tasksApprovedTotal || 0) === (sent.worshipBaseline || 0)) {
    sent.worship = today; sent.worshipBaseline = state.tasksApprovedTotal || 0; saveState();
    sendPhoneNotification('يوم مليء بالخير ينتظرك 🌟', 'النهاردة لسه ما بدأتش مهامك، يلا اكسب حسنات!');
  }

  // أذكار المساء
  if (hour === 18 && sent.azkarMasaa !== today && state.tasksApproved['azkar_masaa'] !== today) {
    sent.azkarMasaa = today; saveState();
    sendPhoneNotification('أذكار المساء 🌆', 'متنساش أذكار المساء، فيها حفظ وأمان طول الليل');
  }

  // تذكير الصلاة على النبي ﷺ (وقت الظهر تقريبًا)
  if (hour === 13 && sent.salawat !== today && (state.tasbihCounts?.salatalannabi || 0) === 0) {
    sent.salawat = today; saveState();
    sendPhoneNotification('صلِّ على النبي ﷺ 🌙', 'اللهم صلِّ على سيدنا محمد، جرّب سبحة الصلاة على النبي');
  }

  // تذكير التسبيح (المساء)
  if (hour === 19 && sent.tasbih !== today && Object.values(state.tasbihCounts || {}).every(c => !c)) {
    sent.tasbih = today; saveState();
    sendPhoneNotification('وقت التسبيح 📿', 'سبّح شوية دلوقتي، سبحان الله وبحمده');
  }

  // تذكير الاستغفار (قبل النوم)
  if (hour === 21 && sent.istighfar !== today) {
    sent.istighfar = today; saveState();
    sendPhoneNotification('استغفر الله 🤍', 'قبل ما تنام، استغفر ربنا كذا مرة، فيه خير كتير');
  }

  // تذكير خطط الكفارة النشطة (لو فيه يوم لسه ما اتسجّلش النهاردة)
  if (hour === 20 && sent.kaffara !== today) {
    const pending = (state.kaffaraPlans || []).find(p => p.doneDates.length < p.totalDays && !p.doneDates.includes(today));
    if (pending) {
      sent.kaffara = today; saveState();
      sendPhoneNotification('تذكير بخطة الكفارة 🌙', 'متنساش تسجّل صيام النهاردة في خطة "' + (pending.label || 'الكفارة') + '"');
    }
  }
}

function renderPrayerTab() {
  const items = prayerLessons.map(p => `
    <div class="list-item" data-action="open-prayer" data-id="${p.id}">
      <div class="emoji">${icon('mosque')}</div>
      <div class="info"><div class="t">${p.name}</div><div class="s">${p.rakahs} ركعات · ${p.type}</div></div>
    </div>`).join('');
  return `<div class="container"><h1 class="title">${icon('mosque')} ${tr('page_prayer')}</h1>
    <p class="muted mb8">اضغط على أي صلاة لتتعلم خطواتها بالرسم التوضيحي المتحرك، حتى صلاة العيد</p>
    <button class="btn secondary block mb12" data-action="open-qibla">${icon('compass')} اتجاه القبلة</button>
    ${items}</div>`;
}

// ============================== شرح الصلاة المتحرك (يعمل بالكامل داخل التطبيق، بلا فيديو خارجي) ==============================
// ملاحظة: هذا عرض متحرك برسوم توضيحية وليس فيديو مصوَّر حقيقي (لا تتوفر بيئة العمل هذه على أي وسيلة لتسجيل
// أو تحميل فيديوهات فعلية)، لكنه يعمل بالكامل محليًا داخل التطبيق نفسه دون أي رابط أو موقع خارجي.
let prayerPlayer = { playing: false, index: 0, timer: null };
function stopPrayerPlayer() {
  if (prayerPlayer.timer) clearInterval(prayerPlayer.timer);
  prayerPlayer.timer = null; prayerPlayer.playing = false;
}
function renderPrayerPlayer(steps) {
  const i = Math.min(prayerPlayer.index, steps.length - 1);
  const s = steps[i];
  const dots = steps.map((_, idx) => `<span class="player-dot ${idx === i ? 'active' : ''}"></span>`).join('');
  return `
  <div class="card center" style="border:2px solid var(--primary)">
    <div style="font-weight:900">${icon('sparkle')} خطوات الصلاة بالصور</div>
    <div class="prayer-pose-frame" style="width:140px;height:170px;margin:12px auto">${poseSVG(s.pose)}</div>
    <div style="font-weight:800">${s.title}</div>
    <p class="muted small mt8">${s.desc}</p>
    <div class="player-dots mt8">${dots}</div>
    <div class="row center mt12" style="gap:8px">
      <button class="icon-btn" data-action="prayer-player-prev">${icon('compass')}</button>
      <button class="btn" style="padding:10px 20px" data-action="prayer-player-toggle">${prayerPlayer.playing ? icon('stop') + ' إيقاف' : icon('speaker') + ' تشغيل'}</button>
      <button class="icon-btn" data-action="prayer-player-next">${icon('compass')}</button>
    </div>
  </div>`;
}

function renderPrayerDetail(id) {
  const p = prayerLessons.find(x => x.id === id);
  if (!p) return '';
  if (prayerPlayer.forId !== id) { stopPrayerPlayer(); prayerPlayer.index = 0; prayerPlayer.forId = id; }
  const stepsToShow = buildPrayerSteps(p.rakahs);
  const stepsHtml = stepsToShow.map((s, i) => `
    <div class="card prayer-step-card">
      <div><div class="prayer-pose-frame">${poseSVG(s.pose)}</div><div class="center muted" style="font-size:11px">${i+1}</div></div>
      <div class="txt"><div style="font-weight:800">${s.title}</div><div class="muted mt8">${s.desc}</div></div>
    </div>`).join('');
  const extraNote = id === 'eid' ? `<div class="card" style="background:var(--gold);color:#3a2a00"><b>ملاحظة مهمة:</b> في صلاة العيد تُضاف تكبيرات زائدة: 7 تكبيرات بعد تكبيرة الإحرام في الركعة الأولى، و5 تكبيرات بعد القيام في الركعة الثانية، قبل بدء القراءة في كل ركعة.</div>` : '';
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 style="text-align:center;font-weight:900">${icon('mosque')} ${p.name}</h2>
      <p class="muted center">${p.rakahs} ركعات · ${p.type}</p>
      <p class="center mt8">${p.notes}</p>
      ${extraNote}
      ${renderPrayerPlayer(stepsToShow)}
      <div class="mt16">${stepsHtml}</div>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== الشريط السفلي ==============================
// ============================== الوضع التعليمي (يعمل تلقائيًا أول مرة فقط) ==============================
const TAB_TUTORIAL_TEXT = {
  home: 'من هنا تشوف مهامك اليومية زي الصلاة وقراءة القرآن، وتضغط "حصل" بعد ما تخلصها عشان تاخد نقاطها بعد تأكيد والديك.',
  pet: 'حيوانك الأليف بيكبر ويتطور كل ما بتجمع نقاط أكتر، اعتني بيه واستمتع بمشاهدته يتحرك على الشاشة.',
  assistant: '"فاعل الخير" مساعدك الذكي، تقدر تسأله أي سؤال إسلامي بسيط وهيجاوبك بطريقة مناسبة لسنك.',
  stories: 'مجموعة قصص إسلامية جميلة وهادفة، بعضها مجاني وبعضها تشتريه بالنقاط اللي جمعتها.',
  quiz: 'اختبر معلوماتك الدينية بأسئلة ممتعة، وكل إجابة صحيحة تكسبك نقاط ومعرفة جديدة.',
  games: 'ألعاب إسلامية تعليمية تجمع بين المتعة والفائدة.',
  challenges: 'تحديات يومية وأسبوعية تزيد حماسك لفعل الخير وتكافئك بنقاط إضافية.',
  rewards: 'اعرف مستواك الحالي والمكافآت اللي تقدر تفتحها كل ما زادت نقاطك.',
  achievements: 'كل إنجاز تحققه بيدّيك شهادة تقدير جميلة تقدر تحتفظ بها أو تشاركها مع أهلك.',
  quran: 'اقرأ واستمع للقرآن الكريم كاملًا، واحفظ آيات جديدة وتابع تقدّمك في كل سورة.',
  hadith: 'مجموعة كبيرة من الأحاديث النبوية الصحيحة، مع شرح بسيط لكل حديث.',
  adhkar: 'أذكار الصباح والمساء وأذكار متنوعة، مع عدّاد يحفظ تقدّمك في كل يوم.',
  sunnah: 'سنن يومية بسيطة كان يحرص عليها النبي ﷺ، حاول تجعلها عادة يومية عندك.',
  prayerTimes: 'مواقيت الصلاة محسوبة تلقائيًا حسب مكانك، مع تنبيه لك عند دخول وقت كل صلاة.',
  contributors: 'أفكار من مستخدمين رائعين ساعدوا في تطوير التطبيق، وتقدر تساهم بفكرتك كمان.',
  otherServices: 'مشاريع وتطبيقات تانية من نفس فريق العمل، وهتلاقي هنا رابط تحميل تطبيق حصالة الحسنات نفسه.',
  inviteFriend: 'شارك التطبيق مع أصدقائك وعائلتك عشان يستفيدوا منه هما كمان.',
  diamondVault: 'الألماس عملة نادرة تجمعها من حفظ آيات القرآن، وتفتح بيها ميزات حصرية.',
  events: 'فعاليات حصرية تُشترى بالألماس، فيها جولات ألعاب خاصة ومكافآت كبيرة مش موجودة في مكان تاني.',
  asmaHusna: 'احفظ أسماء الله الحسنى بالترتيب مع تأكيد والديك على كل اسم جديد.',
  kaffara: 'حاسبة بسيطة تساعدك تتابع أيام صيام الكفارة اللي عليك.',
  safeVideos: 'فيديوهات يختارها والداك بنفسهم، تتفرج عليها بأمان بدون تعليقات أو اقتراحات خارجية.',
  halalScanner: 'صوّر مكونات أي منتج، والتطبيق هيدوّر لك على أي رموز مشبوهة فيها.',
  tree: 'شجرة حسناتك بتكبر كل ما عملت خير، وتقدر تهدي حسنة لشخص عزيز عليك.',
  scenarios: 'مواقف حياتية بسيطة تتعلم منها إزاي تتصرف بأخلاق إسلامية صحيحة.',
  tasbih: 'سبحة رقمية تساعدك تعدّ أذكارك وتسبيحك بسهولة.',
  shop: 'استبدل نقاطك بمظاهر وإطارات وشخصيات جديدة لتخصيص تطبيقك.',
  prayer: 'تعلّم خطوات الصلاة كاملة بالرسم التوضيحي لكل صلاة، بما فيها صلاة الجمعة والعيد.',
};
let tutorialActive = false;
let tutorialIndex = 0;
let tutorialTimer = null;
const TUTORIAL_STEP_MS = 4200;

function startTutorial() {
  tutorialActive = true;
  tutorialIndex = 0;
  currentMode = 'child';
  currentTab = ALL_TABS[0].id;
  clearInterval(tutorialTimer);
  tutorialTimer = setInterval(advanceTutorial, TUTORIAL_STEP_MS);
  render();
}
function advanceTutorial() {
  if (!tutorialActive) return;
  tutorialIndex++;
  if (tutorialIndex >= ALL_TABS.length) { endTutorial(); return; }
  currentTab = ALL_TABS[tutorialIndex].id;
  render();
}
function endTutorial() {
  tutorialActive = false;
  clearInterval(tutorialTimer); tutorialTimer = null;
  currentTab = 'home';
  render();
}
function renderTutorialOverlay() {
  if (!tutorialActive) return '';
  const t = ALL_TABS[tutorialIndex];
  const dots = ALL_TABS.map((x, i) => `<span class="tutorial-dot ${i === tutorialIndex ? 'active' : ''}"></span>`).join('');
  return `
  <div class="tutorial-overlay">
    <div class="tutorial-card">
      <div class="row" style="gap:8px;align-items:center">
        <span class="icon-lg" style="color:var(--primary)">${icon(t.icon)}</span>
        <b style="font-size:16px">${esc(t.label)}</b>
      </div>
      <p class="mt8" style="line-height:1.9">${esc(TAB_TUTORIAL_TEXT[t.id] || '')}</p>
      <div class="tutorial-dots mt12">${dots}</div>
      <div class="row mt12" style="gap:8px">
        <button class="btn secondary block" data-action="tutorial-skip">تخطي الجولة</button>
        <button class="btn block" data-action="tutorial-next">${tutorialIndex === ALL_TABS.length - 1 ? 'إنهاء' : 'التالي'}</button>
      </div>
    </div>
  </div>`;
}

const ALL_TABS = [
  { id: 'home', icon: 'checklist', label: 'مهامي' },
  { id: 'pet', icon: 'bird', label: 'حيواني' },
  { id: 'assistant', icon: 'sparkle', label: 'فاعل الخير' },
  { id: 'stories', icon: 'bookOpenStar', label: 'قصص' },
  { id: 'quiz', icon: 'brain', label: 'اختبار' },
  { id: 'games', icon: 'gift', label: 'ألعاب' },
  { id: 'challenges', icon: 'star', label: 'تحديات' },
  { id: 'rewards', icon: 'coin', label: 'مكافآت' },
  { id: 'achievements', icon: 'crown', label: 'إنجازاتي' },
  { id: 'quran', icon: 'book', label: 'قرآن' },
  { id: 'hadith', icon: 'chat', label: 'أحاديث' },
  { id: 'adhkar', icon: 'beads', label: 'أذكار' },
  { id: 'sunnah', icon: 'sunnah', label: 'سنن الرسول' },
  { id: 'prayerTimes', icon: 'clock', label: 'مواقيت الصلاة' },
  { id: 'calendar', icon: 'calendar', label: 'التقويم الهجري' },
  { id: 'contributors', icon: 'contributors', label: 'المساهمين' },
  { id: 'otherServices', icon: 'otherServices', label: 'مشاريع أخرى' },
  { id: 'inviteFriend', icon: 'inviteFriend', label: 'دعوة صديق' },
  { id: 'diamondVault', icon: 'diamondVault', label: 'خزنة العملات' },
  { id: 'events', icon: 'crown', label: 'الفعاليات' },
  { id: 'asmaHusna', icon: 'asmaHusna', label: 'الأسماء الحسنى' },
  { id: 'kaffara', icon: 'kaffara', label: 'حاسبة الكفارة' },
  { id: 'safeVideos', icon: 'safeVideos', label: 'فيديوهات آمنة' },
  { id: 'halalScanner', icon: 'halalScanner', label: 'رفيق الحلال' },
  { id: 'tree', icon: 'tree', label: 'شجرتي' },
  { id: 'scenarios', icon: 'compass', label: 'مواقف' },
  { id: 'tasbih', icon: 'tasbih', label: 'سبحة' },
  { id: 'shop', icon: 'bag', label: 'متجر' },
  { id: 'prayer', icon: 'mosque', label: 'تعلّم الصلاة' },
  { id: 'subscription', icon: 'crown', label: 'الاشتراك' },
];
// نعرض عدد قليل وثابت من التابات الأساسية أسفل الشاشة (يظهر بالكامل على أي حجم جهاز)
// وباقي التابات تحت زر "المزيد" حتى لا يزدحم الشريط ولا تختفي أيقونات على الشاشات الصغيرة
const PRIMARY_TAB_IDS = ['home', 'stories', 'quiz', 'shop'];
function renderBottomNav() {
  const primary = PRIMARY_TAB_IDS.map(id => ALL_TABS.find(t => t.id === id));
  const moreActive = !PRIMARY_TAB_IDS.includes(currentTab);
  const primaryBtns = primary.map(t => `
    <button class="${currentTab === t.id ? 'active' : ''}" data-action="switch-tab" data-tab="${t.id}">
      <span class="nav-emoji">${tabIcon(t.id)}</span>${tr('tab_' + t.id)}
    </button>`).join('');
  return `<div class="bottom-nav">${primaryBtns}
    <button class="${moreActive ? 'active' : ''}" data-action="open-more-menu">
      <span class="nav-emoji">${tabIcon('more')}</span>${tr('tab_more')}
    </button>
  </div>`;
}

function renderMoreMenu() {
  const secondary = ALL_TABS.filter(t => !PRIMARY_TAB_IDS.includes(t.id));
  const items = secondary.map(t => `
    <button class="more-menu-item ${currentTab === t.id ? 'active' : ''}" data-action="switch-tab-from-more" data-tab="${t.id}">
      <span class="nav-emoji">${tabIcon(t.id)}</span><span>${tr('tab_' + t.id)}</span>
    </button>`).join('');
  const settingsTile = `
    <button class="more-menu-item" data-action="open-profile-from-more">
      <span class="nav-emoji">${icon('person')}</span><span>الإعدادات</span>
    </button>`;
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 style="font-weight:900" class="mb12">${icon('sparkle')} كل الأقسام</h2>
      <div class="more-menu-grid">${items}${settingsTile}</div>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== البروفايل ==============================
// صف إعداد متطور بمفتاح تبديل (Toggle Switch) بدل زرار نص عادي
function renderSettingsRow(iconName, title, desc, action, isOn) {
  return `
  <div class="settings-row" data-action="${action}">
    <div class="settings-row-icon">${icon(iconName)}</div>
    <div class="settings-row-text"><div class="t">${title}</div><div class="s">${desc}</div></div>
    <div class="toggle-switch ${isOn ? 'on' : ''}"><div class="toggle-knob"></div></div>
  </div>`;
}

function renderSettingsGroup(iconName, title, body) {
  return `<section class="set-group"><h2 class="set-group-title">${icon(iconName)} ${title}</h2><div class="set-group-body">${body}</div></section>`;
}

function renderProfileModal() {
  const level = getCurrentLevel(state.totalEarnedPoints);
  const frameId = validFrameId() || (hasAllAccess() ? 'phoenix-frame' : null);
  const frame = frameId ? fierceFrames.find(x => x.id === frameId) : null;
  const avatarStyle = (frame ? `border:${frame.border};box-shadow:${frame.glow};` : '') +
    (state.childPhoto ? `background-image:url('${state.childPhoto}');background-size:cover;background-position:center;` : '');
  const off = hijriOffsetDays();
  const offLabel = off === 0 ? 'بدون تعديل' : (off > 0 ? '+' + off + ' يوم' : off + ' يوم');
  const langs = SUPPORTED_LANGUAGES.filter(l => l.ready).map(l => `
    <button type="button" class="set-lang ${state.language === l.code ? 'active' : ''}" data-action="change-language" data-code="${l.code}">
      <span>${l.name}</span>${state.language === l.code ? `<span class="chk">${icon('check')}</span>` : ''}
    </button>`).join('');
  const soonLangs = SUPPORTED_LANGUAGES.filter(l => !l.ready).map(l => l.name).join('، ');

  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box settings-box" onclick="event.stopPropagation()">
      <div class="settings-top">
        <h2>${icon('person')} الإعدادات</h2>
        <button type="button" class="icon-btn" data-action="close-modal" aria-label="${tr('close')}">${icon('xCircle')}</button>
      </div>

      <div class="set-profile">
        <label class="set-avatar-wrap" title="اضغط لتغيير الصورة">
          <div class="set-avatar" style="${avatarStyle}">${state.childPhoto ? '' : icon(level.icon)}</div>
          <span class="set-avatar-cam">${icon('camera')}</span>
          <input type="file" accept="image/*" style="display:none" onchange="handlePhotoUpload(this)">
        </label>
        <div class="set-profile-fields">
          <input type="text" id="name-input" value="${esc(state.childName)}" placeholder="اسم الطفل" aria-label="اسم الطفل" />
          <input type="number" id="age-input" min="2" max="15" value="${state.childAge || ''}" placeholder="العمر" aria-label="العمر" />
        </div>
      </div>
      <button class="btn block mt8" data-action="save-name">${icon('check')} حفظ البيانات</button>

      <div class="set-stats">
        <div><span>المستوى</span><b>${level.name}</b></div>
        <div><span>الرصيد الحالي</span><b>${icon('coin')} ${state.points}</b></div>
        <div><span>إجمالي النقاط المكتسبة</span><b>${icon('star')} ${state.totalEarnedPoints}</b></div>
        <div><span>الألماس (من حفظ القرآن)</span><b style="color:#4FA3E0">${icon('diamond')} ${state.diamonds || 0}</b></div>
      </div>

      ${renderSettingsGroup('key', 'الحساب', typeof renderAuthAccountCard === 'function' ? renderAuthAccountCard() : '')}

      ${renderSettingsGroup('chat', 'اللغة', `<div class="set-lang-grid">${langs}</div><p class="muted small mt8">تتغير واجهة التطبيق كلها قدر الإمكان، أما القرآن والأحاديث والقصص فتبقى بالعربية</p><p class="muted small mt8">لغات قادمة قريبًا: ${soonLangs}</p>`)}

      ${renderSettingsGroup('sun', 'المظهر', `
        ${renderSettingsRow('moon', 'الوضع الليلي', 'خلفية سوداء بالكامل وإضاءة هادئة', 'toggle-dark', !!state.darkMode)}
        ${renderSettingsRow('pen', 'النص الكبير', 'يكبّر الكتابة في التطبيق لتُقرأ بسهولة', 'toggle-large-text', !!state.largeText)}
        ${renderSettingsRow('compass', 'تكبير الصفحة', 'لتحسين وضوح الكتابة والعناصر', 'toggle-zoom-mode', !!state.zoomMode)}
        ${renderSettingsRow('leaf', 'وضع الهدوء', 'يوقف الحركات والأصوات للتركيز', 'toggle-calm-mode', !!state.calmMode)}
        ${renderSettingsRow('sparkle', 'حركة الأيقونات', 'نبضة خفيفة مستمرة لكل الأيقونات', 'toggle-animated-icons', state.animatedIcons !== false)}
        ${renderSettingsRow('sparkle', 'حركة النصوص', 'لمعان متحرك على العناوين الرئيسية', 'toggle-animated-text', state.animatedText !== false)}`)}

      ${renderSettingsGroup('speaker', 'الصوت والتنبيهات', `
        ${renderSettingsRow('speaker', 'الأصوات', 'أصوات النقر والنجاح والتنبيهات', 'toggle-sound', !!state.soundEnabled)}
        ${renderSettingsRow('lock', 'إشعارات الهاتف', 'تنبيهات المهام والصلاة والتذكيرات', 'toggle-notifications', !!state.notificationsEnabled)}
        ${'vibrate' in navigator ? renderSettingsRow('hands', 'الاهتزاز', 'اهتزاز خفيف عند الضغط على الأزرار', 'toggle-haptic', state.hapticEnabled !== false) : ''}`)}

      ${renderSettingsGroup('calendar', 'التاريخ الهجري', `
        <p class="muted small">اليوم: <b>${weekdayName(new Date().getDay())} ${formatHijri(getTodayHijri())}</b></p>
        <div class="set-stepper mt8">
          <button type="button" class="icon-btn" data-action="hijri-offset" data-d="-1" ${off <= -2 ? 'disabled' : ''} aria-label="يوم أقل">−</button>
          <div><b>${offLabel}</b><small>ضبط يوم الهلال</small></div>
          <button type="button" class="icon-btn" data-action="hijri-offset" data-d="1" ${off >= 2 ? 'disabled' : ''} aria-label="يوم أكثر">+</button>
        </div>
        <p class="muted small mt8">الحساب جدولي وقد يختلف يومًا عن رؤية الهلال في بلدك، عدّله هنا ليطابق الإعلان الرسمي</p>`)}

      ${renderSettingsGroup('shield', 'الوالدان والدعم', `
        <button class="btn secondary block" data-action="open-parent-gate">${icon('lock')} وضع الوالدين</button>
        <button class="btn secondary block mt8" data-action="open-report">${icon('mailEnvelope')} الإبلاغ عن مشكلة</button>`)}

      <div class="credit"><p>صنع بواسطة محمد حمدي</p><p class="small">لا تنسوا الدعاء لصانع الموقع</p></div>
      <button class="btn secondary block" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== الإبلاغ عن مشكلة والتواصل الرسمي ==============================
let reportSubmitted = false;
let lastReportText = '';
const OFFICIAL_INSTAGRAM = 'https://www.instagram.com/horrordeath2/';
const OFFICIAL_X = 'https://x.com/Mohamed26Hamdy';
const OFFICIAL_FACEBOOK = 'https://www.facebook.com/horrordeath2';
const OFFICIAL_YOUTUBE = 'https://www.youtube.com/@HorrorDeath-999';
// رقم واتساب المسؤول: بالصيغة الدولية بدون + وبدون أصفار زيادة (مثال لرقم مصري: 201012345678)
// لو اتساب فاضي، واتساب هيفتح برسالة جاهزة ويسيب المستخدم يختار جهة الاتصال بنفسه
const OFFICIAL_WHATSAPP = '201021515763';

function buildReportWhatsAppLink(desc) {
  const text = 'بلاغ / اقتراح من تطبيق حصالة الحسنات 🌙\n\n' + desc + '\n\n— إصدار التطبيق: ' + APP_VERSION + ' | التاريخ: ' + todayStr();
  const num = String(OFFICIAL_WHATSAPP || '').replace(/\D/g, '');
  return 'https://wa.me/' + num + '?text=' + encodeURIComponent(text);
}

// ============================== شخصية "صديقك السري" ==============================
// شخصية كرتونية ودودة (نجمة مضيئة مبتسمة)، وليست صورة إنسان، مصممة لتكون مريحة ومطمئنة للطفل
function secretFriendMascotSvg(size) {
  const s = size || 120;
  return `
  <svg viewBox="0 0 120 120" width="${s}" height="${s}">
    <defs>
      <radialGradient id="sfGlow" cx="50%" cy="45%" r="60%">
        <stop offset="0%" stop-color="#FFF6D6"/><stop offset="100%" stop-color="#F2C464"/>
      </radialGradient>
      <linearGradient id="sfCheek" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#F3A6A0"/><stop offset="100%" stop-color="#E0817A"/>
      </linearGradient>
    </defs>
    <circle cx="60" cy="60" r="52" fill="#FDF6E3" opacity=".35"/>
    <path d="M60 8 L70 42 L106 42 L76 62 L88 96 L60 76 L32 96 L44 62 L14 42 L50 42 Z" fill="url(#sfGlow)" stroke="#D9A441" stroke-width="1.5" stroke-linejoin="round"/>
    <circle cx="48" cy="58" r="4.4" fill="#3A2A1C"/>
    <circle cx="72" cy="58" r="4.4" fill="#3A2A1C"/>
    <circle cx="46" cy="55.5" r="1.3" fill="#fff"/>
    <circle cx="70" cy="55.5" r="1.3" fill="#fff"/>
    <path d="M50 68q10 9 20 0" stroke="#8B5A2B" stroke-width="2.6" fill="none" stroke-linecap="round"/>
    <ellipse cx="38" cy="66" rx="6" ry="4" fill="url(#sfCheek)" opacity=".7"/>
    <ellipse cx="82" cy="66" rx="6" ry="4" fill="url(#sfCheek)" opacity=".7"/>
    <g class="sf-sparkle-a" style="color:#4A5FA8"><g transform="translate(14,18) scale(0.5)">${ICONS.sparkle}</g></g>
    <g class="sf-sparkle-b" style="color:#3C8055"><g transform="translate(96,20) scale(0.4)">${ICONS.sparkle}</g></g>
    <g class="sf-sparkle-c" style="color:#C1694F"><g transform="translate(18,92) scale(0.4)">${ICONS.sparkle}</g></g>
  </svg>`;
}

let secretMessageSent = false;
function renderSecretFriendModal() {
  if (secretMessageSent) {
    return `
    <div class="modal-overlay" data-action="close-modal-overlay">
      <div class="modal-box center" onclick="event.stopPropagation()">
        <div class="secret-friend-avatar-lg">${secretFriendMascotSvg(110)}</div>
        <h2 style="font-weight:900;margin-top:6px">أحسنت! أنت شجاع</h2>
        <p class="muted mt8">وصلت رسالتك لأمك وأبوك، وهما هيساعدوك ويطمنوك بإذن الله. تذكّر: كل إنسان بيخطئ، والمهم إنك تصارح وتتعلم</p>
        <button class="btn block mt16" data-action="close-modal">تمام</button>
      </div>
    </div>`;
  }
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box center" onclick="event.stopPropagation()">
      <div class="secret-friend-avatar-lg">${secretFriendMascotSvg(110)}</div>
      <h2 style="font-weight:900;margin-top:6px">أنا صديقك السري</h2>
      <p class="muted mt8">لو عملت غلطة، أو عندك مشكلة أو حاجة مضايقاك، احكيلها لي. هوصلها لأمك وأبوك عشان يساعدوك ويطمنوك، مش عشان يزعلوا. كل إنسان بيخطئ ويتعلم، والصراحة بطولة</p>
      <textarea id="secret-friend-text" rows="4" placeholder="اكتب هنا اللي في قلبك..." style="width:100%;margin-top:10px;border-radius:12px;border:1px solid var(--card-border);background:var(--background);color:var(--foreground);padding:10px;font-family:inherit;resize:vertical;text-align:right"></textarea>
      <button class="btn block mt12" data-action="submit-secret-message">${icon('heart')} أرسلها لأمي وأبي</button>
      <button class="btn secondary block mt8" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

function renderReportModal() {
  if (reportSubmitted) {
    return `
    <div class="modal-overlay" data-action="close-modal-overlay">
      <div class="modal-box" onclick="event.stopPropagation()">
        <div class="report-success-icons">
          <span class="pop-1">${icon('star')}</span>
          <span class="pop-2">${icon('heart')}</span>
          <span class="pop-3">${icon('gift')}</span>
          <span class="pop-4">${icon('checkCircle')}</span>
        </div>
        <h2 class="center" style="font-weight:900;margin-top:6px">جزاك الله خيرًا</h2>
        <p class="muted center">لقد ساعدتنا في تحسين التطبيق، ونسأل الله أن يجعل ذلك في ميزان حسناتك</p>
        <p class="muted center small mt8">تم تجهيز رسالتك في واتساب. اضغط "إرسال" هناك لتصل للمسؤول مباشرة</p>
        <a class="btn block mt12" style="background:#25D366;text-decoration:none" href="${buildReportWhatsAppLink(lastReportText)}" target="_blank" rel="noopener">${icon('whatsapp')} لو واتساب ما فتحش، اضغط هنا</a>
        ${renderOfficialContactCard()}
        <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
      </div>
    </div>`;
  }
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <div class="row" style="justify-content:center;gap:8px">
        <span class="icon-lg" style="color:var(--primary)">${icon('mailEnvelope')}</span>
      </div>
      <h2 class="center" style="font-weight:900;margin:8px 0 2px">الإبلاغ عن مشكلة</h2>
      <p class="muted center small">بص يا بطل، اكتب مشكلتك أو اقتراحك بمساعدة أهلك بكل التفاصيل، وبعدها اضغط الزر الأخضر "إرسال للمسؤول"، وهيفتح واتساب برسالتك جاهزة ومكتوبة، وانت بس تدوس إرسال. جزاك الله خيرًا</p>

      <div class="card mt16">
        <label class="muted small" style="display:block;margin-bottom:6px">وصف المشكلة أو الاقتراح</label>
        <textarea id="report-desc" rows="4" maxlength="1000" placeholder="اكتب هنا ما حدث بالتفصيل..." style="width:100%;border-radius:12px;border:1px solid var(--card-border);background:var(--background);color:var(--foreground);padding:10px;font-family:inherit;resize:vertical"></textarea>
        <p class="muted small mt8">لو عايز تبعت صورة للمشكلة، تقدر تضيفها من واتساب بعد ما يفتح</p>
      </div>

      <button class="btn block mt8" style="background:#25D366" data-action="submit-report">${icon('whatsapp')} إرسال للمسؤول</button>

      ${renderOfficialContactCard()}
      ${renderAboutCard()}

      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== جمعيات خيرية ==============================
// ترتيب الأقسام في الواجهة: غزة وفلسطين أولًا، ثم مصر، ثم الجهات الدولية اللي بتغطي عدة دول
const CHARITY_REGION_ORDER = ['غزة وفلسطين', 'مصر', 'دولي'];

function renderCharityCard(c) {
  const methodRows = (c.methods || []).map(m => `
    <div class="row mt8" style="justify-content:space-between;background:var(--muted);border-radius:10px;padding:8px 10px">
      <div>
        <div class="muted small">${esc(m.label)}</div>
        <div style="font-weight:900;letter-spacing:.3px" dir="ltr">${esc(m.value)}</div>
      </div>
      ${m.copyable ? `<button type="button" class="btn secondary" style="padding:6px 12px" data-action="copy-charity-number" data-number="${esc(m.value)}">نسخ</button>` : ''}
    </div>`).join('');
  return `
  <div class="card mt12">
    <b>${icon('hands')} ${esc(c.name)}</b>
    <p class="muted small mt8">${esc(c.desc || '')}</p>
    ${methodRows}
    ${c.source ? `<p class="muted small mt8">المصدر: <a href="${esc(c.source)}" target="_blank" rel="noopener" style="color:var(--primary)">رابط التحقق الرسمي</a></p>` : ''}
  </div>`;
}

function renderCharitiesModal() {
  const all = typeof trustedCharities !== 'undefined' ? trustedCharities : [];
  const regions = CHARITY_REGION_ORDER.filter(r => all.some(c => c.region === r))
    .concat([...new Set(all.map(c => c.region).filter(r => !CHARITY_REGION_ORDER.includes(r)))]);
  const sections = regions.map(r => `
    <h2 class="mt16 mb8" style="font-weight:900;font-size:16px">${r === 'غزة وفلسطين' ? icon('heart') : icon('hands')} ${esc(r)}</h2>
    ${all.filter(c => c.region === r).map(renderCharityCard).join('')}`).join('')
    || '<p class="muted center mt16">لا توجد جمعيات مضافة حاليًا</p>';
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900;margin:8px 0 2px">${icon('hands')} جمعيات خيرية</h2>
      <p class="muted center small">أرقام تحويل موثوقة لجمعيات ومستشفيات ومشاريع خيرية في مصر وغزة وعدة دول، تقدر تحول لها مباشرة من تطبيق البنك أو المحفظة بتاعتك</p>
      ${sections}
      <p class="muted small center mt16">تنويه: التحويل بيتم مباشرة بينك وبين الجهة، والتطبيق مش طرف في العملية ومش بياخد أي بيانات منك هنا. يُفضّل مراجعة رابط التحقق قبل التحويل لأي مبلغ كبير، خصوصًا جهات غزة نظرًا لكثرة محاولات انتحال الصفة في هذا المجال</p>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== التبرع لدعم التطبيق ==============================
function buildDonateWhatsAppLink(d, refNo) {
  const text = '📩 طلب تبرع جديد لدعم تطبيق حصالة الحسنات\n\n' +
    '👤 الاسم: ' + (d.name || '— غير مذكور —') + '\n' +
    '🌍 الدولة: ' + (d.country || '— غير مذكورة —') + '\n' +
    '🎂 السن: ' + (d.age || '— غير مذكور —') + '\n' +
    '💰 المبلغ المراد تحويله: ' + (d.amount || '— غير محدد —') + '\n' +
    '🔖 رقم الطلب: ' + refNo + '\n' +
    '🕒 وقت الإرسال: ' + nowStampAr();
  const num = String(OFFICIAL_WHATSAPP || '').replace(/\D/g, '');
  return 'https://wa.me/' + num + '?text=' + encodeURIComponent(text);
}

function renderDonateFormModal() {
  if (donateFormSent) {
    return `
    <div class="modal-overlay" data-action="close-modal-overlay">
      <div class="modal-box center" onclick="event.stopPropagation()">
        <div class="icon-lg" style="color:var(--gold);margin:0 auto">${icon('heart')}</div>
        <h2 style="font-weight:900;margin-top:6px">جزاك الله خيرًا</h2>
        <p class="muted mt8">تم تجهيز طلب التبرع في واتساب برقم الطلب <b dir="ltr">${esc(lastDonateRefNo)}</b>. اضغط "إرسال" هناك، وسيتواصل معك فريقنا لإتمام التحويل. لاحظ أن الطلب ده رسالة تواصل وليس عملية دفع مكتملة</p>
        <a class="btn block mt12" style="background:#25D366;text-decoration:none" href="${buildDonateWhatsAppLink(state.__lastDonateData || {}, lastDonateRefNo)}" target="_blank" rel="noopener">${icon('whatsapp')} لو واتساب ما فتحش، اضغط هنا</a>
        <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
      </div>
    </div>`;
  }
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900;margin:8px 0 2px">${icon('heart')} تبرع لدعم التطبيق</h2>
      <p class="muted center small">تبرعك يساعدنا نحسّن جودة التطبيق ونطور خدماته باستمرار، ويخلينا نقدر نفضل مستمرين بإذن الله. البيانات كلها اختيارية إلا إنه لازم تكتب اسمك أو دولتك على الأقل</p>
      <div class="card mt16">
        <label class="muted small" style="display:block;margin-bottom:4px">الاسم (اختياري)</label>
        <input id="donate-name" type="text" maxlength="60" placeholder="اكتب اسمك" />
        <label class="muted small mt8" style="display:block;margin-bottom:4px">الدولة (اختياري)</label>
        <input id="donate-country" type="text" maxlength="40" placeholder="اكتب دولتك" />
        <label class="muted small mt8" style="display:block;margin-bottom:4px">السن (اختياري)</label>
        <input id="donate-age" type="number" min="1" max="120" placeholder="سنك" />
        <label class="muted small mt8" style="display:block;margin-bottom:4px">المبلغ المراد تحويله</label>
        <input id="donate-amount" type="text" maxlength="30" placeholder="مثلاً: 100 جنيه" />
        <p id="donate-form-error" class="muted small mt8" style="color:#C1694F"></p>
      </div>
      <button class="btn block mt8" style="background:#25D366" data-action="submit-donate-form">${icon('whatsapp')} تبرع</button>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

// ============================== اشتراك باقة بريميوم ==============================
function buildPremiumWhatsAppLink(d, refNo) {
  const tier = subscriptionTiers.find(t => t.id === selectedSubTierId);
  const text = '📩 طلب اشتراك ' + (tier ? tier.name : 'باقة بريميوم') + ' — تطبيق حصالة الحسنات\n\n' +
    '👤 الاسم: ' + (d.name || '— غير مذكور —') + '\n' +
    '🌍 الدولة: ' + (d.country || '— غير مذكورة —') + '\n' +
    '🎂 السن: ' + (d.age || '— غير مذكور —') + '\n' +
    '💰 المبلغ المراد تحويله: ' + (d.amount || '— غير محدد —') + '\n' +
    '🔖 رقم الطلب: ' + refNo + '\n' +
    '🕒 وقت الإرسال: ' + nowStampAr();
  const num = String(OFFICIAL_WHATSAPP || '').replace(/\D/g, '');
  return 'https://wa.me/' + num + '?text=' + encodeURIComponent(text);
}

function renderPremiumFormModal() {
  const tier = subscriptionTiers.find(t => t.id === selectedSubTierId) || subscriptionTiers[0];
  if (premiumFormSent) {
    return `
    <div class="modal-overlay" data-action="close-modal-overlay">
      <div class="modal-box center" onclick="event.stopPropagation()">
        <div class="icon-lg" style="color:${tier.color};margin:0 auto">${icon('crown')}</div>
        <h2 style="font-weight:900;margin-top:6px">تم إرسال طلبك</h2>
        <p class="muted mt8">تم تجهيز طلب اشتراك ${esc(tier.name)} في واتساب برقم الطلب <b dir="ltr">${esc(lastPremiumRefNo)}</b>. اضغط "إرسال" هناك، وسيتواصل معك فريقنا لإتمام التحويل، ثم يديك كود تفعيل تكتبه في تابة "الاشتراك" لتفعيل الباقة لمدة شهر. لاحظ أن الطلب ده رسالة تواصل وليس اشتراك مفعّل بعد</p>
        <a class="btn block mt12" style="background:#25D366;text-decoration:none" href="${buildPremiumWhatsAppLink(state.__lastPremiumData || {}, lastPremiumRefNo)}" target="_blank" rel="noopener">${icon('whatsapp')} لو واتساب ما فتحش، اضغط هنا</a>
        <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
      </div>
    </div>`;
  }
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900;margin:8px 0 2px">${tier.icon} اشتراك ${esc(tier.name)}</h2>
      <p class="muted center small">تمتّع بميزات حصرية ووصول وتحكم أكبر داخل التطبيق. البيانات كلها اختيارية إلا إنه لازم تكتب اسمك أو دولتك على الأقل</p>
      <div class="card mt16">
        <label class="muted small" style="display:block;margin-bottom:4px">الاسم (اختياري)</label>
        <input id="premium-name" type="text" maxlength="60" placeholder="اكتب اسمك" />
        <label class="muted small mt8" style="display:block;margin-bottom:4px">الدولة (اختياري)</label>
        <input id="premium-country" type="text" maxlength="40" placeholder="اكتب دولتك" />
        <label class="muted small mt8" style="display:block;margin-bottom:4px">السن (اختياري)</label>
        <input id="premium-age" type="number" min="1" max="120" placeholder="سنك" />
        <label class="muted small mt8" style="display:block;margin-bottom:4px">المبلغ المراد تحويله</label>
        <input id="premium-amount" type="text" maxlength="30" placeholder="مثلاً: 100 جنيه" />
        <p id="premium-form-error" class="muted small mt8" style="color:#C1694F"></p>
      </div>
      <button class="btn block mt8" style="background:#25D366" data-action="submit-premium-form">${icon('whatsapp')} اشترك</button>
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}

function renderAboutCard() {
  return `
  <div class="report-contact-card mt16">
    <div class="report-contact-title">${icon('sparkle')} نبذة ومعلومات الصانع</div>
    <p class="muted small mt8" style="line-height:2">
      <b>المطوّر:</b> محمد حمدي أحمد عبد الفتاح<br/>
      <b>الجنسية:</b> مصري<br/>
      <b>فريق التطوير:</b> Horror Death
    </p>
    <p class="muted small mt8">© جميع الحقوق محفوظة لفريق Horror Death</p>
  </div>`;
}

function renderOfficialContactCard() {
  return `
  <div class="report-contact-card mt16">
    <div class="report-contact-title">${icon('mailEnvelope')} جهات التواصل الرسمية</div>
    <div class="report-contact-row">
      <button type="button" class="report-contact-btn" data-action="contact-unavailable" data-name="Instagram" title="Instagram">
        ${icon('instagramGlyph')}<span>Instagram</span>
      </button>
      <a class="report-contact-btn" href="${OFFICIAL_X}" target="_blank" rel="noopener" data-action="tap-contact" title="X">
        ${icon('xGlyph')}<span>X</span>
      </a>
      <button type="button" class="report-contact-btn" data-action="contact-unavailable" data-name="Facebook" title="Facebook">
        ${icon('facebookGlyph')}<span>Facebook</span>
      </button>
    </div>
    <p class="muted small center mt8">كل اقتراح أو بلاغ ترسله قد يكون سببًا في تحسين التطبيق ونشر الخير، فلا تتردد في إرساله للمسؤول</p>
    <a class="report-youtube-btn mt12" href="${OFFICIAL_YOUTUBE}" target="_blank" rel="noopener" data-action="tap-contact">
      ${icon('youtubeGlyph')} <span>تابعنا على يوتيوب</span>
    </a>
  </div>`;
}

// ============================== بوابة PIN الوالدين ==============================
let pinBuffer = '';
let passwordBuffer = '';
let patternBuffer = [];

function renderParentGateModal() {
  const type = state.parentLockType || 'pin';
  if (type === 'password') return renderPasswordLockModal();
  if (type === 'pattern') return renderPatternLockModal();
  return renderPinModal();
}

function renderPinModal() {
  const dots = [0,1,2,3].map(i => `<span class="${i < pinBuffer.length ? 'filled' : ''}"></span>`).join('');
  const keys = [1,2,3,4,5,6,7,8,9,'',0,'DEL'];
  const pad = keys.map(k => k === '' ? '<div></div>' :
    `<button data-action="pin-key" data-k="${k}">${k}</button>`).join('');
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900">${icon('lock')} أدخل الرقم السري للوالدين</h2>
      <p class="muted center">أول مرة ليك/ي؟ اختر أي 4 أرقام الآن وستصبح رقمك السري</p>
      <div class="pin-dots">${dots}</div>
      <div id="pin-error" class="center muted" style="color:var(--danger)"></div>
      <div class="pin-pad mt16">${pad}</div>
      ${state.parentSecurityQ && state.parentPin ? `<button class="btn secondary block mt8" data-action="open-security-recovery">${icon('key')} نسيت الرقم السري؟</button>` : ''}
      <button class="btn secondary block mt16" data-action="close-modal">إلغاء</button>
    </div>
  </div>`;
}

function renderPasswordLockModal() {
  const isFirstTime = !state.parentPassword;
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900">${icon('lock')} كلمة سر الوالدين</h2>
      <p class="muted center">${isFirstTime ? 'أول مرة؟ اكتب كلمة السر اللي عايزها وستصبح كلمة سرك من الآن' : 'اكتب كلمة السر للدخول'}</p>
      <input type="password" id="parent-password-input" placeholder="كلمة السر" class="mt12" />
      <div id="pin-error" class="center muted" style="color:var(--danger)"></div>
      <button class="btn block mt12" data-action="password-submit">${icon('check')} دخول</button>
      ${state.parentSecurityQ && state.parentPassword ? `<button class="btn secondary block mt8" data-action="open-security-recovery">${icon('key')} نسيت كلمة السر؟</button>` : ''}
      <button class="btn secondary block mt8" data-action="close-modal">إلغاء</button>
    </div>
  </div>`;
}

function renderPatternLockModal() {
  const isFirstTime = !state.parentPattern;
  const dots = [0,1,2,3,4,5,6,7,8].map(i => `
    <button class="pattern-dot ${patternBuffer.includes(i) ? 'active' : ''}" data-action="pattern-dot" data-i="${i}">
      ${patternBuffer.includes(i) ? patternBuffer.indexOf(i) + 1 : ''}
    </button>`).join('');
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900">${icon('lock')} نمط الوالدين</h2>
      <p class="muted center">${isFirstTime ? 'أول مرة؟ اضغط على 4 نقاط على الأقل بالترتيب اللي عايزه وسيصبح نمطك' : 'اضغط على النقاط بنفس الترتيب المحفوظ'}</p>
      <div class="pattern-grid mt12">${dots}</div>
      <div id="pin-error" class="center muted" style="color:var(--danger)"></div>
      <button class="btn block mt12" data-action="pattern-submit">${icon('check')} تأكيد</button>
      <button class="btn secondary mt8" data-action="pattern-clear">${icon('xCircle')} مسح</button>
      ${state.parentSecurityQ && state.parentPattern ? `<button class="btn secondary block mt8" data-action="open-security-recovery">${icon('key')} نسيت النمط؟</button>` : ''}
      <button class="btn secondary block mt8" data-action="close-modal">إلغاء</button>
    </div>
  </div>`;
}

// ============================== استرجاع دخول الوالدين عبر سؤال الأمان ==============================
function renderSecurityRecoveryModal() {
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 class="center" style="font-weight:900">${icon('key')} استرجاع دخول الوالدين</h2>
      <p class="muted center mt8">${esc(state.parentSecurityQ)}</p>
      <input type="text" id="security-recovery-answer" placeholder="اكتب الإجابة" class="mt8" />
      <div id="pin-error" class="center muted" style="color:var(--danger)"></div>
      <button class="btn block mt12" data-action="security-recovery-submit">${icon('check')} تأكيد</button>
      <button class="btn secondary block mt8" data-action="close-modal">إلغاء</button>
    </div>
  </div>`;
}

// يبني بطاقة لوحة العائلة: قائمة الأبناء، ترتيبهم حسب النقاط، وأزرار تبديل/تشجيع
function renderFamilySection() {
  const idx = loadFamilyIndex();
  saveCurrentProfileSnapshot(idx); // اضمن أن بيانات الطفل النشط محدّثة دائمًا قبل عرض المقارنة
  const rows = idx.profiles.map(p => {
    const st = (p.id === idx.activeId) ? state : (loadProfileState(p.id) || {});
    return {
      p,
      pts: st.totalEarnedPoints || 0,
      achCount: Object.keys(st.unlockedAchievements || {}).length,
      isActive: p.id === idx.activeId,
    };
  }).sort((a, b) => b.pts - a.pts);

  const listHtml = rows.map((r, i) => `
    <div class="list-item">
      <div class="emoji">${icon(i === 0 ? 'crown' : 'person')}</div>
      <div class="info">
        <div class="t">${esc(r.p.name)}${r.isActive ? ' (النشط الآن)' : ''}</div>
        <div class="s">${icon('star')} ${r.pts} نقطة  •  ${icon('checkCircle')} ${r.achCount} إنجاز</div>
      </div>
      ${r.isActive ? '' : `
      <div class="row" style="gap:4px">
        <button class="btn secondary" style="padding:8px 10px" data-action="switch-profile" data-id="${r.p.id}">تبديل</button>
        <button class="icon-btn" data-action="encourage-profile" data-id="${r.p.id}" title="إرسال تشجيع">${icon('heart')}</button>
        <button class="icon-btn" data-action="delete-profile" data-id="${r.p.id}" title="حذف هذا الحساب">${icon('trash')}</button>
      </div>`}
    </div>`).join('');

  return `
  <div class="card">
    <h2 class="section-title">${icon('person')} لوحة العائلة</h2>
    <p class="muted small mb8">حسابات متعددة للإخوة على نفس الجهاز، مع لوحة ترتيب ومقارنة إنجازات</p>
    ${listHtml}
    <button class="btn secondary block mt12" data-action="add-family-profile">${icon('person')} إضافة طفل جديد</button>
  </div>`;
}

// ============================== لوحة تحكم الوالدين ==============================
function renderParentDashboard() {
  const allTasks = [...defaultTasks, ...state.customTasks];
  const pendingList = allTasks.filter(t => state.tasksPending[t.id] === todayStr() && state.tasksApproved[t.id] !== todayStr());
  const pendingRows = pendingList.map(t => `
    <div class="task-row">
      <div><div class="name">${esc(t.name)}</div><div class="pts">+${t.points} نقطة</div></div>
      <div class="row" style="gap:6px">
        <button class="btn" style="padding:8px 12px" data-action="approve-task" data-id="${t.id}" data-pts="${t.points}">${icon('check')} تأكيد</button>
        <button class="btn secondary" style="padding:8px 12px" data-action="reject-task" data-id="${t.id}">${icon('xCircle')} رفض</button>
      </div>
    </div>`).join('');

  const pendingSurahRows = (state.pendingMemorizedSurahs || []).map(sid => {
    const s = surahs.find(x => x.id === sid);
    return `
    <div class="task-row">
      <div><div class="name">${icon('bookOpenStar')} حفظ سورة ${s ? esc(s.name) : sid}</div></div>
      <div class="row" style="gap:6px">
        <button class="btn" style="padding:8px 12px" data-action="approve-memorized-surah" data-id="${sid}">${icon('check')} تأكيد</button>
        <button class="btn secondary" style="padding:8px 12px" data-action="reject-memorized-surah" data-id="${sid}">${icon('xCircle')} رفض</button>
      </div>
    </div>`;
  }).join('');
  const pendingHadithRows = (state.pendingMemorizedHadiths || []).map(hid => {
    const h = hadiths.find(x => x.id === hid);
    return `
    <div class="task-row">
      <div><div class="name">${icon('chat')} حفظ حديث: ${h ? esc(h.text.slice(0, 40)) + '...' : hid}</div></div>
      <div class="row" style="gap:6px">
        <button class="btn" style="padding:8px 12px" data-action="approve-memorized-hadith" data-id="${hid}">${icon('check')} تأكيد</button>
        <button class="btn secondary" style="padding:8px 12px" data-action="reject-memorized-hadith" data-id="${hid}">${icon('xCircle')} رفض</button>
      </div>
    </div>`;
  }).join('');
  const pendingMemorizationCard = (pendingSurahRows || pendingHadithRows) ? `
    <div class="card mt12">
      <h2 class="section-title">${icon('star')} طلبات تأكيد حفظ</h2>
      ${pendingSurahRows}${pendingHadithRows}
    </div>` : '';

  const weekly = getWeeklyEvent();
  const weeklyPending = weekly && state.weeklyClaimed[weekly.id] === todayStr() && state.weeklyApproved[weekly.id] !== todayStr();
  const weeklyCard = weeklyPending ? `
    <div class="card">
      <h2 class="section-title">${icon(weekly.icon)} ${weekly.name}</h2>
      ${weekly.kind === 'khutba' ? `<p class="mt8">ما كتبه طفلك عن الخطبة:</p><div class="khutba-note" style="background:var(--muted);color:var(--foreground)">${esc(state.khutbaNotes[todayStr()] || '')}</div>` :
        `<p class="mt8">طفلك ذكر أنه صام اليوم (صيام الاثنين والخميس). راجع الأمر ثم أكّد المكافأة.</p>`}
      <div class="row mt12" style="gap:6px">
        <button class="btn" style="padding:8px 12px;flex:1" data-action="approve-weekly" data-id="${weekly.id}" data-pts="${weekly.points}">${icon('check')} تأكيد (+${weekly.points})</button>
        <button class="btn secondary" style="padding:8px 12px;flex:1" data-action="reject-weekly" data-id="${weekly.id}">${icon('xCircle')} رفض</button>
      </div>
    </div>` : '';

  return `
  <div class="container">
    <div class="topbar">
      <h1 class="title" style="margin:0">${icon('key')} لوحة تحكم الوالدين</h1>
      <button class="icon-btn" data-action="back-to-child">${icon('door')}</button>
    </div>
    <div class="card">
      <h2 class="section-title">إحصائيات</h2>
      <div class="row"><span>اسم الطفل</span><b>${esc(state.childName)}</b></div>
      <div class="row mt8"><span>الرصيد الحالي</span><b>${icon('coin')} ${state.points}</b></div>
      <div class="row mt8"><span>إجمالي النقاط</span><b>${icon('star')} ${state.totalEarnedPoints}</b></div>
    </div>

    ${renderFamilySection()}

    <div class="card">
      <h2 class="section-title">${icon('hourglass')} مهام بانتظار تأكيدك (${pendingList.length})</h2>
      ${pendingRows || '<p class="muted">لا توجد مهام بانتظار التأكيد الآن</p>'}
    </div>
    ${pendingMemorizationCard}

    <div class="card" style="border:1px solid var(--primary)">
      <h2 class="section-title">${icon('bookOpenStar')} طلبات حفظ القرآن</h2>
      ${Object.keys(state.ayahMemoryPending || {}).length === 0
        ? `<p class="muted small">لا توجد طلبات حفظ آيات بانتظار تأكيدك حاليًا</p>`
        : Object.entries(state.ayahMemoryPending).map(([sid, target]) => {
            const s = surahs.find(x => x.id === Number(sid));
            return `<div class="task-row">
              <div><div class="name">${s ? s.name : sid}</div><div class="pts">حتى الآية رقم ${target} من ${s ? s.versesCount : '?'}</div></div>
              <button class="btn" style="padding:8px 12px" data-action="approve-ayah-memorized" data-id="${sid}">${icon('check')} تأكيد الحفظ</button>
            </div>`;
          }).join('')}
    </div>

    <div class="card" style="border:1px solid #4A9FD9">
      <h2 class="section-title">${icon('asmaHusna')} طلبات حفظ أسماء الله الحسنى</h2>
      ${!state.namesMemoryPending
        ? `<p class="muted small">لا توجد طلبات حفظ أسماء بانتظار تأكيدك حاليًا</p>`
        : `<div class="task-row">
            <div><div class="name">${asmaAlHusna[state.namesMemoryPending - 1] ? asmaAlHusna[state.namesMemoryPending - 1].name : ''}</div><div class="pts">الاسم رقم ${state.namesMemoryPending} من ${asmaAlHusna.length}</div></div>
            <button class="btn" style="padding:8px 12px" data-action="approve-name-memorized">${icon('check')} تأكيد الحفظ</button>
          </div>`}
    </div>

    <div class="card" style="border:1px solid var(--primary)">
      <h2 class="section-title">${icon('safeVideos')} إدارة الفيديوهات الآمنة</h2>
      <p class="muted small mb8">ألصق رابط يوتيوب أو أي رابط فيديو عادي (mp4 مثلًا)، وهيظهر لابنك في تشغيل معزول بدون اقتراحات ولا تعليقات</p>
      <input type="text" id="new-video-title" placeholder="عنوان الفيديو" class="mb8" />
      <input type="text" id="new-video-url" placeholder="رابط الفيديو (يوتيوب أو أي رابط عادي)" class="mb8" />
      <button class="btn block" data-action="add-safe-video">${icon('safeVideos')} إضافة الفيديو</button>
      ${(state.customVideos || []).length ? `<div class="mt12">${state.customVideos.map(v => `
        <div class="task-row"><span>${esc(v.title)}</span>
        <button class="icon-btn" data-action="delete-safe-video" data-id="${v.id}">${icon('trash')}</button></div>`).join('')}</div>` : ''}
    </div>

    ${weeklyCard}

    <div class="card" style="border:1px solid var(--primary)">
      <h2 class="section-title">${icon('sparkle')} تحدي خاص من عندك</h2>
      <p class="muted small mb8">اعمل تحدي بالاسم اللي انت عايزه (مثلاً: احفظ آية الكرسي، ساعد جدتك) بنقاط تحددها انت</p>
      ${(state.parentChallenges || []).filter(c => c.status === 'pending').map(c => `
        <div class="task-row">
          <div><div class="name">${esc(c.name)}</div><div class="pts">+${c.points} نقطة</div></div>
          <button class="btn" style="padding:8px 12px" data-action="approve-parent-challenge" data-id="${c.id}">${icon('check')} تأكيد الإنجاز</button>
        </div>`).join('')}
      <input type="text" id="new-challenge-name" placeholder="اسم التحدي" class="mb8" />
      <input type="text" id="new-challenge-points" placeholder="كام نقطة؟ مثال: 40" class="mb8" />
      <button class="btn block" data-action="add-parent-challenge">${icon('gift')} إضافة التحدي</button>
    </div>

    <div class="card" style="border:2px solid var(--danger,#C0392B)">
      <h2 class="section-title">${icon('lock')} عقوبات (الغش أو الكذب)</h2>
      <p class="muted small mb8">لو اكتشفت إن ابنك غش أو كدب، تقدر تخصم نقاط و/أو تقفل ميزات معينة لفترة محددة</p>
      <input type="number" id="penalty-points" placeholder="عدد النقاط المخصومة (مثال: 30)" class="mb8" />
      <p class="muted small mb8">اختار الميزات اللي عايز تقفلها:</p>
      <div class="more-menu-grid mb8">
        ${ALL_TABS.filter(t => t.id !== 'home').map(t => `
          <label class="more-menu-item" style="cursor:pointer">
            <input type="checkbox" class="penalty-feature-check" value="${t.id}" style="width:16px;height:16px" />
            <span class="nav-emoji">${tabIcon(t.id)}</span><span>${t.label}</span>
          </label>`).join('')}
      </div>
      <p class="muted small mb8">مدة القفل:</p>
      <select id="penalty-duration" class="mb8">
        <option value="1">ساعة واحدة</option>
        <option value="3">3 ساعات</option>
        <option value="6">6 ساعات</option>
        <option value="12">12 ساعة</option>
        <option value="24" selected>يوم كامل</option>
        <option value="72">3 أيام</option>
        <option value="168">أسبوع كامل</option>
      </select>
      <button class="btn block" style="background:var(--danger,#C0392B)" data-action="apply-penalty">${icon('lock')} تطبيق العقوبة</button>
      ${(state.penaltyLog || []).length ? `<p class="muted small mt12">آخر عقوبة: ${hijriFromKey(state.penaltyLog[state.penaltyLog.length-1].date)}</p>` : ''}
      ${Object.keys(state.lockedFeatures || {}).some(k => isFeatureLocked(k)) ? `
        <div class="mt12">
          <p class="muted small mb8">ميزات مقفولة حاليًا:</p>
          ${Object.keys(state.lockedFeatures).filter(isFeatureLocked).map(id => {
            const t = ALL_TABS.find(x => x.id === id);
            return `<div class="task-row"><div>${t ? t.label : id}</div><button class="btn secondary" style="padding:6px 10px" data-action="unlock-feature" data-id="${id}">${icon('check')} فك القفل الآن</button></div>`;
          }).join('')}
        </div>` : ''}
    </div>

    <div class="card" style="border:1px solid var(--gold)">
      <h2 class="section-title">${icon('sparkle')} رسائل ابنك السرية</h2>
      <p class="mt8" style="font-weight:700">هذه رسائل كتبها طفلك بثقة ليصارحك بأي خطأ أو مشكلة عنده. من المهم جدًا أن تستقبلها بحب وتشجيع بدون غضب أو عقاب، حتى يستمر طفلك في الصدق معك ومشاركتك أسراره دائمًا.</p>
      ${state.secretMessages.length ? `
        <div class="mt12">${[...state.secretMessages].reverse().map((m, i) => `
          <div class="khutba-note" style="background:var(--muted);color:var(--foreground);margin-bottom:8px">
            <div class="muted small">${hijriFromKey(m.date)}</div>
            <div class="mt8">${esc(m.text)}</div>
          </div>`).join('')}</div>
        <button class="btn secondary block mt8" data-action="clear-secret-messages">${icon('trash')} تم الاطلاع، مسح الرسائل</button>
      ` : `<p class="muted mt8">لا توجد رسائل حتى الآن</p>`}
    </div>

    <div class="card">
      <h2 class="section-title">${icon('gift')} إضافة مهمة مخصصة (حدد اسمها وكام عملة تساوي)</h2>
      <input type="text" id="new-task-name" placeholder="اسم المهمة" class="mb8" />
      <input type="text" id="new-task-points" placeholder="كام نقطة (عملة) هتاخد المهمة دي؟ مثال: 20" class="mb8" />
      <button class="btn block" data-action="add-custom-task">إضافة المهمة</button>
      ${state.customTasks.length ? `<div class="mt12">${state.customTasks.map(t => `
        <div class="task-row"><span>${esc(t.name)} (+${t.points})</span>
        <button class="icon-btn" data-action="delete-custom-task" data-id="${t.id}">${icon('trash')}</button></div>`).join('')}</div>` : ''}
    </div>

    <div class="card">
      <h2 class="section-title">${icon('key')} طريقة قفل دخول الوالدين</h2>
      <div class="story-filter-row">
        <button class="story-filter-btn ${(state.parentLockType || 'pin') === 'pin' ? 'active' : ''}" data-action="set-parent-lock-type" data-type="pin">رقم سري</button>
        <button class="story-filter-btn ${state.parentLockType === 'password' ? 'active' : ''}" data-action="set-parent-lock-type" data-type="password">كلمة سر</button>
        <button class="story-filter-btn ${state.parentLockType === 'pattern' ? 'active' : ''}" data-action="set-parent-lock-type" data-type="pattern">نمط</button>
      </div>
      ${(state.parentLockType || 'pin') === 'pin' ? `
        <input type="text" id="new-pin" placeholder="رقم سري جديد (4 أرقام)" maxlength="4" class="mt12 mb8" />
        <button class="btn block" data-action="save-new-pin">حفظ الرقم السري</button>
      ` : state.parentLockType === 'password' ? `
        <input type="password" id="new-password" placeholder="كلمة سر جديدة" class="mt12 mb8" />
        <button class="btn block" data-action="save-new-password">حفظ كلمة السر</button>
      ` : `
        <p class="muted small mt12">لتغيير النمط: سجّل خروج ثم ادخل على وضع الوالدين، وسيُطلب منك نمط جديد تلقائيًا لأنك اخترت هذه الطريقة الآن</p>
      `}
      <p id="pin-save-msg" class="muted center mt8"></p>
    </div>

    <div class="card">
      <h2 class="section-title">${icon('chat')} تقرير تقدّم الطفل</h2>
      <p class="muted small mb8">ملخص بسيط عن تقدّم ${esc(state.childName)} تقدر تبعته لأي حد من العائلة</p>
      <button class="btn block" data-action="share-progress-report">${icon('whatsapp')} مشاركة التقرير</button>
    </div>

    <div class="card">
      <h2 class="section-title">${icon('shield')} نسخة احتياطية</h2>
      <p class="muted small mb8">احفظ تقدّم كل الأطفال (النقاط والإنجازات والحسابات) في ملف، واستعده لو مسحت بيانات المتصفح أو غيّرت الجهاز</p>
      <button class="btn block" data-action="export-backup">${icon('download')} حفظ نسخة احتياطية</button>
      <label class="btn secondary block mt8" style="cursor:pointer;text-align:center">${icon('paperclip')} استعادة من ملف
        <input type="file" accept="application/json,.json" style="display:none" onchange="handleBackupImport(this)" />
      </label>
    </div>

    <div class="card">
      <h2 class="section-title">${icon('clock')} وقت الشاشة والنوم</h2>
      <p class="muted small mb8">اليوم استخدم طفلك التطبيق ${state.screenTimeUsedToday || 0} دقيقة${state.screenLimitMinutes ? ' من ' + (state.screenLimitMinutes + (state.extraTimeGrantedToday || 0)) + ' دقيقة مسموحة' : ''}</p>
      <label class="muted small" style="display:block;margin-bottom:6px">الحد الأقصى للاستخدام يوميًا بالدقائق (اتركه 0 لإلغاء الحد)</label>
      <input type="number" id="screen-limit-input" min="0" max="600" value="${state.screenLimitMinutes || 0}" class="mb8" />
      <button class="btn secondary block mb8" data-action="save-screen-limit">${icon('check')} حفظ الحد اليومي</button>
      ${state.screenLimitMinutes ? `<button class="btn secondary block mb8" data-action="grant-extra-time">${icon('gift')} امنح 15 دقيقة إضافية اليوم</button>` : ''}
      <label class="muted small" style="display:block;margin:12px 0 6px">وقت النوم (يقفل التطبيق تلقائيًا خلاله، اتركهم فاضيين لإلغائه)</label>
      <div class="row" style="gap:8px">
        <input type="time" id="bedtime-start-input" value="${esc(state.bedtimeStart || '')}" style="flex:1" />
        <span class="muted">إلى</span>
        <input type="time" id="bedtime-end-input" value="${esc(state.bedtimeEnd || '')}" style="flex:1" />
      </div>
      <button class="btn secondary block mt8" data-action="save-bedtime">${icon('check')} حفظ وقت النوم</button>
    </div>

    <div class="card">
      <h2 class="section-title">${icon('key')} استرجاع دخول الوالدين</h2>
      <p class="muted small mb8">لو نسيت الرقم السري مستقبلاً، تقدر تسترجع دخولك بسؤال الأمان ده بدل ما تمسح كل البيانات</p>
      <input type="text" id="security-q-input" placeholder="سؤال الأمان (مثال: اسم أول مدرسة التحقت بها؟)" value="${esc(state.parentSecurityQ || '')}" class="mb8" />
      <input type="text" id="security-a-input" placeholder="الإجابة" class="mb8" />
      <button class="btn secondary block" data-action="save-security-question">${icon('check')} حفظ سؤال الأمان</button>
    </div>

    <div class="card">
      <h2 class="section-title">${icon('warning')} إعادة الضبط</h2>
      <button class="btn danger block" data-action="reset-app">مسح كل البيانات وإعادة الضبط</button>
    </div>

    <div class="credit"><p>صنع بواسطة محمد حمدي</p><p class="small">لا تنسوا الدعاء لصانع الموقع</p><p</p></div>
  </div>`;
}

// ============================== المودالات ==============================
// ============================== بطاقة النتيجة المتلألئة (بديل alert للإجابات) ==============================
let resultCard = null; // { kind: 'success'|'error'|'warning'|'info', title, message }
let resultCardTimer = null;
// بطاقة عامة تستبدل alert() في كل التطبيق - نفس شكل بطاقة الإجابات لكن بأنواع رسائل مختلفة
function showMessageCard(kind, title, message) {
  resultCard = { kind, title, message };
  clearTimeout(resultCardTimer);
  resultCardTimer = setTimeout(() => { resultCard = null; render(); }, 4000);
  render();
}
// غلاف متوافق مع الاستخدام القديم لتغذية الاختبارات والألعاب (صح/غلط)
function showResultCard(correct, title, message) {
  showMessageCard(correct ? 'success' : 'error', title, message);
}
const RESULT_CARD_ICONS = { success: 'checkCircle', error: 'xCircle', warning: 'warning', info: 'sparkle' };
function renderResultCard() {
  if (!resultCard) return '';
  const kind = resultCard.kind || 'info';
  return `
  <div class="result-card-overlay" data-action="close-result-card">
    <div class="result-card ${kind}" onclick="event.stopPropagation()">
      <div class="result-card-shine"></div>
      <div class="result-card-icon">${icon(RESULT_CARD_ICONS[kind] || 'sparkle')}</div>
      <div class="result-card-title">${esc(resultCard.title)}</div>
      <p class="result-card-message">${esc(resultCard.message)}</p>
    </div>
  </div>`;
}

function renderModals() {
  const overlay = document.getElementById('modal-root');
  overlay.innerHTML = modalStack.map(m => {
    if (m.type === 'story') return renderStoryReader(m.id);
    if (m.type === 'surah') return renderSurahDetail(m.id);
    if (m.type === 'adhkar-cat') return renderAdhkarCategory(m.id);
    if (m.type === 'prayer') return renderPrayerDetail(m.id);
    if (m.type === 'profile') return renderProfileModal();
    if (m.type === 'report') return renderReportModal();
    if (m.type === 'secret-friend') return renderSecretFriendModal();
    if (m.type === 'qibla') return renderQiblaModal();
    if (m.type === 'apk-download') return renderApkModal();
    if (m.type === 'regional-notice') return renderRegionalNoticeModal();
    if (m.type === 'security-recovery') return renderSecurityRecoveryModal();
    if (m.type === 'coupon-redeem') return renderCouponRedeemModal();
    if (m.type === 'coupon-scratch') return renderCouponScratchModal();
    if (m.type === 'more-menu') return renderMoreMenu();
    if (m.type === 'certificate') return renderCertificateModal(m.id);
    if (m.type === 'pin') return renderParentGateModal();
    if (m.type === 'safe-video') return renderSafeVideoPlayerModal(m.id);
    if (m.type === 'charities') return renderCharitiesModal();
    if (m.type === 'donate-form') return renderDonateFormModal();
    if (m.type === 'premium-form') return renderPremiumFormModal();
    if (m.type === 'reciter-picker') return renderReciterPickerModal();
    return '';
  }).join('') + renderResultCard();
}

function renderReciterPickerModal() {
  const q = (reciterSearchQuery || '').trim();
  const list = quranReciters.filter(r => !q || r.name.includes(q));
  const items = list.map(r => `
    <div class="list-item" data-action="select-reciter" data-id="${r.id}">
      <div class="emoji">${icon('speaker')}</div>
      <div class="info"><div class="t">${esc(r.name)}</div></div>
      ${state.selectedReciter === r.id ? `<span class="badge">${icon('check')}</span>` : ''}
    </div>`).join('');
  return `
  <div class="modal-overlay" data-action="close-modal-overlay">
    <div class="modal-box" onclick="event.stopPropagation()">
      <h2 style="text-align:center;font-weight:900">${icon('speaker')} اختر صوت الشيخ</h2>
      <input type="text" id="reciter-search" value="${esc(q)}" placeholder="ابحث عن اسم الشيخ..." class="mb12" oninput="handleReciterSearch(this.value)" />
      ${items || '<p class="muted center">لا يوجد شيخ بهذا الاسم</p>'}
      <button class="btn secondary block mt16" data-action="close-modal">${tr("close")}</button>
    </div>
  </div>`;
}
let reciterSearchQuery = '';
function handleReciterSearch(v) { reciterSearchQuery = v; renderModals(); }


function openModal(type, id) { modalStack.push({ type, id }); render(); }
function closeModal() {
  if (typeof stopPrayerPlayer === 'function') stopPrayerPlayer();
  const closed = modalStack.pop();
  const shouldStartTutorial = closed && closed.type === 'regional-notice' && !state.tutorialShown;
  render();
  if (shouldStartTutorial) {
    state.tutorialShown = true; saveState();
    startTutorial();
  }
}

// ============================== الأحداث ==============================
function bindEvents() {
  document.querySelectorAll('[data-action]').forEach(el => {
    el.addEventListener('click', handleAction);
  });
  initScratchCard();
}

// يمنح جائزة الكوبون فور اكتمال الخربشة (أو عند الضغط على "اكشفها لي")، ويقفل الكوبون حتى لا يُستخدم مرتين
function revealCouponReward() {
  const m = modalStack[modalStack.length - 1];
  if (!m || m.type !== 'coupon-scratch') return;
  const coupon = m.coupon;
  state.redeemedCoupons = state.redeemedCoupons || [];
  if (state.redeemedCoupons.includes(coupon.code)) return;
  const r = coupon.reward;
  const labelParts = [];
  if (r.type === 'diamonds') {
    // الشكل القديم لكوبونات الأسبوع (نوع واحد فقط)
    state.diamonds = (state.diamonds || 0) + r.amount;
    labelParts.push(r.amount + ' ألماسة 💎');
  } else if (r.type === 'points') {
    addPoints(r.amount);
    labelParts.push(r.amount + ' نقطة ذهبية 🪙');
  } else {
    // الشكل الجديد (كوبون استثنائي/متجر): يدعم أكتر من عملة ومكافأة في نفس الكوبون
    if (r.diamonds) { state.diamonds = (state.diamonds || 0) + r.diamonds; labelParts.push(r.diamonds + ' ألماسة 💎'); }
    if (r.gold) { state.gold = (state.gold || 0) + r.gold; labelParts.push(r.gold + ' ذهب 🟡'); }
    if (r.silver) { state.silver = (state.silver || 0) + r.silver; labelParts.push(r.silver + ' فضة ⚪'); }
    if (r.points) { addPoints(r.points); labelParts.push(r.points + ' نقطة ذهبية 🪙'); }
    if (r.frame) {
      state.ownedFierceFrames = state.ownedFierceFrames || [];
      if (!state.ownedFierceFrames.includes(r.frame)) state.ownedFierceFrames.push(r.frame);
      state.currentProfileFrame = r.frame;
      const f = (typeof fierceFrames !== 'undefined' ? fierceFrames.find(x => x.id === r.frame) : null);
      labelParts.push('إطار ' + (f ? f.name : r.frame) + ' 🔥');
    }
    if (r.nameGlow) {
      state.ownedNameGlows = state.ownedNameGlows || [];
      if (!state.ownedNameGlows.includes(r.nameGlow)) state.ownedNameGlows.push(r.nameGlow);
      state.currentNameGlow = r.nameGlow;
      labelParts.push('اسم متوهج أحمر ✨');
    }
  }
  state.redeemedCoupons.push(coupon.code);
  saveState(); celebrate(); playAchievementSound();
  modalStack.pop();
  render();
  showMessageCard('success', 'مبروك الكوبون! 🎉', 'حصلت على ' + labelParts.join(' + '));
}

// كارت الخربشة: نرسم طبقة فضية فوق الجائزة، والمستخدم بيمسحها بإصبعه زي كارت الكوبونات الحقيقي
function initScratchCard() {
  const canvas = document.getElementById('scratch-canvas');
  if (!canvas || canvas.dataset.inited) return;
  canvas.dataset.inited = '1';
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, '#D8D8D8'); grad.addColorStop(1, '#8A8A8A');
  ctx.fillStyle = grad; ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = 'rgba(255,255,255,.9)';
  ctx.font = 'bold 15px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('اخربش هنا 👆', w / 2, h / 2 - 10);
  ctx.font = '13px sans-serif';
  ctx.fillText('لتكشف جائزتك', w / 2, h / 2 + 14);

  let scratching = false, revealed = false, moveCount = 0;
  function posFromEvent(e) {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches && e.touches[0];
    const cx = (t ? t.clientX : e.clientX) - rect.left;
    const cy = (t ? t.clientY : e.clientY) - rect.top;
    return { x: cx * (w / rect.width), y: cy * (h / rect.height) };
  }
  function scratchAt(x, y) {
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath(); ctx.arc(x, y, 20, 0, Math.PI * 2); ctx.fill();
  }
  function checkProgress() {
    if (revealed) return;
    const data = ctx.getImageData(0, 0, w, h).data;
    let clearCount = 0, sampleCount = 0;
    for (let i = 3; i < data.length; i += 4 * 12) { sampleCount++; if (data[i] < 40) clearCount++; }
    if (clearCount / sampleCount > 0.45) {
      revealed = true;
      canvas.style.transition = 'opacity .4s ease';
      canvas.style.opacity = '0';
      setTimeout(() => { if (typeof revealCouponReward === 'function') revealCouponReward(); }, 380);
    }
  }
  function start(e) { scratching = true; const p = posFromEvent(e); scratchAt(p.x, p.y); if (e.cancelable) e.preventDefault(); }
  function move(e) {
    if (!scratching) return;
    const p = posFromEvent(e); scratchAt(p.x, p.y);
    moveCount++; if (moveCount % 3 === 0) checkProgress();
    if (e.cancelable) e.preventDefault();
  }
  function end() { scratching = false; checkProgress(); }
  canvas.addEventListener('mousedown', start);
  canvas.addEventListener('mousemove', move);
  window.addEventListener('mouseup', end);
  canvas.addEventListener('touchstart', start, { passive: false });
  canvas.addEventListener('touchmove', move, { passive: false });
  canvas.addEventListener('touchend', end);
}

// يربط الأحداث فقط داخل عنصر معيّن تم تحديثه ديناميكيًا (مثل صفحات القرآن) دون إعادة ربط بقية التطبيق
function bindContainer(container) {
  container.querySelectorAll('[data-action]').forEach(el => {
    el.addEventListener('click', handleAction);
  });
}

async function handleAction(e) {
  const el = e.currentTarget;
  const action = el.dataset.action;
  // فحص أمني: نشاط نقر غير بشري (بوت) بيتحظر مؤقتًا؛ الأزرار اللي بتقفل موديل أو تتنقل بسيطة معفية عشان منمنعش استخدام عادي
  if (action !== 'close-modal' && action !== 'close-modal-overlay') {
    if (isSecurityLocked()) { render(); return; }
    if (checkBotLikeActivity()) { render(); return; }
  }
  playClickSound();
  sparkleAt(e.clientX || (el.getBoundingClientRect().left + el.getBoundingClientRect().width / 2),
            e.clientY || (el.getBoundingClientRect().top + el.getBoundingClientRect().height / 2));

  switch (action) {
    case 'claim-daily-challenge': {
      if (state.dailyChallengeClaimed === todayStr() || (state.tasksApprovedToday || 0) < 3) break;
      addPoints(30); state.dailyChallengeClaimed = todayStr(); saveState();
      playAchievementSound(); celebrate(); checkAndUnlockAchievements();
      showMessageCard('success', 'أحسنت! 🌟', 'أكملت تحدي اليوم +30 نقطة');
      render(); break;
    }

    case 'claim-weekly-challenge': {
      const wk = getWeekKey();
      if (state.weeklyChallengeClaimed === wk || (state.loginStreak || 0) < 3) break;
      addPoints(60); state.weeklyChallengeClaimed = wk; saveState();
      playAchievementSound(); celebrate(); checkAndUnlockAchievements();
      showMessageCard('success', 'رائع! 🌟', 'أكملت تحدي الأسبوع +60 نقطة');
      render(); break;
    }

    case 'open-daily-gift': {
      if (state.lastDailyGiftDate === todayStr()) break;
      const prize = 10 + Math.floor(Math.random() * 21);
      addPoints(prize);
      state.lastDailyGiftDate = todayStr(); saveState();
      playPurchaseSound(); celebrate(); checkAndUnlockAchievements();
      showMessageCard('success', 'هدية اليوم! 🎁', 'هديتك اليومية: ' + prize + ' نقطة! عُد غدًا لهدية جديدة');
      render(); break;
    }

    case 'spin-wheel': {
      const weekKey = getWeekKey();
      if (wheelSpinning || state.lastWheelWeek === weekKey) break;
      wheelSpinning = true;
      const n = wheelPrizes.length, seg = 360 / n;
      const chosen = Math.floor(Math.random() * n);
      const targetAngle = 5 * 360 + (360 - (chosen * seg + seg / 2));
      const wheelEl = document.getElementById('luck-wheel');
      if (wheelEl) wheelEl.style.transform = `rotate(${targetAngle}deg)`;
      playTickSound();
      setTimeout(() => {
        const prize = wheelPrizes[chosen];
        addPoints(prize);
        state.lastWheelWeek = weekKey; saveState();
        playAchievementSound(); celebrate(); checkAndUnlockAchievements();
        showMessageCard('success', 'مبروك! 🎡', 'ربحت ' + prize + ' نقطة من عجلة الحظ');
        wheelSpinning = false;
        render();
      }, 3100);
      break;
    }

    case 'open-monthly-gift': {
      const mk = getMonthKey();
      if (state.lastMonthlyGift === mk) break;
      const prize = 150;
      addPoints(prize);
      state.lastMonthlyGift = mk; saveState();
      playAchievementSound(); celebrate(); checkAndUnlockAchievements();
      showMessageCard('success', 'هدية الشهر! 🎁', 'هدية الشهر: ' + prize + ' نقطة! بارك الله في مواظبتك');
      render(); break;
    }

    case 'clear-secret-messages':
      state.secretMessages = []; saveState(); render(); break;

    case 'ask-assistant': {
      const inp = document.getElementById('assistant-input');
      const text = (inp?.value || '').trim();
      if (!text) break;
      assistantChat.push({ role: 'user', kind: 'text', text });
      if (inp) inp.value = '';
      playTickSound();
      render();
      await pushAssistantReply(text);
      break;
    }

    case 'ask-suggested': {
      const text = el.dataset.q;
      assistantChat.push({ role: 'user', kind: 'text', text });
      playTickSound();
      render();
      await pushAssistantReply(text);
      break;
    }

    case 'assistant-attach-image':
      document.getElementById('assistant-image-input')?.click(); break;

    case 'assistant-toggle-record': {
      if (assistantMediaRecorder) {
        assistantMediaRecorder.stop();
        assistantMediaRecorder = null;
        render();
        break;
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showMessageCard('error', 'غير مدعوم', 'متصفحك لا يدعم تسجيل الصوت');
        break;
      }
      navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
        const chunks = [];
        const rec = new MediaRecorder(stream);
        rec.ondataavailable = e => chunks.push(e.data);
        rec.onstop = () => {
          const blob = new Blob(chunks, { type: 'audio/webm' });
          const src = URL.createObjectURL(blob);
          assistantChat.push({ role: 'user', kind: 'audio', src });
          assistantChat.push({ role: 'assistant', kind: 'text', text: 'سمعت رسالتك الصوتية 🎙️ جزاك الله خيرًا! اكتب سؤالك بالحروف كمان لو حابب إجابة أكيدة.' });
          stream.getTracks().forEach(t => t.stop());
          render();
        };
        rec.start();
        assistantMediaRecorder = rec;
        render();
      }).catch(() => showMessageCard('error', 'تعذّر الوصول', 'لم نتمكن من الوصول للميكروفون'));
      break;
    }

    case 'toggle-dark':
      state.darkMode = !state.darkMode; saveState(); render(); break;

    case 'toggle-notifications':
      if (state.notificationsEnabled) { state.notificationsEnabled = false; saveState(); render(); }
      else { requestNotificationPermission(); }
      break;

    case 'toggle-sound':
      state.soundEnabled = !state.soundEnabled; saveState();
      if (state.soundEnabled) playOpenSound();
      render(); break;

    case 'toggle-animated-icons':
      state.animatedIcons = state.animatedIcons === false ? true : false; saveState(); render(); break;

    case 'toggle-animated-text':
      state.animatedText = state.animatedText === false ? true : false; saveState(); render(); break;

    case 'toggle-zoom-mode':
      state.zoomMode = !state.zoomMode; saveState(); render(); break;

    case 'toggle-haptic':
      state.hapticEnabled = state.hapticEnabled === false; saveState(); render(); break;

    case 'open-profile':
      openModal('profile'); break;

    case 'open-certificate':
      openModal('certificate', el.dataset.id); break;

    case 'open-qibla':
      openQiblaModal(); break;

    case 'dismiss-adhan-banner':
      adhanBannerPrayer = null; render(); break;

    case 'open-secret-friend':
      secretMessageSent = false; openModal('secret-friend'); break;

    case 'submit-secret-message': {
      const text = (document.getElementById('secret-friend-text')?.value || '').trim();
      if (!text) { showMessageCard('warning', 'اكتب رسالتك', 'اكتب أولاً اللي في قلبك'); break; }
      state.secretMessages.push({ text, date: todayStr() });
      saveState();
      secretMessageSent = true;
      playTickSound(); celebrate();
      render(); break;
    }

    case 'open-report':
      reportSubmitted = false; openModal('report'); break;

    case 'download-apk': {
      const btn = document.getElementById('apk-download-btn');
      const statusEl = document.getElementById('apk-download-status');
      if (btn) { btn.disabled = true; btn.textContent = 'جاري التحميل...'; }
      fetch(APK_DOWNLOAD.url)
        .then(r => { if (!r.ok) throw new Error('bad status'); return r.blob(); })
        .then(rawBlob => {
          // نعيد بناء الملف بنوع APK الصريح، عشان لا يتحفظ بامتداد .zip حتى لو السيرفر بعت نوع غلط
          const apkBlob = new Blob([rawBlob], { type: 'application/vnd.android.package-archive' });
          const objUrl = URL.createObjectURL(apkBlob);
          const a = document.createElement('a');
          a.href = objUrl; a.download = APK_DOWNLOAD.fileName;
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(() => URL.revokeObjectURL(objUrl), 8000);
          if (statusEl) statusEl.textContent = 'بدأ التحميل بنجاح ✓';
        })
        .catch(() => {
          if (statusEl) statusEl.textContent = 'تعذّر التحميل التلقائي، جرّب الرابط المباشر بالأسفل';
          const w = window.open(APK_DOWNLOAD.url, '_blank');
          if (!w) showMessageCard('warning', 'تعذّر التحميل', 'تأكد من اتصالك بالإنترنت وحاول مرة أخرى');
        })
        .finally(() => { if (btn) { btn.disabled = false; btn.textContent = 'تحميل مرة أخرى'; } });
      break;
    }

    case 'open-apk-download':
      playOpenSound(); openModal('apk-download'); break;

    case 'submit-report': {
      const desc = (document.getElementById('report-desc')?.value || '').trim();
      if (!desc) { showMessageCard('warning', 'اكتب الوصف', 'يرجى كتابة وصف بسيط للمشكلة أو الاقتراح أولاً'); break; }
      lastReportText = desc;
      reportSubmitted = true;
      // نفتح واتساب برسالة جاهزة على رقم المسؤول (لازم يتم في نفس لحظة الضغطة عشان المتصفح ما يمنعه)
      window.open(buildReportWhatsAppLink(desc), '_blank', 'noopener');
      playSuccessSound(); celebrate();
      render(); break;
    }

    case 'dismiss-premium-ad':
      premiumAdDismissed = true; render(); break;

    case 'open-premium-form':
      selectedSubTierId = el.dataset.tier || selectedSubTierId;
      premiumFormSent = false; openModal('premium-form'); break;

    case 'open-charities':
      openModal('charities'); break;

    case 'copy-charity-number': {
      const num = el.dataset.number || '';
      if (navigator.clipboard) {
        navigator.clipboard.writeText(num).then(() => {
          el.textContent = 'تم النسخ ✓';
          setTimeout(() => { el.textContent = 'نسخ'; }, 1500);
        }).catch(() => showMessageCard('info', 'انسخ الرقم يدويًا', num));
      } else {
        showMessageCard('info', 'انسخ الرقم يدويًا', num);
      }
      break;
    }

    case 'submit-donate-form': {
      const name = (document.getElementById('donate-name')?.value || '').trim();
      const country = (document.getElementById('donate-country')?.value || '').trim();
      const age = (document.getElementById('donate-age')?.value || '').trim();
      const amount = (document.getElementById('donate-amount')?.value || '').trim();
      const err = document.getElementById('donate-form-error');
      if (!name && !country) {
        if (err) err.textContent = 'اكتب اسمك أو دولتك على الأقل من فضلك';
        break;
      }
      const refNo = generateRefNo('DON');
      lastDonateRefNo = refNo;
      state.__lastDonateData = { name, country, age, amount };
      donateFormSent = true;
      window.open(buildDonateWhatsAppLink(state.__lastDonateData, refNo), '_blank', 'noopener');
      playSuccessSound(); celebrate();
      render(); break;
    }

    case 'submit-premium-form': {
      const name = (document.getElementById('premium-name')?.value || '').trim();
      const country = (document.getElementById('premium-country')?.value || '').trim();
      const age = (document.getElementById('premium-age')?.value || '').trim();
      const amount = (document.getElementById('premium-amount')?.value || '').trim();
      const err = document.getElementById('premium-form-error');
      if (!name && !country) {
        if (err) err.textContent = 'اكتب اسمك أو دولتك على الأقل من فضلك';
        break;
      }
      const refNo = generateRefNo('PRM');
      lastPremiumRefNo = refNo;
      state.__lastPremiumData = { name, country, age, amount };
      premiumFormSent = true;
      window.open(buildPremiumWhatsAppLink(state.__lastPremiumData, refNo), '_blank', 'noopener');
      playSuccessSound(); celebrate();
      render(); break;
    }

    case 'contact-unavailable':
      showMessageCard('info', 'غير متاح حاليًا', 'حساب ' + (el.dataset.name || '') + ' غير متاح حاليًا. تقدر تبعت للمسؤول من خلال زر "إرسال للمسؤول" في خانة الشكوى والاقتراح');
      break;

    case 'close-modal':
      closeModal(); break;

    case 'close-modal-overlay':
      if (e.target === el) closeModal();
      break;

    case 'switch-tab':
      currentTab = el.dataset.tab;
      if (currentTab === 'quiz') quizIndex = null;
      if (currentTab === 'games') gameIndex = null;
      render(); break;

    case 'pick-language':
      if (typeof pickLanguage === 'function') pickLanguage(el.dataset.code);
      break;

    case 'change-language': {
      const code = el.dataset.code;
      const meta = SUPPORTED_LANGUAGES.find(l => l.code === code);
      if (!meta || !meta.ready) break;
      state.language = code; saveState();
      if (typeof applyLanguageDirection === 'function') applyLanguageDirection();
      render(); break;
    }

    case 'prayer-player-toggle': {
      const p = prayerLessons.find(x => x.id === prayerPlayer.forId);
      const steps = p ? buildPrayerSteps(p.rakahs) : [];
      if (prayerPlayer.playing) {
        stopPrayerPlayer();
      } else {
        prayerPlayer.playing = true;
        prayerPlayer.timer = setInterval(() => {
          prayerPlayer.index = (prayerPlayer.index + 1) % Math.max(1, steps.length);
          render();
        }, 2500);
      }
      render(); break;
    }

    case 'prayer-player-next': {
      const p = prayerLessons.find(x => x.id === prayerPlayer.forId);
      const steps = p ? buildPrayerSteps(p.rakahs) : [];
      prayerPlayer.index = (prayerPlayer.index + 1) % Math.max(1, steps.length);
      render(); break;
    }

    case 'prayer-player-prev': {
      const p = prayerLessons.find(x => x.id === prayerPlayer.forId);
      const steps = p ? buildPrayerSteps(p.rakahs) : [];
      prayerPlayer.index = (prayerPlayer.index - 1 + steps.length) % Math.max(1, steps.length);
      render(); break;
    }

    case 'open-more-menu':
      openModal('more-menu'); break;

    case 'close-result-card':
      resultCard = null; clearTimeout(resultCardTimer); render(); break;

    case 'native-share': {
      const text = getShareText();
      const url = (typeof location !== 'undefined' && location.href) ? location.href.split('#')[0] : '';
      if (navigator.share) {
        navigator.share({ title: 'حصالة الحسنات', text, url }).catch(() => {});
      } else {
        showMessageCard('info', 'المشاركة غير مدعومة', 'استخدم أحد الأزرار التانية أو انسخ الرابط');
      }
      break;
    }

    case 'copy-share-link': {
      const url = (typeof location !== 'undefined' && location.href) ? location.href.split('#')[0] : '';
      if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
          showMessageCard('success', 'تم النسخ! 📋', 'الرابط جاهز، الصقه في أي مكان تحب');
        }).catch(() => showMessageCard('error', 'تعذّر النسخ', 'جرّب تاني أو انسخ الرابط يدويًا'));
      }
      break;
    }

    case 'print-certificate': {
      const box = document.querySelector('.certificate-frame-wrap');
      if (!box) break;
      const w = window.open('', '_blank');
      if (!w) { showMessageCard('warning', 'تعذّر فتح نافذة الطباعة', 'اسمح للنوافذ المنبثقة من إعدادات المتصفح'); break; }
      w.document.write('<html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>شهادة تقدير</title><base href="' + document.baseURI + '"><style>' + Array.from(document.styleSheets).map(sheet => { try { return Array.from(sheet.cssRules).map(r => r.cssText).join(''); } catch (e) { return ''; } }).join('') + 'body{display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}</style></head><body>' + box.outerHTML + '</body></html>');
      w.document.close();
      setTimeout(() => { w.focus(); w.print(); }, 300);
      break;
    }

    case 'share-achievement': {
      const a = achievementsList.find(x => x.id === el.dataset.id);
      const text = 'فتحت إنجاز "' + (a ? a.title : '') + '" في تطبيق حصالة الحسنات 🏆';
      const certBox = document.querySelector('.certificate-frame-wrap');
      if (a && a.certifiable && certBox && typeof html2canvas === 'function') {
        html2canvas(certBox, { backgroundColor: null, scale: 2, useCORS: true }).then(canvas => {
          canvas.toBlob(blob => {
            if (!blob) return;
            const file = new File([blob], 'شهادة-تقدير.png', { type: 'image/png' });
            if (navigator.canShare && navigator.canShare({ files: [file] })) {
              navigator.share({ title: 'شهادة تقدير 🏆', text, files: [file] }).catch(() => {});
            } else {
              // مفيش دعم لمشاركة صور، ننزّل الصورة بدل كده
              const link = document.createElement('a');
              link.href = URL.createObjectURL(blob);
              link.download = 'شهادة-تقدير.png';
              link.click();
            }
          }, 'image/png');
        }).catch(() => {
          if (navigator.share) navigator.share({ title: 'إنجاز جديد!', text }).catch(() => {});
        });
        break;
      }
      if (navigator.share) {
        navigator.share({ title: 'إنجاز جديد!', text }).catch(() => {});
      } else {
        const waLink = 'https://wa.me/?text=' + encodeURIComponent(text);
        window.open(waLink, '_blank');
      }
      break;
    }

    case 'buy-event': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if ((state.diamonds || 0) < cost) {
        showMessageCard('warning', 'ألماس غير كافٍ', 'احفظ آيات أكتر من القرآن عشان تجمع ألماس كفاية لفتح الفعالية دي');
        break;
      }
      state.diamonds -= cost;
      state.ownedEvents = state.ownedEvents || [];
      if (!state.ownedEvents.includes(id)) state.ownedEvents.push(id);
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'مبروك! 👑', 'فتحت فعالية حصرية جديدة، دوس "ابدأ الفعالية" عشان تلعبها');
      render(); break;
    }

    case 'start-event': {
      const ev = EVENTS_LIST.find(e => e.id === el.dataset.id);
      if (!ev) break;
      if (ev.kind === 'scramble') {
        const words = shuffle(getEventPool(ev.id)).slice(0, 10);
        eventScrambleSession = { eventId: ev.id, words, index: 0, correct: 0, buffer: [] };
      } else {
        const pool = shuffle(getEventPool(ev.id)).slice(0, 10);
        eventSession = { eventId: ev.id, pool, index: 0, correct: 0 };
      }
      playOpenSound(); render(); break;
    }

    case 'quit-event-session':
      eventSession = null; eventScrambleSession = null;
      window.__eventScrambleOrder = null;
      render(); break;

    case 'answer-event-mcq': {
      const q = eventSession.pool[eventSession.index];
      const i = Number(el.dataset.i);
      if (i === q.answer) {
        eventSession.correct++; addPoints(q.points || 15); playSuccessSound(); hapticTap(12);
      } else {
        hapticTap(20);
      }
      eventSession.index++;
      if (eventSession.index >= eventSession.pool.length) finishEventSession(); else render();
      break;
    }

    case 'event-scramble-pick':
      eventScrambleSession.buffer.push(Number(el.dataset.i));
      playClickSound(); render(); break;

    case 'event-scramble-clear':
      eventScrambleSession.buffer = []; render(); break;

    case 'event-scramble-submit': {
      const g = eventScrambleSession.words[eventScrambleSession.index];
      const built = eventScrambleSession.buffer.map(i => g.word[i]).join('');
      if (built === g.word && eventScrambleSession.buffer.length === g.word.length) {
        eventScrambleSession.correct++; addPoints(g.points || 20); playSuccessSound();
      }
      eventScrambleSession.index++; eventScrambleSession.buffer = [];
      window.__eventScrambleOrder = null;
      if (eventScrambleSession.index >= eventScrambleSession.words.length) finishEventScrambleSession(); else render();
      break;
    }

    case 'buy-with-diamonds': {
      const key = el.dataset.key, cost = Number(el.dataset.cost);
      if ((state.diamonds || 0) < cost) {
        showMessageCard('warning', 'ألماس غير كافٍ', 'احفظ آيات أكتر من القرآن عشان تجمع ألماس كفاية');
        break;
      }
      state.diamonds -= cost;
      if (key === 'badge') { state.diamondBadgeOwned = true; }
      else if (key === 'certFrame') {
        const f = certificateFrames.find(x => x.diamondOnly);
        if (f && !state.certFramesOwned.includes(f.id)) { state.certFramesOwned.push(f.id); state.currentCertFrame = f.id; }
      } else if (key === 'potSkin') {
        const p = treePotSkins.find(x => x.diamondOnly);
        if (p && !state.potSkinsOwned.includes(p.id)) { state.potSkinsOwned.push(p.id); state.currentPotSkin = p.id; }
      }
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'مبروك! 💎', 'فتحت ميزة حصرية جديدة بالألماس');
      render(); break;
    }

    case 'select-profile-frame':
      state.currentProfileFrame = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'select-name-glow':
      state.currentNameGlow = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-rare-item': {
      const key = el.dataset.key, cost = Number(el.dataset.cost), currency = el.dataset.currency;
      const currencyName = { gold: 'ذهب', silver: 'فضة', diamonds: 'ماس' }[currency] || currency;
      if ((state[currency] || 0) < cost) {
        showMessageCard('warning', currencyName + ' غير كافٍ', 'محتاج ' + cost + ' ' + currencyName + '، وده عملة نادرة تُجمع من فعاليات خاصة أو شحن حقيقي فقط');
        break;
      }
      const [kind, id] = String(key).split(':');
      state[currency] -= cost;
      if (kind === 'frame') {
        state.ownedFierceFrames = state.ownedFierceFrames || [];
        if (!state.ownedFierceFrames.includes(id)) state.ownedFierceFrames.push(id);
        state.currentProfileFrame = id;
      } else if (kind === 'glow') {
        state.ownedNameGlows = state.ownedNameGlows || [];
        if (!state.ownedNameGlows.includes(id)) state.ownedNameGlows.push(id);
        state.currentNameGlow = id;
      }
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'مبروك! 🔥', 'فتحت ميزة احتراقية فاخرة جديدة');
      render(); break;
    }

    case 'buy-supporter-badge': {
      if ((state.gold || 0) >= supporterBadge.goldCost) {
        state.gold -= supporterBadge.goldCost;
      } else if ((state.silver || 0) >= supporterBadge.silverCost) {
        state.silver -= supporterBadge.silverCost;
      } else {
        showMessageCard('warning', 'رصيد غير كافٍ', 'محتاج ' + supporterBadge.goldCost + ' ذهب أو ' + supporterBadge.silverCost + ' فضة عشان تفتح شارة داعم مميز');
        break;
      }
      state.supporterBadgeOwned = true;
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'مبروك! 🔥', 'فتحت شارة "داعم مميز" — لقب وشكل تجميلي مميز بجانب اسمك');
      render(); break;
    }

    case 'buy-subscription-gold': {
      const tierId = el.dataset.tier, cost = Number(el.dataset.cost);
      const tier = subscriptionTiers.find(t => t.id === tierId);
      if (!tier) break;
      if ((state.gold || 0) < cost) {
        showMessageCard('warning', 'ذهب غير كافٍ', 'محتاج ' + cost + ' ذهب عشان تفتح ' + tier.name);
        break;
      }
      state.gold -= cost;
      const expires = new Date(Date.now() + tier.durationDays * 86400000);
      state.activeSubscription = { tierId: tier.id, startDate: todayStr(), expiresDate: expires.toISOString().slice(0, 10) };
      state.lastDailyBonusDate = null; // يقدر يستلم هدية اليوم فورًا من أول يوم تفعيل
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'مبروك! 👑', 'اتفعّلت ' + tier.name + ' لمدة ' + tier.durationDays + ' يوم');
      render(); break;
    }

    case 'activate-subscription-code': {
      const tierId = el.dataset.tier;
      const tier = subscriptionTiers.find(t => t.id === tierId);
      const input = document.getElementById('sub-code-' + tierId);
      const errBox = document.getElementById('sub-code-err-' + tierId);
      const code = String(input?.value || '').trim().toUpperCase();
      if (errBox) errBox.textContent = '';
      if (!tier || !code) break;
      const hash = await hashPin(code);
      state.usedActivationCodeHashes = state.usedActivationCodeHashes || [];
      const validHashes = (subscriptionActivationCodeHashes[tierId] || []);
      if (state.usedActivationCodeHashes.includes(hash)) {
        triggerCodeLock();
        modalStack = [];
        render();
        break;
      }
      if (!validHashes.includes(hash)) {
        if (errBox) errBox.textContent = 'الكود مش صحيح، تأكد منه مع صاحب التطبيق';
        break;
      }
      state.usedActivationCodeHashes.push(hash);
      const expires = new Date(Date.now() + tier.durationDays * 86400000);
      state.activeSubscription = { tierId: tier.id, startDate: todayStr(), expiresDate: expires.toISOString().slice(0, 10) };
      state.lastDailyBonusDate = null; // يقدر يستلم هدية اليوم فورًا من أول يوم تفعيل
      saveState(); celebrate(); playAchievementSound();
      if (input) input.value = '';
      showMessageCard('success', 'مبروك! 🎉', 'اتفعّلت ' + tier.name + ' لمدة ' + tier.durationDays + ' يوم');
      render(); break;
    }

    case 'toggle-large-text':
      state.largeText = !state.largeText; saveState(); render(); break;

    case 'toggle-calm-mode':
      if (!state.calmMode) { state.calmPrevSound = state.soundEnabled; state.soundEnabled = false; state.calmMode = true; }
      else { state.calmMode = false; state.soundEnabled = state.calmPrevSound !== false; }
      saveState(); render(); break;

    case 'hijri-prev':
    case 'hijri-next': {
      if (!hijriView) { const t = getTodayHijri(); hijriView = { year: t.year, month: t.month }; }
      const dir = action === 'hijri-next' ? 1 : -1;
      let m = hijriView.month + dir, y = hijriView.year;
      if (m > 12) { m = 1; y++; } else if (m < 1) { m = 12; y--; }
      hijriView = { year: y, month: m }; hijriSelDay = 1;
      render(); break;
    }
    case 'hijri-today':
      hijriView = null; hijriSelDay = null; render(); break;
    case 'hijri-select':
      hijriSelDay = Number(el.dataset.day) || 1; render(); break;
    case 'cal-toggle-fast': {
      const key = el.dataset.key;
      state.fastingDays = state.fastingDays || [];
      const i = state.fastingDays.indexOf(key);
      if (i >= 0) state.fastingDays.splice(i, 1); else state.fastingDays.push(key);
      saveState(); render(); break;
    }
    case 'hijri-offset': {
      const d = Number(el.dataset.d) || 0;
      state.hijriOffset = Math.max(-2, Math.min(2, (Number(state.hijriOffset) || 0) + d));
      hijriView = null; hijriSelDay = null;
      saveState(); render(); break;
    }

    case 'mark-fast-today': {
      state.fastingDays = state.fastingDays || [];
      if (!state.fastingDays.includes(todayStr())) state.fastingDays.push(todayStr());
      saveState(); render(); break;
    }

    case 'save-gratitude': {
      const inp = document.getElementById('gratitude-input');
      const txt = String((inp && inp.value) || '').replace(/<[^>]*>/g, '').trim().slice(0, 100);
      if (txt.length < 2) break;
      state.gratitudeEntries = state.gratitudeEntries || [];
      state.gratitudeEntries.push({ date: todayStr(), text: txt });
      if (state.gratitudeEntries.length > 60) state.gratitudeEntries.shift();
      saveState(); render(); break;
    }

    case 'delete-gratitude': {
      const d = el.dataset.date, t = el.dataset.text;
      const idx = (state.gratitudeEntries || []).findIndex(g => g.date === d && g.text === t);
      if (idx >= 0) state.gratitudeEntries.splice(idx, 1);
      saveState(); render(); break;
    }

    case 'claim-weekly-chest': {
      if (!hasTierAtLeast('diamond-plan')) break;
      const last = state.lastWeeklyChestDate ? new Date(state.lastWeeklyChestDate).getTime() : 0;
      if (Date.now() - last < 7 * 86400000) break;
      const legendary = hasTierAtLeast('legendary-plan');
      const pts = legendary ? 1500 : 600, dia = legendary ? 100 : 40, gld = legendary ? 40 : 15, slv = legendary ? 25 : 10;
      addPoints(pts);
      state.diamonds = (state.diamonds || 0) + dia;
      state.gold = (state.gold || 0) + gld;
      state.silver = (state.silver || 0) + slv;
      state.lastWeeklyChestDate = todayStr();
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'صندوق الأسبوع! 🎁', 'استلمت ' + pts + ' نقطة + ' + dia + ' ألماس + ' + gld + ' ذهب + ' + slv + ' فضة');
      render(); break;
    }

    case 'claim-daily-sub-bonus': {
      const tier = getActiveSubscriptionTier();
      if (!tier || state.lastDailyBonusDate === todayStr()) break;
      const p = tier.perks || {};
      state.diamonds = (state.diamonds || 0) + (p.dailyDiamonds || 0);
      state.gold = (state.gold || 0) + (p.dailyGold || 0);
      state.silver = (state.silver || 0) + (p.dailySilver || 0);
      state.lastDailyBonusDate = todayStr();
      saveState(); celebrate(); playAchievementSound();
      showMessageCard('success', 'هدية اليوم! 🎁', 'استلمت هدية ' + tier.name + ' اليومية');
      render(); break;
    }

    case 'open-profile-from-more':
      modalStack = [];
      openModal('profile'); break;

    case 'auth-google-signin':
      if (typeof googleSignIn === 'function') googleSignIn();
      break;

    case 'auth-gate-tab':
      if (typeof switchAuthGateTab === 'function') switchAuthGateTab(el.dataset.tab);
      break;

    case 'auth-local-login':
      if (typeof localFakeLogin === 'function') localFakeLogin();
      break;

    case 'auth-local-register':
      if (typeof localFakeRegister === 'function') localFakeRegister();
      break;

    case 'auth-continue-guest':
      if (typeof dismissAuthGate === 'function') dismissAuthGate();
      break;

    case 'auth-sign-out':
      if (typeof googleSignOut === 'function') googleSignOut();
      break;


    case 'tasbih-tap': {
      if (!state.tasbihCounts) state.tasbihCounts = {};
      const id = state.currentTasbihId || 'subhanallah';
      const t = tasbihPhrases.find(x => x.id === id);
      const before = state.tasbihCounts[id] || 0;
      state.tasbihCounts[id] = before + 1;
      const completedCycle = !state.tasbihFreeMode && t && (before + 1) % t.target === 0;
      const freeMilestone = state.tasbihFreeMode && (before + 1) % 100 === 0;
      if (completedCycle || freeMilestone) {
        addPoints(2);
        if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
        state.hasanahTree.dhikr = (state.hasanahTree.dhikr || 0) + 1;
        celebrate(); playAchievementSound();
        sendPhoneNotification('ما شاء الله! 📿', 'أكملت دورة تسبيح ' + t.text);
      } else {
        playTickSound();
      }
      saveState(); render(); break;
    }

    case 'toggle-tasbih-free-mode':
      state.tasbihFreeMode = !state.tasbihFreeMode; saveState(); render(); break;

    case 'tasbih-select':
      state.currentTasbihId = el.dataset.id; saveState(); render(); break;

    case 'tasbih-reset':
      if (!state.tasbihCounts) state.tasbihCounts = {};
      state.tasbihCounts[el.dataset.id] = 0; saveState(); render(); break;


    case 'switch-tab-from-more':
      currentTab = el.dataset.tab;
      if (currentTab === 'quiz') quizIndex = null;
      if (currentTab === 'games') gameIndex = null;
      closeModal(); break;

    case 'request-task': {
      const id = el.dataset.id;
      const allTasks = [...defaultTasks, ...state.customTasks];
      const taskObj = allTasks.find(x => x.id === id);
      state.tasksPending[id] = todayStr();
      saveState(); celebrate();
      sendPhoneNotification('مهمة في انتظار تأكيدك ⏳', (taskObj ? taskObj.name : 'مهمة') + ' بانتظار تأكيد الوالدين');
      render(); break;
    }

    case 'claim-event': {
      const id = el.dataset.id, pts = Number(el.dataset.pts);
      state.eventClaimed[id] = todayStr();
      addPoints(pts); celebrate(); playSuccessSound();
      render(); break;
    }

    case 'filter-stories':
      storyCategoryFilter = el.dataset.cat; render(); break;

    case 'open-story': {
      playOpenSound();
      const s = stories.find(x => x.id === el.dataset.id);
      const owned = s && (state.storiesOwned.includes(s.id) || hasAllAccess());
      if (!owned) break; // القصة مقفولة، لازم تُشترى أولًا (زر buy-story)
      if (!state.storiesReadIds.includes(s.id)) {
        state.storiesReadIds.push(s.id); saveState(); checkAndUnlockAchievements();
      }
      openModal('story', el.dataset.id); break;
    }

    case 'buy-story': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) {
        state.storiesOwned.push(id); saveState(); playPurchaseSound(); celebrate();
        if (!state.storiesReadIds.includes(id)) { state.storiesReadIds.push(id); checkAndUnlockAchievements(); }
        saveState();
        openModal('story', id);
      } else {
        showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد، استمر في إنجاز المهام لتجمع المزيد');
      }
      render(); break;
    }

    case 'story-decision': {
      storyDecisionChoice[el.dataset.story] = el.dataset.choice;
      if (el.dataset.choice === 'A') { addPoints(3); saveState(); }
      playClickSound(); render(); break;
    }

    case 'toggle-pet-roaming':
      state.petRoamingEnabled = !state.petRoamingEnabled; saveState(); render(); break;

    case 'pet-speak': {
      const line = petVoiceLines[Math.floor(Math.random() * petVoiceLines.length)];
      speakArabic(line, { pitch: 1.3 });
      showPetBubble(line);
      break;
    }

    case 'narrate-toggle': {
      const box = document.getElementById('narrator-controls');
      const text = decodeURIComponent(box.dataset.text);
      if (!('speechSynthesis' in window)) { showMessageCard('info', 'قريبًا', 'هذه الميزة تُضاف لاحقًا، يرجى الصبر وجزاكم الله خيرًا'); break; }
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = 'ar-SA'; utter.rate = 0.92;
      const voices = window.speechSynthesis.getVoices();
      const arVoice = voices.find(v => v.lang && v.lang.toLowerCase().startsWith('ar'));
      if (arVoice) utter.voice = arVoice;
      window.speechSynthesis.speak(utter);
      box.querySelector('[data-action="narrate-toggle"]').style.display = 'none';
      box.querySelector('[data-action="narrate-stop"]').style.display = 'inline-flex';
      break;
    }
    case 'narrate-stop': {
      window.speechSynthesis.cancel();
      const box = document.getElementById('narrator-controls');
      box.querySelector('[data-action="narrate-toggle"]').style.display = 'inline-flex';
      box.querySelector('[data-action="narrate-stop"]').style.display = 'none';
      break;
    }

    case 'add-parent-challenge': {
      const nameEl = document.getElementById('new-challenge-name');
      const name = nameEl.value.trim().slice(0, 40);
      const ptsRaw = Number(document.getElementById('new-challenge-points').value);
      const pts = Number.isFinite(ptsRaw) && ptsRaw > 0 ? Math.min(Math.round(ptsRaw), 1000) : null;
      if (!name) { showMessageCard('warning', 'اكتب اسم التحدي', 'أدخل اسم التحدي أولاً'); break; }
      if (!pts) { showMessageCard('warning', 'عدد نقاط غير صحيح', 'اكتب رقمًا صحيحًا أكبر من صفر (بحد أقصى 1000)'); break; }
      if (!state.parentChallenges) state.parentChallenges = [];
      state.parentChallenges.push({ id: 'pc_' + Date.now(), name, points: pts, status: 'active' });
      saveState();
      nameEl.value = ''; document.getElementById('new-challenge-points').value = '';
      sendPhoneNotification('تحدي جديد! ⭐', name + ' - ' + pts + ' نقطة بانتظارك');
      showMessageCard('success', 'تمت الإضافة', 'التحدي الجديد ظاهر الآن عند طفلك');
      render(); break;
    }

    case 'complete-parent-challenge': {
      const c = (state.parentChallenges || []).find(x => x.id === el.dataset.id);
      if (c) { c.status = 'pending'; saveState(); playClickSound(); sendPhoneNotification('تحدي في انتظار تأكيدك ⏳', c.name + ' بانتظار تأكيد الوالدين'); }
      render(); break;
    }

    case 'approve-parent-challenge': {
      const c = (state.parentChallenges || []).find(x => x.id === el.dataset.id);
      if (c) {
        c.status = 'done';
        if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
        state.hasanahTree.kindness = (state.hasanahTree.kindness || 0) + 1;
        addPoints(c.points); saveState(); celebrate(); playAchievementSound(); checkAndUnlockAchievements();
        sendPhoneNotification('أحسنت! 🎉', 'تم تأكيد تحدي "' + c.name + '" +' + c.points + ' نقطة');
      }
      render(); break;
    }

    case 'apply-penalty': {
      const pts = Number(document.getElementById('penalty-points').value) || 0;
      const hours = Number(document.getElementById('penalty-duration').value) || 24;
      const checks = Array.from(document.querySelectorAll('.penalty-feature-check:checked')).map(c => c.value);
      if (pts <= 0 && checks.length === 0) { showMessageCard('warning', 'اختر أولاً', 'اختار نقاط تخصمها أو ميزة تقفلها على الأقل'); break; }
      if (pts > 0) { state.points = Math.max(0, state.points - pts); saveState(); }
      if (!state.lockedFeatures) state.lockedFeatures = {};
      const until = Date.now() + hours * 3600000;
      checks.forEach(id => { state.lockedFeatures[id] = until; });
      if (!state.penaltyLog) state.penaltyLog = [];
      state.penaltyLog.push({ date: todayStr(), points: pts, features: checks, hours });
      if (checks.includes(currentTab)) currentTab = 'home';
      saveState();
      sendPhoneNotification('تنبيه من والديك ⚠️', 'تم تطبيق عقوبة' + (pts > 0 ? ' - خصم ' + pts + ' نقطة' : '') + (checks.length ? ' وقفل ميزات' : ''));
      showMessageCard('warning', 'تم تطبيق العقوبة', (pts > 0 ? 'خصم ' + pts + ' نقطة' : '') + (checks.length ? ' وقفل ' + checks.length + ' ميزة' : ''));
      render(); break;
    }

    case 'unlock-feature': {
      if (state.lockedFeatures) delete state.lockedFeatures[el.dataset.id];
      saveState(); render(); break;
    }

    case 'add-dedication': {
      const name = document.getElementById('dedication-name').value.trim();
      const dua = document.getElementById('dedication-dua').value.trim();
      if (!name || !dua) { showMessageCard('warning', 'أكمل البيانات', 'اكتب اسم الشخص والدعاء الأول'); break; }
      if (!state.dedications) state.dedications = [];
      state.dedications.push({ name, dua, date: todayStr() });
      if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
      state.hasanahTree.kindness = (state.hasanahTree.kindness || 0) + 1;
      saveState(); celebrate(); playSuccessSound();
      sendPhoneNotification('حسنة مُهداة 🤍', 'أهديت حسنة لـ' + name);
      showMessageCard('success', 'تقبل الله منك! 🤍', 'تم إهداء الحسنة لـ' + name);
      render(); break;
    }

    case 'answer-scenario': {
      const s = situationScenarios[scenarioIndex];
      const i = Number(el.dataset.i);
      const correct = i === s.answer;
      if (correct) { addPoints(5); saveState(); celebrate(); playSuccessSound(); }
      showResultCard(correct, correct ? 'إجابة صحيحة! 🌟' : 'فكّر تاني في المرة الجاية 🙂', s.explain);
      lastScenarioIndex = scenarioIndex; scenarioIndex = null; render(); break;
    }

    case 'answer-quiz': {
      const q = quizQuestions[quizIndex];
      const i = Number(el.dataset.i);
      if (i === q.answer) {
        addPoints(q.points); state.quizCorrectCount = (state.quizCorrectCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'إجابة صحيحة! 🌟', '+' + q.points + ' نقطة');
      }
      else { showResultCard(false, 'إجابة خاطئة', 'الإجابة الصحيحة: ' + q.options[q.answer]); }
      lastQuizIndex = quizIndex; quizIndex = null; render(); break;
    }

    case 'switch-game':
      gameType = el.dataset.game; gameIndex = null;
      scrambleWordIndex = null; scrambleBuffer = [];
      render(); break;

    case 'answer-ayah-game': {
      const g = ayahGames[gameIndex];
      const picked = el.dataset.picked;
      if (picked === g.blank) {
        addPoints(g.points); state.gamesWonCount = (state.gamesWonCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'أحسنت! 🌟', '+' + g.points + ' نقطة');
      } else {
        showResultCard(false, 'حاول مرة أخرى', 'الكلمة الصحيحة: ' + g.blank);
      }
      lastAyahIndex = gameIndex; gameIndex = null; render(); break;
    }

    case 'answer-sahaba-game': {
      const g = sahabaGames[gameIndex];
      const i = Number(el.dataset.i);
      if (i === g.answer) {
        addPoints(g.points); state.gamesWonCount = (state.gamesWonCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'أحسنت! 🌟', '+' + g.points + ' نقطة');
      } else {
        showResultCard(false, 'إجابة خاطئة', 'الصحيح: ' + g.options[g.answer]);
      }
      lastSahabaIndex = gameIndex; gameIndex = null; render(); break;
    }

    case 'answer-truefalse-game': {
      const g = trueFalseGames[gameIndex];
      const picked = el.dataset.picked === 'true';
      if (picked === g.answer) {
        addPoints(g.points); state.gamesWonCount = (state.gamesWonCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'أحسنت! 🌟', g.explanation);
      } else {
        showResultCard(false, 'إجابة خاطئة', g.explanation);
      }
      lastTrueFalseIndex = gameIndex; gameIndex = null; render(); break;
    }

    case 'answer-asma-game': {
      const picked = el.dataset.picked, answer = el.dataset.answer;
      if (picked === answer) {
        addPoints(15); state.gamesWonCount = (state.gamesWonCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'أحسنت! 🌟', '+15 نقطة');
      } else {
        showResultCard(false, 'إجابة خاطئة', 'الصحيح: ' + answer);
      }
      lastAsmaIndex = gameIndex; gameIndex = null; render(); break;
    }

    case 'answer-revelation-game': {
      const picked = el.dataset.picked, answer = el.dataset.answer;
      if (picked === answer) {
        addPoints(10); state.gamesWonCount = (state.gamesWonCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'أحسنت! 🌟', '+10 نقطة');
      } else {
        showResultCard(false, 'إجابة خاطئة', 'الصحيح: ' + answer);
      }
      lastRevelationIndex = gameIndex; gameIndex = null; render(); break;
    }

    case 'scramble-pick':
      scrambleBuffer.push(Number(el.dataset.i));
      playClickSound(); render(); break;

    case 'scramble-clear':
      scrambleBuffer = []; render(); break;

    case 'scramble-submit': {
      const g = wordScrambleGames[scrambleWordIndex];
      const built = scrambleBuffer.map(i => g.word[i]).join('');
      if (built === g.word && scrambleBuffer.length === g.word.length) {
        addPoints(g.points); state.gamesWonCount = (state.gamesWonCount || 0) + 1; saveState();
        celebrate(); playSuccessSound(); checkAndUnlockAchievements();
        showResultCard(true, 'أحسنت! 🌟', '+' + g.points + ' نقطة');
      } else {
        showResultCard(false, 'مش الترتيب الصحيح', 'الكلمة الصحيحة: ' + g.word);
      }
      scrambleWordIndex = null; scrambleBuffer = []; window.__scrambleOrder = null; render(); break;
    }

    case 'open-surah':
      playOpenSound();
      openModal('surah', el.dataset.id);
      setTimeout(() => loadSurahText(el.dataset.id), 0);
      break;

    case 'play-surah-audio': {
      const player = document.getElementById('surah-audio-player');
      if (player) {
        player.src = el.dataset.url;
        player.style.display = 'block';
        player.play().catch(() => {});
      }
      break;
    }

    case 'trigger-halal-scan': {
      const input = document.getElementById('halal-scan-input');
      if (input) input.click();
      break;
    }

    case 'trigger-barcode-scan':
      startBarcodeScan(); break;

    case 'cancel-barcode-scan':
      stopBarcodeScan(); break;

    case 'play-safe-video':
      openModal('safe-video', el.dataset.id); break;

    case 'add-safe-video': {
      const title = (document.getElementById('new-video-title') || {}).value || '';
      const url = (document.getElementById('new-video-url') || {}).value || '';
      const classified = classifyVideoUrl(url);
      if (!title.trim() || !classified) { showMessageCard('warning', 'تحقق من البيانات', 'اكتب عنوان صحيح ورابط فيديو صالح (يوتيوب أو أي رابط فيديو عادي)'); break; }
      if (!state.customVideos) state.customVideos = [];
      state.customVideos.push({ id: 'vid_' + Date.now(), type: classified.type, ref: classified.ref, title: title.trim() });
      saveState();
      showMessageCard('success', 'تمت الإضافة! 🎬', 'الفيديو بقى متاح لابنك دلوقتي');
      render(); break;
    }

    case 'delete-safe-video': {
      state.customVideos = (state.customVideos || []).filter(v => v.id !== el.dataset.id);
      saveState(); render(); break;
    }

    case 'add-kaffara-plan': {
      const label = (document.getElementById('kaffara-label') || {}).value || '';
      const days = Number((document.getElementById('kaffara-days') || {}).value);
      if (!days || days < 1) { showMessageCard('warning', 'أدخل عدد الأيام', 'اكتب عدد أيام الصيام اللي عايز تحددها'); break; }
      if (!state.kaffaraPlans) state.kaffaraPlans = [];
      state.kaffaraPlans.push({ id: 'kf_' + Date.now(), label: label.trim(), totalDays: days, doneDates: [], startDate: todayStr(), active: true });
      saveState(); celebrate();
      showMessageCard('success', 'بدأت الخطة! 🌙', 'وفّقك الله لإتمام الكفارة، هنذكّرك كل يوم');
      render(); break;
    }

    case 'mark-kaffara-day': {
      const p = (state.kaffaraPlans || []).find(x => x.id === el.dataset.id);
      if (!p) break;
      const today = todayStr();
      if (!p.doneDates.includes(today)) p.doneDates.push(today);
      saveState(); celebrate(); playSuccessSound();
      if (p.doneDates.length >= p.totalDays) {
        showMessageCard('success', 'الحمد لله! 🎉', 'أتممت خطة الكفارة كاملة، تقبل الله منك');
      } else {
        showMessageCard('success', 'بارك الله فيك', 'تم تسجيل صيام اليوم، باقي ' + (p.totalDays - p.doneDates.length) + ' يوم');
      }
      render(); break;
    }

    case 'delete-kaffara-plan': {
      state.kaffaraPlans = (state.kaffaraPlans || []).filter(x => x.id !== el.dataset.id);
      saveState(); render(); break;
    }

    case 'request-name-memorized': {
      const cur = state.namesMemoryProgress || 0;
      state.namesMemoryPending = cur + 1;
      saveState(); playOpenSound();
      sendPhoneNotification('حفظ اسم في انتظار تأكيدك ⏳', 'بانتظار تأكيد حفظ الاسم رقم ' + (cur + 1) + ' من أسماء الله الحسنى');
      render(); break;
    }

    case 'approve-name-memorized': {
      const target = state.namesMemoryPending;
      if (!target) break;
      state.namesMemoryProgress = target;
      state.namesMemoryPending = 0;
      state.diamonds = (state.diamonds || 0) + 1;
      if (target % 10 === 0) state.diamonds += 5;
      if (target >= asmaAlHusna.length) state.diamonds += 15;
      if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
      state.hasanahTree.dhikr = (state.hasanahTree.dhikr || 0) + 1;
      saveState(); celebrate(); playAchievementSound(); checkAndUnlockAchievements();
      sendPhoneNotification('أحسنت! 💎', 'تم تأكيد حفظ اسم جديد من أسماء الله الحسنى');
      render(); break;
    }

    case 'request-ayah-memorized': {
      const sid = Number(el.dataset.id);
      const cur = (state.ayahMemoryProgress && state.ayahMemoryProgress[sid]) || 0;
      if (!state.ayahMemoryPending) state.ayahMemoryPending = {};
      const sInfo = surahs.find(x => x.id === sid);
      const slider = document.getElementById('ayah-slider-' + sid);
      let chosen = slider ? Number(slider.value) : cur + 1;
      if (!Number.isFinite(chosen)) chosen = cur + 1;
      chosen = Math.max(cur + 1, Math.min(sInfo ? sInfo.versesCount : chosen, Math.round(chosen)));
      state.ayahMemoryPending[sid] = chosen;
      saveState(); playOpenSound();
      sendPhoneNotification('حفظ آيات في انتظار تأكيدك ⏳', 'بانتظار تأكيد حفظ حتى الآية رقم ' + chosen);
      render(); break;
    }

    case 'approve-ayah-memorized': {
      const sid = Number(el.dataset.id);
      const target = state.ayahMemoryPending && state.ayahMemoryPending[sid];
      if (!target) break;
      if (!state.ayahMemoryProgress) state.ayahMemoryProgress = {};
      const prev = state.ayahMemoryProgress[sid] || 0;
      const delta = Math.max(1, target - prev); // عدد الآيات الجديدة اللي اتحفظت مرة واحدة (الشريط ممكن يقفز أكتر من آية)
      const fives = Math.max(0, Math.floor(target / 5) - Math.floor(prev / 5));
      state.ayahMemoryProgress[sid] = target;
      delete state.ayahMemoryPending[sid];
      if (hasTierAtLeast('gold-plan')) state.diamonds = (state.diamonds || 0) + 2 * delta; // مكافأة الباقة الذهبية فأعلى
      addPoints(5 * delta + 30 * fives);
      state.diamonds = (state.diamonds || 0) + delta + 3 * fives;
      if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
      state.hasanahTree.quran = (state.hasanahTree.quran || 0) + delta;
      const s = surahs.find(x => x.id === sid);
      if (s && target >= s.versesCount && !state.memorizedSurahs.includes(sid)) {
        state.memorizedSurahs.push(sid);
        addPoints(100); state.diamonds += 10; // جائزة إتمام السورة كاملة
      }
      saveState(); celebrate(); playAchievementSound(); checkAndUnlockAchievements();
      sendPhoneNotification('أحسنت! 🌟', 'تم تأكيد حفظ ' + delta + ' آية من ' + (s ? s.name : 'السورة'));
      render(); break;
    }

    case 'open-reciter-picker':
      reciterSearchQuery = '';
      openModal('reciter-picker'); break;

    case 'select-reciter':
      state.selectedReciter = el.dataset.id; saveState();
      modalStack.pop(); render(); break;

    case 'toggle-memorized': {
      const sid = Number(el.dataset.id);
      state.pendingMemorizedSurahs = state.pendingMemorizedSurahs || [];
      if (state.memorizedSurahs.includes(sid)) {
        // إلغاء حفظ مؤكَّد سلفًا، مايحتاجش تأكيد والدين
        state.memorizedSurahs.splice(state.memorizedSurahs.indexOf(sid), 1);
      } else if (state.pendingMemorizedSurahs.includes(sid)) {
        state.pendingMemorizedSurahs.splice(state.pendingMemorizedSurahs.indexOf(sid), 1);
      } else {
        state.pendingMemorizedSurahs.push(sid);
        showMessageCard('success', 'تم الإرسال! 📩', 'حفظك بانتظار تأكيد الوالدين قبل ما يُحسب رسميًا');
      }
      saveState(); render(); break;
    }

    case 'toggle-memorized-hadith': {
      const hid = el.dataset.id;
      state.memorizedHadiths = state.memorizedHadiths || [];
      state.pendingMemorizedHadiths = state.pendingMemorizedHadiths || [];
      if (state.memorizedHadiths.includes(hid)) {
        state.memorizedHadiths.splice(state.memorizedHadiths.indexOf(hid), 1);
      } else if (state.pendingMemorizedHadiths.includes(hid)) {
        state.pendingMemorizedHadiths.splice(state.pendingMemorizedHadiths.indexOf(hid), 1);
      } else {
        state.pendingMemorizedHadiths.push(hid);
        showMessageCard('success', 'تم الإرسال! 📩', 'حفظك بانتظار تأكيد الوالدين قبل ما يُحسب رسميًا');
      }
      saveState(); render(); break;
    }

    case 'approve-memorized-surah': {
      const sid = Number(el.dataset.id);
      state.pendingMemorizedSurahs = (state.pendingMemorizedSurahs || []).filter(x => x !== sid);
      if (!state.memorizedSurahs.includes(sid)) state.memorizedSurahs.push(sid);
      if (hasTierAtLeast('gold-plan')) state.diamonds = (state.diamonds || 0) + 5;
      saveState(); checkAndUnlockAchievements(); render(); break;
    }
    case 'reject-memorized-surah': {
      const sid = Number(el.dataset.id);
      state.pendingMemorizedSurahs = (state.pendingMemorizedSurahs || []).filter(x => x !== sid);
      saveState(); render(); break;
    }
    case 'approve-memorized-hadith': {
      const hid = el.dataset.id;
      state.pendingMemorizedHadiths = (state.pendingMemorizedHadiths || []).filter(x => x !== hid);
      state.memorizedHadiths = state.memorizedHadiths || [];
      if (!state.memorizedHadiths.includes(hid)) state.memorizedHadiths.push(hid);
      if (hasTierAtLeast('gold-plan')) state.diamonds = (state.diamonds || 0) + 5;
      saveState(); checkAndUnlockAchievements(); render(); break;
    }
    case 'reject-memorized-hadith': {
      const hid = el.dataset.id;
      state.pendingMemorizedHadiths = (state.pendingMemorizedHadiths || []).filter(x => x !== hid);
      saveState(); render(); break;
    }

    case 'quran-next-page': {
      if (quranPageIndex < quranPages.length - 1) { quranPageIndex++; flipQuranPage('next'); }
      break;
    }

    case 'quran-prev-page': {
      if (quranPageIndex > 0) { quranPageIndex--; flipQuranPage('prev'); }
      break;
    }

    case 'filter-hadith':
      hadithTopicFilter = el.dataset.topic; render(); break;

    case 'toggle-agreed-hadith':
      hadithAgreedOnly = !hadithAgreedOnly; render(); break;

    case 'filter-sunnah':
      sunnahCatFilter = el.dataset.cat; render(); break;

    case 'speak-hadith-of-day': {
      const h = hadiths[hashStr(todayStr()) % hadiths.length];
      speakArabic(h.text + '. ' + (h.explanation || ''));
      break;
    }

    case 'tutorial-next':
      clearInterval(tutorialTimer);
      advanceTutorial();
      if (tutorialActive) tutorialTimer = setInterval(advanceTutorial, TUTORIAL_STEP_MS);
      break;

    case 'tutorial-skip':
      endTutorial(); break;

    case 'refresh-prayer-times':
      fetchPrayerTimesIfNeeded(true); render(); break;

    case 'open-adhkar-cat':
      playOpenSound(); openModal('adhkar-cat', el.dataset.id); break;

    case 'open-prayer':
      playOpenSound(); openModal('prayer', el.dataset.id); break;

    case 'tap-dhikr': {
      const id = el.dataset.id, max = Number(el.dataset.count);
      const wasComplete = state.dhikrProgress[id] >= max;
      state.dhikrProgress[id] = Math.min((state.dhikrProgress[id] || 0) + 1, max);
      saveState();
      if (state.dhikrProgress[id] >= max) {
        playTickSound();
        if (!wasComplete) {
          state.dhikrCompletedCount = (state.dhikrCompletedCount || 0) + 1;
          if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
          state.hasanahTree.dhikr = (state.hasanahTree.dhikr || 0) + 1;
          saveState(); checkAndUnlockAchievements();
        }
      }
      render(); break;
    }

    case 'request-weekly': {
      const id = el.dataset.id;
      state.weeklyClaimed[id] = todayStr();
      saveState(); celebrate();
      sendPhoneNotification('تحدي أسبوعي في انتظار تأكيدك ⏳', 'طلب تأكيد إكمال التحدي الأسبوعي');
      render(); break;
    }

    case 'submit-khutba': {
      const id = el.dataset.id;
      const text = (document.getElementById('khutba-input')?.value || '').trim();
      if (!text) { showMessageCard('warning', 'اكتب أولاً', 'اكتب أهم حاجة اتعلمتها من الخطبة قبل الإرسال'); break; }
      state.khutbaNotes[todayStr()] = text;
      state.weeklyClaimed[id] = todayStr();
      saveState(); celebrate(); render(); break;
    }

    case 'approve-weekly': {
      const id = el.dataset.id, pts = Number(el.dataset.pts);
      state.weeklyApproved[id] = todayStr();
      state.weeklyApprovedTotal = (state.weeklyApprovedTotal || 0) + 1;
      addPoints(pts); saveState(); celebrate(); playSuccessSound();
      checkAndUnlockAchievements();
      render(); break;
    }

    case 'reject-weekly': {
      delete state.weeklyClaimed[el.dataset.id];
      saveState(); render(); break;
    }

    case 'toggle-island-milestones':
      islandMilestonesOpen = !islandMilestonesOpen; render(); break;

    case 'tap-pet': {
      playPetSound();
      bouncePetFigure();
      break;
    }

    case 'select-pet':
      state.currentPet = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-pet': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.petsOwned.push(id); state.currentPet = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد، استمر في إنجاز المهام لتجمع المزيد');
      render(); break;
    }

    case 'select-theme':
      state.appColorTheme = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-theme': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.colorThemesOwned.push(id); state.appColorTheme = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد');
      render(); break;
    }

    case 'select-cert-frame':
      state.currentCertFrame = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-cert-frame': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.certFramesOwned.push(id); state.currentCertFrame = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد');
      render(); break;
    }

    case 'select-pot-skin':
      state.currentPotSkin = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-pot-skin': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.potSkinsOwned.push(id); state.currentPotSkin = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد');
      render(); break;
    }

    case 'select-bg-theme':
      state.currentBackgroundTheme = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-bg-theme': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.backgroundThemesOwned.push(id); state.currentBackgroundTheme = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد');
      render(); break;
    }

    case 'select-pet-accessory':
      state.currentPetAccessory = state.currentPetAccessory === el.dataset.id ? '' : el.dataset.id;
      saveState(); playOpenSound(); render(); break;

    case 'buy-pet-accessory': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.petAccessoriesOwned.push(id); state.currentPetAccessory = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد');
      render(); break;
    }

    case 'select-avatar':
      state.currentAvatar = el.dataset.id; saveState(); playOpenSound(); render(); break;

    case 'buy-avatar': {
      const id = el.dataset.id, cost = Number(el.dataset.cost);
      if (spendPoints(cost)) { state.avatarsOwned.push(id); state.currentAvatar = id; saveState(); playAchievementSound(); celebrate(); }
      else showMessageCard('warning', 'نقاط غير كافية', 'لا تملك نقاطاً كافية بعد، استمر في إنجاز المهام لتجمع المزيد');
      render(); break;
    }

    case 'save-name': {
      const rawVal = document.getElementById('name-input').value;
      const val = sanitizeChildName(rawVal);
      const ageEl = document.getElementById('age-input');
      const age = ageEl ? Number(ageEl.value) : 0;
      if (rawVal && rawVal.trim() && !val) {
        showMessageCard('warning', 'اسم غير صالح', 'الاسم لازم يكون حروف عربي أو إنجليزي بس، من حرفين لحد 20 حرف، من غير أرقام أو رموز');
        break;
      }
      if (val) state.childName = val;
      if (age >= 2 && age <= 15) state.childAge = age;
      saveState();
      try {
        const fidx = loadFamilyIndex();
        const cur = fidx.profiles.find(x => x.id === fidx.activeId);
        if (cur && val) { cur.name = state.childName; saveFamilyIndex(fidx); }
      } catch (e) {}
      render(); break;
    }

    case 'add-family-profile': {
      const rawName = prompt('اسم الطفل الجديد؟');
      const name = sanitizeChildName(rawName);
      if (rawName && rawName.trim() && !name) {
        showMessageCard('warning', 'اسم غير صالح', 'الاسم لازم يكون حروف عربي أو إنجليزي بس، من حرفين لحد 20 حرف');
        break;
      }
      if (!name) break;
      const idx = loadFamilyIndex();
      const newId = 'p' + Date.now();
      idx.profiles.push({ id: newId, name });
      saveFamilyIndex(idx);
      const fresh = defaultState();
      fresh.childName = name;
      localStorage.setItem('hasana_profile_' + newId, JSON.stringify(fresh));
      render(); break;
    }

    case 'switch-profile': {
      const targetId = el.dataset.id;
      const idx = loadFamilyIndex();
      if (targetId === idx.activeId) break;
      saveCurrentProfileSnapshot(idx);
      const targetState = loadProfileState(targetId);
      if (!targetState) break;
      idx.activeId = targetId; saveFamilyIndex(idx);
      state = rollDailyState({ ...defaultState(), ...targetState });
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      currentMode = 'child'; currentTab = 'home';
      render(); break;
    }

    case 'delete-profile': {
      const delId = el.dataset.id;
      const didx = loadFamilyIndex();
      const target = didx.profiles.find(x => x.id === delId);
      if (!target || delId === didx.activeId || didx.profiles.length <= 1) break;
      if (!confirm('حذف حساب "' + target.name + '" نهائيًا بكل نقاطه وإنجازاته؟ لا يمكن التراجع.')) break;
      didx.profiles = didx.profiles.filter(x => x.id !== delId);
      saveFamilyIndex(didx);
      localStorage.removeItem('hasana_profile_' + delId);
      render(); break;
    }

    case 'encourage-profile': {
      const msg = prompt('اكتب رسالة تشجيع قصيرة له/لها:');
      if (!msg || !msg.trim()) break;
      const target = loadProfileState(el.dataset.id);
      if (!target) break;
      target.pendingEncouragements = target.pendingEncouragements || [];
      target.pendingEncouragements.push(msg.trim());
      localStorage.setItem('hasana_profile_' + el.dataset.id, JSON.stringify(target));
      showMessageCard('success', 'تم الإرسال! 💌', 'ستظهر رسالة التشجيع له عند دخوله حسابه');
      render(); break;
    }

    case 'dismiss-encouragements':
      state.pendingEncouragements = []; saveState(); render(); break;

    case 'open-coupon-redeem':
      openModal('coupon-redeem'); break;

    case 'redeem-coupon-code': {
      const raw = (document.getElementById('coupon-code-input') || {}).value || '';
      const err = document.getElementById('pin-error');
      const coupon = findActiveCoupon(raw);
      if (!coupon) {
        if (err) err.textContent = 'الكود غير صحيح أو منتهي الصلاحية';
        break;
      }
      if ((state.redeemedCoupons || []).includes(coupon.code)) {
        triggerCodeLock();
        modalStack = [];
        render();
        break;
      }
      modalStack.pop();
      modalStack.push({ type: 'coupon-scratch', coupon });
      playOpenSound();
      render(); break;
    }

    case 'force-reveal-coupon':
      revealCouponReward(); break;

    case 'open-parent-gate':
      pinBuffer = ''; passwordBuffer = ''; patternBuffer = []; openModal('pin'); break;

    case 'open-security-recovery':
      modalStack.pop(); openModal('security-recovery'); break;

    case 'security-recovery-submit': {
      const ans = (document.getElementById('security-recovery-answer') || {}).value || '';
      if (!ans.trim()) break;
      const hashed = await hashPin(ans.trim().toLowerCase());
      if (hashed === state.parentSecurityA) {
        // نمسح وسيلة القفل الحالية فقط (مش أي بيانات تانية) عشان يقدر يحدد وحدة جديدة فورًا
        if (state.parentLockType === 'password') state.parentPassword = '';
        else if (state.parentLockType === 'pattern') state.parentPattern = '';
        else state.parentPin = '';
        saveState();
        modalStack.pop();
        pinBuffer = ''; passwordBuffer = ''; patternBuffer = [];
        openModal('pin');
        showMessageCard('success', 'تم التحقق', 'اختر رقمك/كلمة سرك الجديدة الآن');
      } else {
        const err = document.getElementById('pin-error');
        if (err) err.textContent = 'إجابة غير صحيحة';
      }
      break;
    }

    case 'password-submit': {
      const val = (document.getElementById('parent-password-input') || {}).value || '';
      if (!val) break;
      const enteredHash = await hashPin(val);
      const stored = state.parentPassword;
      if (!stored) {
        state.parentPassword = enteredHash; saveState();
        modalStack = []; currentMode = 'parent'; render();
      } else {
        const match = looksHashed(stored) ? enteredHash === stored : val === stored;
        if (match) {
          if (!looksHashed(stored)) { state.parentPassword = enteredHash; saveState(); }
          modalStack = []; currentMode = 'parent'; render();
        } else {
          document.getElementById('pin-error').textContent = 'كلمة السر غير صحيحة';
          render();
        }
      }
      break;
    }

    case 'pattern-dot': {
      const i = Number(el.dataset.i);
      if (!patternBuffer.includes(i)) patternBuffer.push(i);
      render(); break;
    }

    case 'pattern-clear':
      patternBuffer = []; render(); break;

    case 'pattern-submit': {
      if (patternBuffer.length < 4) {
        document.getElementById('pin-error').textContent = 'اختر 4 نقاط على الأقل';
        render(); break;
      }
      const seq = patternBuffer.join('-');
      const enteredHash = await hashPin(seq);
      const stored = state.parentPattern;
      if (!stored) {
        state.parentPattern = enteredHash; state.lastSecurityChange = Date.now(); saveState();
        sendPhoneNotification('تم إعداد نمط القفل 🔒', 'تم حفظ نمط جديد لدخول وضع الوالدين');
        patternBuffer = []; modalStack = []; currentMode = 'parent'; render();
      } else {
        const match = looksHashed(stored) ? enteredHash === stored : seq === stored;
        if (match) {
          if (!looksHashed(stored)) { state.parentPattern = enteredHash; saveState(); }
          patternBuffer = []; modalStack = []; currentMode = 'parent'; render();
        } else {
          document.getElementById('pin-error').textContent = 'النمط غير صحيح';
          patternBuffer = []; render();
        }
      }
      break;
    }

    case 'set-parent-lock-type':
      state.parentLockType = el.dataset.type; saveState(); render(); break;


    case 'pin-key': {
      const k = el.dataset.k;
      if (k === 'DEL') pinBuffer = pinBuffer.slice(0, -1);
      else if (pinBuffer.length < 4) pinBuffer += k;
      if (pinBuffer.length === 4) {
        const enteredHash = await hashPin(pinBuffer);
        const stored = state.parentPin;
        if (stored === '') {
          // أول استخدام: هذا الإدخال يصبح هو الرقم السري من الآن فصاعداً
          state.parentPin = enteredHash; saveState();
          pinBuffer = ''; modalStack = []; currentMode = 'parent'; render();
        } else {
          const match = looksHashed(stored) ? enteredHash === stored : pinBuffer === stored;
          if (match) {
            if (!looksHashed(stored)) { state.parentPin = enteredHash; saveState(); }
            pinBuffer = ''; modalStack = []; currentMode = 'parent'; render();
          } else {
            document.getElementById('pin-error').textContent = 'الرقم السري غير صحيح';
            pinBuffer = ''; render();
          }
        }
      } else render();
      break;
    }

    case 'approve-task': {
      const id = el.dataset.id, pts = Number(el.dataset.pts);
      state.tasksApproved[id] = todayStr();
      state.tasksApprovedTotal = (state.tasksApprovedTotal || 0) + 1;
      state.tasksApprovedToday = (state.tasksApprovedToday || 0) + 1;
      state.taskTypeApprovedEver[id] = true;
      const taskObj = [...defaultTasks, ...state.customTasks].find(t => t.id === id);
      if (taskObj && taskObj.name && taskObj.name.includes('صدقة')) state.sadaqahDone = true;
      if (!state.hasanahTree) state.hasanahTree = { salah: 0, quran: 0, dhikr: 0, kindness: 0 };
      const hCat = hasanahCategory(taskObj && taskObj.name);
      state.hasanahTree[hCat] = (state.hasanahTree[hCat] || 0) + 1;
      addPoints(pts); saveState(); celebrate(); playSuccessSound();
      checkAndUnlockAchievements();
      addPoints(pts); saveState(); celebrate(); playSuccessSound();
      checkAndUnlockAchievements();
      sendPhoneNotification('أحسنت! 🎉', (taskObj ? taskObj.name : 'مهمة') + ' اكتملت، +' + pts + ' نقطة');
      render(); break;
    }

    case 'reject-task': {
      delete state.tasksPending[el.dataset.id];
      saveState(); render(); break;
    }

    case 'back-to-child':
      currentMode = 'child'; currentTab = 'home'; render(); break;

    case 'add-custom-task': {
      const nameEl = document.getElementById('new-task-name');
      const name = nameEl.value.trim().slice(0, 40);
      const ptsRaw = Number(document.getElementById('new-task-points').value);
      const pts = Number.isFinite(ptsRaw) && ptsRaw > 0 ? Math.min(Math.round(ptsRaw), 1000) : null;
      if (!name) { showMessageCard('warning', 'اكتب اسم المهمة', 'أدخل اسم المهمة أولاً'); break; }
      if (!pts) { showMessageCard('warning', 'عدد نقاط غير صحيح', 'اكتب رقمًا صحيحًا أكبر من صفر (بحد أقصى 1000)'); break; }
      state.customTasks.push({ id: 'custom_' + Date.now(), name, points: pts });
      saveState();
      nameEl.value = ''; document.getElementById('new-task-points').value = '';
      showMessageCard('success', 'تمت الإضافة', 'المهمة الجديدة ظاهرة الآن عند طفلك');
      render(); break;
    }

    case 'delete-custom-task': {
      const dt = state.customTasks.find(t => t.id === el.dataset.id);
      if (dt && !confirm('حذف مهمة "' + dt.name + '"؟')) break;
      state.customTasks = state.customTasks.filter(t => t.id !== el.dataset.id);
      saveState(); render(); break;
    }

    case 'save-new-pin': {
      const val = document.getElementById('new-pin').value.trim();
      if (/^\d{4}$/.test(val)) {
        state.parentPin = await hashPin(val); state.lastSecurityChange = Date.now(); saveState();
        document.getElementById('pin-save-msg').textContent = 'تم الحفظ بنجاح';
        sendPhoneNotification('تم تغيير الرقم السري 🔒', 'تم تحديث رقمك السري الآن');
      } else {
        document.getElementById('pin-save-msg').textContent = 'أدخل 4 أرقام فقط';
      }
      break;
    }

    case 'save-new-password': {
      const val = document.getElementById('new-password').value.trim();
      if (val.length >= 4) {
        state.parentPassword = await hashPin(val); state.lastSecurityChange = Date.now(); saveState();
        document.getElementById('pin-save-msg').textContent = 'تم الحفظ بنجاح';
        sendPhoneNotification('تم تغيير كلمة السر 🔒', 'تم تحديث كلمة سرك الآن');
      } else {
        document.getElementById('pin-save-msg').textContent = 'كلمة السر يجب أن تكون 4 حروف على الأقل';
      }
      break;
    }

    case 'save-screen-limit': {
      const raw = Number(document.getElementById('screen-limit-input').value);
      state.screenLimitMinutes = Number.isFinite(raw) && raw > 0 ? Math.min(Math.round(raw), 600) : 0;
      state.extraTimeGrantedToday = 0;
      saveState();
      showMessageCard('success', 'تم الحفظ', state.screenLimitMinutes ? 'هيتقفل التطبيق تلقائيًا بعد ' + state.screenLimitMinutes + ' دقيقة استخدام يوميًا' : 'تم إلغاء حد وقت الشاشة');
      render(); break;
    }

    case 'grant-extra-time':
      state.extraTimeGrantedToday = (state.extraTimeGrantedToday || 0) + 15;
      saveState();
      showMessageCard('success', 'تمت الإضافة', 'اتمنح 15 دقيقة إضافية النهاردة');
      render(); break;

    case 'save-bedtime': {
      const st = document.getElementById('bedtime-start-input').value;
      const en = document.getElementById('bedtime-end-input').value;
      state.bedtimeStart = st || ''; state.bedtimeEnd = en || '';
      saveState();
      showMessageCard('success', 'تم الحفظ', (state.bedtimeStart && state.bedtimeEnd) ? 'هيتقفل التطبيق تلقائيًا من ' + state.bedtimeStart + ' إلى ' + state.bedtimeEnd : 'تم إلغاء وقت النوم');
      render(); break;
    }

    case 'save-security-question': {
      const q = document.getElementById('security-q-input').value.trim().slice(0, 100);
      const a = document.getElementById('security-a-input').value.trim();
      if (!q || !a) { showMessageCard('warning', 'أكمل البيانات', 'اكتب السؤال والإجابة معًا'); break; }
      state.parentSecurityQ = q;
      state.parentSecurityA = await hashPin(a.toLowerCase());
      saveState();
      document.getElementById('security-a-input').value = '';
      showMessageCard('success', 'تم الحفظ', 'تقدر تسترجع دخولك بيه لو نسيت القفل');
      render(); break;
    }

    case 'share-progress-report': {
      const text = buildProgressReport();
      if (navigator.share) {
        navigator.share({ title: 'تقرير حصالة الحسنات', text }).catch(() => {});
      } else {
        window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
      }
      break;
    }

    case 'export-backup':
      exportBackup(); break;

    case 'reset-app': {
      if (confirm('هل أنت متأكد من مسح كل البيانات؟ لا يمكن التراجع.')) {
        localStorage.removeItem(STORAGE_KEY);
        state = defaultState();
        currentMode = 'child'; currentTab = 'home';
        render();
      }
      break;
    }
  }
}

// ============================== تقرير التقدّم + النسخ الاحتياطي ==============================
function buildProgressReport() {
  const level = getCurrentLevel(state.totalEarnedPoints);
  const ach = Object.keys(state.unlockedAchievements || {}).length;
  return [
    'تقرير تقدّم ' + state.childName + ' في تطبيق حصالة الحسنات 🌙',
    'المستوى: ' + level.name,
    'إجمالي النقاط: ' + (state.totalEarnedPoints || 0),
    'أيام الدخول المتتالية: ' + (state.loginStreak || 0),
    'المهام المعتمدة: ' + (state.tasksApprovedTotal || 0),
    'الإنجازات: ' + ach + ' من ' + achievementsList.length,
    'السور المحفوظة: ' + (state.memorizedSurahs || []).length,
    'الألماس: ' + (state.diamonds || 0),
  ].join('\n');
}

const BACKUP_KEY_PATTERN = /^hasana_(state_v1|family_v1|profile_[A-Za-z0-9_-]+)$/;
function exportBackup() {
  try {
    const idx = loadFamilyIndex();
    saveCurrentProfileSnapshot(idx);
    const data = {};
    Object.keys(localStorage).filter(k => BACKUP_KEY_PATTERN.test(k)).forEach(k => { data[k] = localStorage.getItem(k); });
    const blob = new Blob([JSON.stringify({ app: 'hasana-hasanat', version: 1, exportedAt: new Date().toISOString(), data })], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'hasanat-backup-' + todayStr() + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    showMessageCard('success', 'تم حفظ النسخة الاحتياطية', 'احتفظ بالملف في مكان آمن، وتقدر تستعيده من نفس الصفحة');
  } catch (e) {
    showMessageCard('error', 'تعذّر حفظ النسخة', 'جرّب مرة تانية أو من متصفح آخر');
  }
}
function handleBackupImport(input) {
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;
  if (file.size > 8 * 1024 * 1024) { showMessageCard('error', 'الملف كبير جدًا', 'اختر ملف نسخة احتياطية صحيح'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const obj = JSON.parse(reader.result);
      if (!obj || obj.app !== 'hasana-hasanat' || !obj.data || typeof obj.data !== 'object') throw new Error('not a backup');
      const keys = Object.keys(obj.data).filter(k => BACKUP_KEY_PATTERN.test(k));
      if (!keys.includes('hasana_state_v1')) throw new Error('no state');
      keys.forEach(k => { const v = JSON.parse(obj.data[k]); if (!v || typeof v !== 'object') throw new Error('bad value'); });
      if (!confirm('سيتم استبدال بيانات هذا الجهاز الحالية بالنسخة الاحتياطية. هل أنت متأكد؟')) return;
      Object.keys(localStorage).filter(k => /^hasana_(family_v1|profile_)/.test(k)).forEach(k => localStorage.removeItem(k));
      keys.forEach(k => localStorage.setItem(k, obj.data[k]));
      state = loadState();
      currentMode = 'child'; currentTab = 'home'; modalStack = [];
      render();
      showMessageCard('success', 'تمت الاستعادة', 'رجعت كل بياناتك من النسخة الاحتياطية');
    } catch (e) {
      showMessageCard('error', 'ملف غير صالح', 'اختر ملف نسخة احتياطية تم حفظه من التطبيق نفسه');
    }
  };
  reader.readAsText(file);
}

// ============================== الإقلاع ==============================
// يخزن صورة الطفل محليًا فقط داخل هذا الجهاز (localStorage)، ولا تُرسل لأي مكان
// يعرض صورة يرسلها الطفل في محادثة فاعل الخير (تبقى محليًا فقط، لا تُرسل لأي خادم)
// يقرأ صورة قائمة المكونات، يحمّل أداة قراءة النص عند الحاجة (مرة واحدة فقط)، ثم يفحص رموز E-Numbers فيها
function handleHalalScanFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  halalScanLoading = true;
  halalScanResult = null;
  render();
  const reader = new FileReader();
  reader.onload = () => {
    const imageDataUrl = reader.result;
    loadTesseract()
      .then(() => Tesseract.recognize(imageDataUrl, 'eng'))
      .then(({ data: { text } }) => {
        halalScanResult = { rawText: text, matches: extractENumbers(text) };
        halalScanLoading = false;
        render();
      })
      .catch((e) => {
        halalScanLoading = false;
        render();
        showMessageCard('error', 'تعذّر تحليل الصورة', e.message || 'تأكد من اتصالك بالإنترنت وحاول مرة أخرى');
      });
  };
  reader.readAsDataURL(file);
  input.value = '';
}

function handleAssistantImage(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    assistantChat.push({ role: 'user', kind: 'image', src: reader.result });
    assistantChat.push({ role: 'assistant', kind: 'text', text: 'ما شاء الله! 🌟 شفت صورتك. لو عندك سؤال عنها اكتبه لي بالحروف عشان أقدر أساعدك أكتر.' });
    render();
  };
  reader.readAsDataURL(file);
  input.value = '';
}

// تصغير صورة الطفل قبل الحفظ: الصور الأصلية من الموبايل كبيرة (عدة ميجا) وكانت بتملأ مساحة التخزين وتوقف حفظ التقدّم كله
function handlePhotoUpload(input) {
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      try {
        const S = 256, c = document.createElement('canvas');
        c.width = c.height = S;
        const m = Math.min(img.width, img.height);
        c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, S, S);
        state.childPhoto = c.toDataURL('image/jpeg', 0.82);
      } catch (e) {
        showMessageCard('error', 'تعذّرت معالجة الصورة', 'جرّب صورة أخرى'); return;
      }
      saveState(); render();
    };
    img.onerror = () => showMessageCard('error', 'تعذّر فتح الصورة', 'اختر ملف صورة صالح');
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

// ============================== تأثير "الشاشة المتكسّرة" عند صدور تحديث جديد ==============================
// الموقع كله يتشقّق كأن زجاج الشاشة انكسر، وتظهر لافتة لامعة "متاح تحديث جديد" تحدّث التطبيق بضغطة
function buildCrackSvg() {
  // شقوق تنطلق من نقطة الارتطام (يتحدد موضعها عشوائيًا في كل مرة) مع شقوق فرعية وحلقات متقطعة
  const rnd = (a, b) => a + Math.random() * (b - a);
  const cx = rnd(35, 65), cy = rnd(28, 55);
  let main = '', fine = '', rings = '';
  const n = 11;
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * Math.PI * 2 + rnd(-0.22, 0.22);
    let x = cx, y = cy, d = `M${cx.toFixed(1)} ${cy.toFixed(1)}`;
    const segs = Math.floor(rnd(5, 8));
    for (let k = 1; k <= segs; k++) {
      const step = rnd(7, 15) * (1 + k * 0.08);
      x += Math.cos(ang + rnd(-0.28, 0.28)) * step * 0.62;
      y += Math.sin(ang + rnd(-0.28, 0.28)) * step;
      d += ` L${x.toFixed(1)} ${y.toFixed(1)}`;
      if (k >= 2 && Math.random() < 0.55) {
        const ba = ang + (Math.random() < 0.5 ? 1 : -1) * rnd(0.5, 1.1);
        const bl = rnd(5, 13);
        fine += `<path d="M${x.toFixed(1)} ${y.toFixed(1)} l${(Math.cos(ba) * bl * 0.62).toFixed(1)} ${(Math.sin(ba) * bl).toFixed(1)}"/>`;
      }
    }
    main += `<path d="${d}" style="animation-delay:${(i * 0.035).toFixed(2)}s"/>`;
  }
  for (let r = 1; r <= 3; r++) {
    let d = '';
    const rad = 9 + r * 11;
    for (let i = 0; i < n; i++) {
      if (Math.random() < 0.35) continue;
      const a1 = (i / n) * Math.PI * 2 + rnd(0, 0.2), a2 = a1 + (Math.PI * 2 / n) * rnd(0.5, 0.9);
      d += `M${(cx + Math.cos(a1) * rad * 0.62).toFixed(1)} ${(cy + Math.sin(a1) * rad).toFixed(1)} L${(cx + Math.cos(a2) * rad * 0.62).toFixed(1)} ${(cy + Math.sin(a2) * rad).toFixed(1)} `;
    }
    rings += `<path d="${d}"/>`;
  }
  return `<svg class="crack-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
    <g class="crack-glow">${main}${fine}${rings}</g>
    <g class="crack-main">${main}</g><g class="crack-fine">${fine}${rings}</g>
    <circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="1.6" class="crack-hit"/>
  </svg>`;
}

function applyUpdateNow() {
  try {
    navigator.serviceWorker.getRegistration().then(reg => {
      if (reg && reg.waiting) reg.waiting.postMessage({ type: 'SKIP_WAITING' });
    }).catch(() => {});
  } catch (e) {}
  setTimeout(() => location.reload(), 150);
}

function dismissUpdateBanner() {
  const o = document.getElementById('update-banner');
  document.body.classList.remove('screen-cracked');
  if (o) o.remove();
  window.__updateDismissedAt = Date.now();
}

function showUpdateBanner() {
  if (document.getElementById('update-banner')) return;
  const en = (state && state.language) === 'en';
  const o = document.createElement('div');
  o.id = 'update-banner';
  o.setAttribute('role', 'alertdialog');
  o.setAttribute('aria-live', 'assertive');
  o.innerHTML = `
    ${buildCrackSvg()}
    <div class="crack-shards" aria-hidden="true"></div>
    <div class="update-card">
      <div class="update-icon">${icon('sparkle')}</div>
      <div class="update-title">${en ? 'A new update is available' : 'متاح تحديث جديد'}</div>
      <div class="update-sub">${en ? 'The screen is cracked, update now to fix it' : 'الشاشة اتكسرت، حدّث التطبيق الآن لإصلاحها'}</div>
      <button type="button" class="update-btn" id="update-now-btn">${en ? 'Update now' : 'تحديث الآن'}</button>
      <button type="button" class="update-later" id="update-later-btn">${en ? 'Later' : 'لاحقًا'}</button>
    </div>`;
  document.body.appendChild(o);
  document.body.classList.add('screen-cracked');
  o.querySelector('#update-now-btn').addEventListener('click', applyUpdateNow);
  o.querySelector('#update-later-btn').addEventListener('click', dismissUpdateBanner);
  try { if (typeof playErrorSound === 'function' && !state.calmMode) playErrorSound(); } catch (e) {}
  try { if (navigator.vibrate && state.hapticEnabled !== false && !state.calmMode) navigator.vibrate([60, 40, 120]); } catch (e) {}
}

function renderOfflineBanner() {
  if (navigator.onLine !== false) return '';
  return `<div class="offline-banner">${icon('warning')} أنت غير متصل بالإنترنت الآن، بعض الميزات (مواقيت الصلاة، نص القرآن، فاعل الخير) قد لا تعمل</div>`;
}

function renderRegionalNoticeIfNeeded() {
  if (state.lastRegionalNoticeShown === todayStr()) return;
  state.lastRegionalNoticeShown = todayStr();
  saveState();
  modalStack.push({ type: 'regional-notice' });
}

// إعلان تثبيت التطبيق: يظهر أعلى الصفحة في كل مرة الصفحة بتتحمّل/بتتحدّث من جديد (مش مرة واحدة بس زي التنبيهات التانية)
function isRunningStandaloneApp() {
  try {
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches)
      || window.navigator.standalone === true
      || /; wv\)/.test(navigator.userAgent || ''); // متصفح داخل تطبيق مُغلّف (زي تطبيق الـ APK نفسه)
  } catch (e) { return false; }
}
function showInstallAdBanner() {
  if (isRunningStandaloneApp()) return; // هو أصلاً مثبّت أو شغال جوه التطبيق، مفيش داعي نعلن له
  const b = document.getElementById('install-ad-banner');
  if (b) b.style.display = 'flex';
}
function dismissInstallAdBanner() {
  const b = document.getElementById('install-ad-banner');
  if (b) b.style.display = 'none';
}
function handleInstallAdClick() {
  dismissInstallAdBanner();
  currentMode = 'child'; modalStack = [];
  currentTab = 'otherServices';
  render();
  setTimeout(() => { playOpenSound(); openModal('apk-download'); }, 50);
}

function boot() {
  window.addEventListener('online', render);
  window.addEventListener('offline', render);
  initVoicesCache();
  renderRegionalNoticeIfNeeded();
  if (typeof applyLanguageDirection === 'function') applyLanguageDirection();
  if (typeof renderLanguagePickerIfNeeded === 'function') renderLanguagePickerIfNeeded();
  const splash = document.getElementById('splash');
  const bgTheme = backgroundColorThemes.find(x => x.id === state.currentBackgroundTheme);
  if (splash && bgTheme && bgTheme.id !== 'default') splash.style.background = bgTheme.splash;
  const tickerRoot = document.getElementById('dhikr-ticker-root');
  if (tickerRoot) tickerRoot.innerHTML = renderDhikrTicker();
  setInterval(rotateDhikrTicker, 3500); // كل 3.5 ثانية ذكر جديد، يمر على كل الأذكار الـ24 ثم يعيد الدورة تلقائيًا للأبد
  updateLoginStreak();
  render();
  // نغمة اللمعان + الصوت الإرشادي (ترحيب أول مرة أو "أهلاً برجوعك") تنتظر أول لمسة من المستخدم
  // لأن أغلب المتصفحات تمنع تشغيل الصوت تلقائيًا قبل أي تفاعل حقيقي من المستخدم
  const playIntroOnce = () => {
    playSplashShineSound();
    playWelcomeVoiceGuide();
    document.removeEventListener('click', playIntroOnce);
    document.removeEventListener('touchstart', playIntroOnce);
  };
  document.addEventListener('click', playIntroOnce, { once: true });
  document.addEventListener('touchstart', playIntroOnce, { once: true });
  fetchPrayerTimesIfNeeded();
  const minuteTick = () => {
    // لو انتهت مدة حظر الأكواد المتكررة، نرفعها أوتوماتيك ونعيد الرسم
    if (state.codeLockUntil && Date.now() >= state.codeLockUntil) {
      state.codeLockUntil = null; saveState(); render();
    }
    // لو عدّى منتصف الليل والتطبيق مفتوح، نبدأ يوم جديد (مهام ومتابعة أذكار متصفّرة)
    if (state.dailyDate !== todayStr() || state.dhikrDate !== todayStr()) {
      rollDailyState(state); saveState(); render();
    }
    fetchPrayerTimesIfNeeded(); checkPrayerTimeNow(); checkDailyReminders();
    // نحسب وقت الاستخدام فقط لما الطفل شغّال فعليًا والتطبيق ظاهر قدامه (مش في الخلفية)
    if (currentMode === 'child' && !document.hidden) {
      state.screenTimeUsedToday = (state.screenTimeUsedToday || 0) + 1;
      state.screenTimeDate = todayStr();
      saveState();
    }
    // تحديث العدّ التنازلي للصلاة القادمة لو الطفل واقف على تاب المواقيت، وكمان نراجع قفل وقت الشاشة/النوم
    if (((currentTab === 'prayerTimes' || childLockReason()) && currentMode === 'child' || isCodeLocked()) && !modalStack.length) render();
  };
  setInterval(minuteTick, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) minuteTick(); });
  const hideSplash = () => {
    if (splash && splash.isConnected) { splash.style.opacity = '0'; setTimeout(() => splash.remove(), 500); }
  };
  setTimeout(hideSplash, 5000);
  if (splash) splash.addEventListener('click', hideSplash); // اضغط في أي مكان لتخطي شاشة البداية

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').then(reg => {
        // لما تنزل نسخة جديدة من التطبيق تظهر شاشة "التحديث المتكسّرة" بدل ما المستخدم يفضل على النسخة القديمة
        const watch = (nw) => {
          if (!nw) return;
          nw.addEventListener('statechange', () => {
            if ((nw.state === 'installed' || nw.state === 'activated') && navigator.serviceWorker.controller) showUpdateBanner();
          });
        };
        if (reg.waiting && navigator.serviceWorker.controller) showUpdateBanner();
        reg.addEventListener('updatefound', () => watch(reg.installing));
        // فحص دوري عن نسخة جديدة (كل 10 دقائق وعند الرجوع للتطبيق) بدل انتظار إعادة تحميل الصفحة
        const check = () => { try { reg.update(); } catch (e) {} };
        setInterval(check, 10 * 60 * 1000);
        document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
      }).catch(() => {});
    });
  }
  // لتجربة التأثير: افتح الموقع بإضافة ?testupdate=1 في الرابط
  if (/[?&]testupdate=1/.test(location.search)) setTimeout(showUpdateBanner, 1200);
  showInstallAdBanner();
}

document.addEventListener('DOMContentLoaded', boot);
